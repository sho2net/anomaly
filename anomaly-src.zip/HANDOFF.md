# ANOMALY 引き継ぎメモ（v3.16 時点）

新しいチャットで開発を続けるための要点。詳しいルールと変更履歴は `anomaly-spec.md` を参照。

## 公開先
- 公開URL（オンライン対戦可）：https://sho2net.github.io/anomaly/ （GitHub リポジトリ sho2net/anomaly の index.html を GitHub Pages で配信）
- Claude上のアーティファクト：https://claude.ai/artifact/KX4v5HUNkir1cvHPed8DCA （Artifact ツールで url を指定して publish すると上書き更新。外部通信が塞がれているのでオンライン対戦は同一ブラウザ内のみ）
- 効果音・エフェクトの試聴ページ：https://claude.ai/artifact/RF3uvzzwXBNcxE2zHTXAu3 （build.py が作る lab.html。ボタンで音と演出を1つずつ確認できる）
- Firebase：プロジェクト anomaly-card（ID anomaly-card-sho、Sparkプラン）、Realtime Database（asia-southeast1）。ルールは rooms/{4文字} のみ読み書き可。設定値は page.html の `window.FIREBASE_CONFIG`。APIキーは sho2net.github.io/* にHTTPリファラー制限済み

## 作業の始め方
1. ソース一式 `anomaly-src.zip`（GitHub には置いていない。ユーザーが手元に保管し、チャットに添付してもらう）を作業フォルダに展開（例：/home/claude/anomaly）
2. `python3 build.py` → index.html（1ファイルに全部入り）ができる
3. テスト（下記）→ /mnt/user-data/outputs にコピー → Artifact を publish（files に bgm/*.mp3 を渡す）→ GitHub へは index.html（曲を変えたときは bgm フォルダも）をユーザーにドラッグしてもらい、「Commit changes」

## ファイル構成
| ファイル | 役割 |
|---|---|
| cards.js | カードデータ（K=クリーチャー, P=スペル, R_=置物, T_=罠）、スタッツ自動算出、効果テキスト生成（effectText/cardText）、アノマリー生成（makeAnomaly／奇妙枠makeWeird／伝説枠makeLegend）、トークン・特殊カード・リーダー能力（LEADER, LEADER_EX）、ボス一覧（BOSSES）、冒険の秘宝（TREASURES） |
| icons.js | SVGアイコン（iconSvg(d) は d.i / d.icon を参照） |
| engine.js | ルールエンジン（Game クラス、決定論的。rng はシード付き）。キュー方式で効果を解決 |
| ai.js | CPU（autoDeck, bestMain, chooser, step, mullPick, bossDeck, abilityValue） |
| net.js | オンライン通信（Firebase／同一ブラウザ用 LocalNet） |
| ui.js | 画面（タイトル・構築・対戦・図鑑・結果・オンライン・ボス挑戦・用語集・公開演出）。`/*ADV*/` の位置に adv_ui.js が差し込まれる |
| adv_ui.js | 冒険モード（地図・戦闘準備・報酬・店・宿・出来事・デッキ編集・封印・最終ボス） |
| fx.js | 効果音（AN.SFX：Web Audio 合成、ミュートは localStorage anomaly_sound_v1）と戦闘エフェクト（AN.FX：renderBattle の再描画前に snapshot、後に run で新しいイベントを演出。canvas のパーティクル＋カードの複製を fx レイヤーで動かす）。演出中は AN.FX.busy() の分だけ CPU の次の行動を待つ。表示専用なので Math.random 可 |
| lab.js | 試聴ページ（lab.html）専用。ゲーム本体には入らない |
| bgm/ | 曲（<key>.mp3）と tracks.json（ループの長さ・音量倍率）。make_bgm.py で作る。index.html には埋め込まず、同じ場所に bgm フォルダごと置く |
| make_bgm_song.py | 長い曲（Song）の加工：`python3 make_bgm_song.py battle2 曲.mp3 --group battle`。ループ点は tools_loopfind.py（librosa が必要：pip install librosa --break-system-packages）が拍と響きから自動で探す。気に入らなければ `--a 秒 --b 秒` で指定。同じ group の曲は2周ごとに順番に流れる |
| make_bgm.py | 短い Loop 曲の差し替え：`python3 make_bgm.py battle 新しい曲.mp3`（前後1秒のつなぎ足し・末尾の無音除去・音量の測定まで行う） |
| art/ | 一枚絵（WebP、26枚・計約1.2MB）。title / region_<属性> / lord_<属性> / boss_devourer / boss_judge / chal_1〜6 / ev_<出来事>。ui.js の ART(k) で参照。index.html に埋め込まず art フォルダごと置く。元の PNG は Z-Image Turbo（別チャットが Runpod で生成）、指示書は art-prompts.md |
| page.html | 外枠と CSS。build.py が `<!--SCRIPTS-->` に JS を埋め込む |
| build.py | index.html を生成 |

## テスト用スクリプト（すべて /home/claude/anomaly で実行）
- `python3 shot2.py`：ブラウザで通しの動作確認（"no errors" が出ればOK）
- `node sim.js 400 3 3`：CPU同士の対戦（属性別勝率・決着手番）
- `N=1500 node variant.js`：属性別勝率と光・闇の相性
- `node dominance.js`：上位互換に近いカードの組の検出（意図的に残しているのは 暗殺/封印、自然の怒り/一騎当千 の2組）
- `python3 adv_test.py`：冒険モードの通し
- `python3 bgm_test.py`：場面ごとの曲の切り替えとサウンド設定（先に `python3 -m http.server 8765` を起動。file:// では曲を読めない）
- `python3 hard_test.py`：冒険ハードの通し（難易度選択・敵の強化・周回ごとの最終ボス・制覇の記録）
- `N=150 node hardsim.js`（最初の地域）／`HV=z node hardsim2.js 150`（2〜3地域目）：ハードの難しさ。finalscale.js の CFG は buff（敵だけの強化）と xl（追加の伝説）も指定できる
- `python3 fieldh_test.py`：場が空・1体・7体で場の高さが変わらないか（画面の高さ3通り）
- `python3 sound_test.py`：全効果音をオフラインで書き出し、NaN とピーク音量を確認（bad=0 ならOK。音を変えたら必ず実行。NaN が1つでも出ると以降の音まで無音になる）
- `python3 lab_test.py`：試聴ページの全ボタンを押し、主な演出の途中を lab_*.png に保存
- `python3 fx_test.py`：対戦中に鳴った効果音の種類とエフェクトの数を数え、攻撃直後の画面を fx_atk*.png に保存
- `python3 online_test.py`：2タブでのオンライン対戦
- `python3 mobile_test.py`：スマホ幅（360/390/414）でターン終了ボタンが押せるか
- `python3 trap_ui_test.py`：罠の一時停止と表示順
- `MODE=new node advearly.js`：冒険の最初の地域の難しさ
- `CFG='[...]' node finalscale.js`：冒険の最終ボスの難しさ（封印の数ごと）
- playwright と node が必要（pip install playwright --break-system-packages が必要な場合あり）

## 設計上の約束事（これまでのやり取りで決まったこと）
- 文章・UIはすべて日本語。効果テキストは「自分／相手／お互い」「このクリーチャー自身を含むか・選べるか」「永続かターン終了時までか」を明記する
- 他ゲームの用語・カードの丸写しは避ける（例：接死→猛毒、クレスト→置物、シークレット→罠。伝説枠はハースの名物カードの「オマージュ」にとどめる）
- ランダム要素はよいが、コイントスで勝敗が決まる効果は入れない
- ブラウザ標準の confirm() は使わない（アーティファクトやアプリ内ブラウザで表示されない）。askConfirm() を使う
- エンジンは決定論的に保つ（オンラインは「デッキ＋行動ログ」を両端末で再生して同期している）。乱数は必ず g.rng を使う
- 罠の発動時は trapPause でエンジンを一時停止し、公開演出を閉じてから再開（UIで作るゲームは game.uiPause=true）
- バランスは CPU 同士のシミュレーションで確認するが、CPUが苦手な戦い方（森の加速、光の粘り）は低く出るので、人のプレイ感を優先する
- 冒険モードの最終ボスの能力はプレイヤー向けには伏せる（仕様書にもぼかして書く）
- 効果音はファンタジーの世界観に合わせ、露骨な電子音（素のサイン波・矩形波・のこぎり波の和音）は避ける（ユーザー談）。fx.js の pluck/harp（ハープ）・bell（鐘）・choir（聖歌隊）・drum（太鼓）を使う
- 演出はエンジンの events（play/attack/hit/dmg/armor/destroy/bounce/life/trap/bossphase/turn）だけを見て作る。場のカードには data-uid と data-zone（field/hand）が付いている
- BGM・イラストは Suno（曲）と Z-Image Turbo（画像）で作った素材を使う方向でも可（ユーザー談）。その場合は index.html に埋め込まず、リポジトリに別ファイルで置いて相対パスで読む想定

## 現在の数値の目安（v3.9.2〜3.10、ルールは変更なし）
- CPU同士の属性別勝率：炎53／水50／森47／光50／闇53%、決着は平均17〜18手番、先攻45〜50%
- 冒険：最初の地域の通常戦闘で強CPUをプレイヤー役にした勝率約70%、最終ボスは封印0で約22%、封印6以上で約80%

## 冒険ハードの要点（v3.13〜3.14）
- ハードの最終ボスは「双冠の審判者 ルクス＝ノクティア」（光・闇のデッキ、advMakeEnemy の kind==='final' && advLoop() の分岐）。能力（開発者向け）：bossRules.mirror＝Nターンごとに相手の場で最も攻撃力の高いクリーチャーの写し身を出す（乱数なし）。封印の効き目0〜3：3ターンごと＋ライフ15で真の姿（リーダー能力「双冠の裁き」＝破壊してそのコピーを出す、LEADER_EX.judge）／4〜5：4ターンごと／6以上：なし。仕様書にはぼかして書く
- finalscale.js の CFG：nb=1 で審判者、m＝写し身の間隔、ph=1 で真の姿あり
- advRun.hard＝周回（0はノーマル）。敵の強化は adv_ui.js の advHardMods／advFinalScale／advSealEff にまとまっている。エンジン側は Game の sideBuff（片方のクリーチャーだけ +攻/+体）
- 敵だけ+1/+1や開始エナジー+1を通常戦闘にかけると勝率が30%台まで落ちたので、通常戦闘は「デッキが1段強い」に留め、体力+1は強敵以上だけにした

## 次にやる候補（ユーザーと相談済みの順番）
1. （v3.10で済み・v3.11で重厚に作り直し）効果音と、攻撃・ダメージ・破壊のエフェクト。ユーザーの感想「軽くて安っぽい」を受けて、残響・低音・歪み・FM金属音、溜め→突進→ヒットストップ、画面揺れ、カードが割れる破壊にした
2. （v3.15で済み）BGM：Suno の Loop で作った7曲。場面と曲の対応は ui.js の bgmKeyFor、再生は fx.js の AN.BGM（効果音と同じ AudioContext。音楽は圧縮器を通さず直接出力）
3. （v3.16で済み）一枚絵：タイトル背景、冒険の見出し（地域）、地域の主・最終ボスの肖像（戦闘前の画面）、ボス挑戦の一覧、出来事7種。禁書庫（文字化け）とさすらいの強者（道路が写る）は絵なし→作り直し待ち。カードの絵は未定
4. カード絵：生成リスト cardart/card_prompts.json（231件、768×1024、1種1枚、L→R→U→C の順）と引き継ぎ書 cardart/card-art-handoff.md を画像生成担当に渡し済み。画像は Downloads\ANOMALY_art\cards\card_<ID>.png に届く予定。届いたら選別→WebP（小さめ）→カードの絵の欄に組み込み（アイコンは予備に残す）。アノマリーは毎試合生成なので固有の絵は無し
5. 残りの Song 曲（タイトル・地図・宿・通常戦闘B/C）が届いたら make_bgm_song.py で差し替え

## 効果音の先行書き出し（v3.16）
- その場合成は1音で最大230部品になり、非力なPCで音声処理が追いつかず BGM ごと途切れていた
- 音が出せるようになると、fx.js が全効果音（36種）を OfflineAudioContext（32kHz）で1つずつ裏で録音し、以後は録音を鳴らすだけ（1音1〜3部品、メモリ約24MB）。録音前の音だけその場で合成
- hit/face のダメージ量は 2/5/9 の3段階にまとめる。click/attack/hit/destroy は2通り録音してランダムに使う
- 試すとき `window.__sfxlive=true` で旧来のその場合成に戻せる
