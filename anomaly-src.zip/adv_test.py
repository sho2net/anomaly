import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':780}, device_scale_factor=2)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/anomaly/index.html'); await pg.wait_for_timeout(300)
        await pg.evaluate('localStorage.clear()'); await pg.reload(); await pg.wait_for_timeout(300)
        await pg.click('#btnAdv'); await pg.wait_for_timeout(300); await pg.screenshot(path='ad1.png')
        await pg.click('.advcolors button[data-c="void"]'); await pg.wait_for_timeout(300); await pg.screenshot(path='ad2.png')
        shots={}
        for step in range(40):
            scr=await pg.evaluate("document.querySelector('.screen')?document.querySelector('.screen').id:''")
            if scr=='advMap':
                btns=await pg.query_selector_all('.advnodes button')
                labels=[await x.inner_text() for x in btns]
                # prefer shop/event/inn once for coverage
                pick=0
                for k,l in enumerate(labels):
                    for want in ['店','謎','宿','強敵']:
                        if want in l and want not in shots: pick=k
                await btns[pick].click(); await pg.wait_for_timeout(300)
            elif scr=='advAnte':
                if 'ante' not in shots: await pg.screenshot(path='ad3.png'); shots['ante']=1
                await pg.click('#fight'); await pg.wait_for_timeout(800)
                mg=await pg.query_selector('#mgo')
                if mg: await mg.click(); await pg.wait_for_timeout(400)
                if 'battle' not in shots: await pg.screenshot(path='ad4.png'); shots['battle']=1
                # force outcome: win mostly, lose once
                lose = (step%7==3)
                await pg.evaluate("(lose)=>{ const g=window.__g(); const t=g.players[lose?0:1]; t.life=1; g.loseLife(t,1,'test'); window.__rb(); }", lose)
                await pg.wait_for_timeout(1500)
            elif scr=='advReward':
                if 'reward' not in shots: await pg.screenshot(path='ad5.png'); shots['reward']=1
                pk=await pg.query_selector('#picks .card')
                if pk:
                    await pk.click(); await pg.wait_for_timeout(200)
                    bb=await pg.query_selector('#bigbtns button.primary')
                    if bb: await bb.click(); await pg.wait_for_timeout(300); continue
                await pg.click('#next'); await pg.wait_for_timeout(300)
            elif scr=='advShop':
                if '店' not in shots: await pg.screenshot(path='ad6.png'); shots['店']=1
                it=await pg.query_selector('#buy .pcard:not(.out)')
                if it:
                    await it.click(); await pg.wait_for_timeout(200)
                    bb=await pg.query_selector('#bigbtns button.primary:not(:disabled)')
                    if bb: await bb.click(); await pg.wait_for_timeout(300)
                    else:
                        gh=await pg.query_selector('#bigbtns button.ghost');
                        if gh: await gh.click()
                await pg.click('#leave'); await pg.wait_for_timeout(300)
            elif scr=='advEvent':
                if '謎' not in shots: await pg.screenshot(path='ad7.png'); shots['謎']=1
                ch=await pg.query_selector('#ch button:not(:disabled)')
                if ch: await ch.click(); await pg.wait_for_timeout(300)
                pk=await pg.query_selector('#pk3 .card')
                if pk:
                    await pk.click(); await pg.wait_for_timeout(200); await pg.click('#bigbtns button.primary'); await pg.wait_for_timeout(300)
                go=await pg.query_selector('#go')
                if go: await go.click(); await pg.wait_for_timeout(300)
            elif scr=='advInn':
                shots['宿']=1
                await pg.click('#leave'); await pg.wait_for_timeout(300)
            elif scr=='battle':
                await pg.wait_for_timeout(1000)
            else:
                break
        st=await pg.evaluate("document.querySelector('.screen').id+' | '+(document.querySelector('.advhead')?document.querySelector('.advhead').innerText.replace(/\\n/g,' / '):document.body.innerText.slice(0,120))")
        print('end at', st, 'shots', list(shots.keys()))
        # deck editor
        await pg.screenshot(path='ad8.png')
        print(errs or 'no errors'); await b.close()
asyncio.run(main())
