// ================= 冒険モード（v3.0）=================
// 開始色を選ぶ → 自分のコレクション → 3つの地域（各5階＋地域ボス）→ 最終ボス。
// 戦闘は毎回カードを1枚ずつ賭ける（アンティ）。地域ごとにその属性のクリーチャーが+1/+1。
const ADV_LS='anomaly_adv_v1';
const ADV_AREA={
  flare:{ treasure:'X01', name:'灼熱の火山', icon:'bonfire', enemies:['火の民の戦士','溶岩の術師','炎の狂信者','灰の傭兵'], elite:'炎獄の騎士', boss:'火山の主イグナ', bossLeader:'inferno' },
  tide: { treasure:'X02', name:'深き海底神殿', icon:'wave', enemies:['潮の巫女','深海の斥候','渦の術師','泡の番人'], elite:'海淵の守護者', boss:'海の支配者ネレア', bossLeader:'boss_tide' },
  grow: { treasure:'X03', name:'太古の大森林', icon:'oldtree', enemies:['森の狩人','樹人の兵','獣使い','苔の賢者'], elite:'大角の王', boss:'森の古王ガイオス', bossLeader:'bloom' },
  ray:  { treasure:'X04', name:'天空の聖都', icon:'cathedral', enemies:['聖堂の衛士','巡礼の僧','光の射手','天使の見習い'], elite:'聖騎士団長', boss:'天光の主セラフ', bossLeader:'boss_ray' },
  void: { treasure:'X05', name:'冥府の墓所', icon:'tomb', enemies:['墓守','屍術師','影の刺客','骨の兵'], elite:'死の騎士', boss:'冥王ハーデン', bossLeader:'boss_void' },
};
const ADV_EV_ART={altar:'ev_altar',chest:'ev_chest',spring:'ev_spring',mirror:'ev_mirror',blade:'ev_armory',bandits:'ev_bandits',merchant:'ev_merchant'}; // 禁書庫・さすらいの強者は絵なし（生成画像に不具合があったため）
const ADV_PRICE={C:25,U:45,R:90,L:160,A:140};
let advRun=null;
function advSer(list){ return list.map(d=>d.anomaly? d : d.id); }
function advDeser(list){ return list.map(x=> typeof x==='string' ? (AN.CARD_BY_ID[x]||AN.SPECIAL[x]) : x).filter(Boolean); }
function advSave(){ if(!advRun) return; try{ const r=Object.assign({},advRun,{col:advSer(advRun.col)}); if(r.pending) r.pending=Object.assign({},r.pending,{en:Object.assign({},r.pending.en,{deck:advSer(r.pending.en.deck)})}); if(r.shop) r.shop=r.shop.map(o=>Object.assign({},o,{d:advSer([o.d])[0]})); if(r.picks) r.picks=advSer(r.picks); localStorage.setItem(ADV_LS, JSON.stringify(r)); }catch(e){} }
function advLoad(){ try{ const r=JSON.parse(localStorage.getItem(ADV_LS)); if(!r) return null; r.col=advDeser(r.col); if(r.pending){ r.pending.en.deck=advDeser(r.pending.en.deck); } if(r.shop) r.shop=r.shop.map(o=>Object.assign(o,{d:advDeser([o.d])[0]})); if(r.picks) r.picks=advDeser(r.picks); return r; }catch(e){ return null; } }
function advClear(){ try{ localStorage.removeItem(ADV_LS); }catch(e){} }
function advRng(tag){ advRun.counter=(advRun.counter||0)+1; return AN.makeRng(advRun.seed+':'+tag+':'+advRun.counter); }
function advDeckDefs(){ return advRun.deck.map(i=>advRun.col[i]); }
function advAttrs(defs){ const s=new Set(); defs.forEach(d=>{ if(!d.anomaly) d.attr.forEach(a=>s.add(a)); }); return [...s]; }
function advMain(defs){ const c={}; defs.forEach(d=>{ if(!d.anomaly) d.attr.forEach(a=>c[a]=(c[a]||0)+1); }); let best=null,bv=-1; Object.keys(c).forEach(a=>{ if(c[a]>bv){bv=c[a];best=a;} }); return best||AN.ATTR_ORDER[0]; }
function advRemoveCol(idx){ advRun.col.splice(idx,1); advRun.deck=advRun.deck.filter(i=>i!==idx).map(i=>i>idx?i-1:i); }
function advAutoDeck(){
  const col=advRun.col; const score={};
  col.forEach(d=>{ if(!d.anomaly) d.attr.forEach(a=>score[a]=(score[a]||0)+AN.cardValue(d)); });
  const two=Object.keys(score).sort((a,b)=>score[b]-score[a]).slice(0,2);
  const ok=d=>d.anomaly||d.attr.length===0||d.attr.every(a=>two.includes(a));
  const idx=col.map((d,i)=>i).filter(i=>ok(col[i])).sort((a,b)=>{ const va=AN.cardValue(col[a])/Math.max(1,col[a].cost)*(col[a].cost<=4?1.15:1)+(col[a].anomaly?2:0)+(col[a].treasure?4:0), vb=AN.cardValue(col[b])/Math.max(1,col[b].cost)*(col[b].cost<=4?1.15:1)+(col[b].anomaly?2:0)+(col[b].treasure?4:0); return vb-va; });
  advRun.deck=idx.slice(0,30);
  if(advRun.deck.length<30){ col.forEach((d,i)=>{ if(advRun.deck.length<30 && !advRun.deck.includes(i)) advRun.deck.push(i); }); }
}
function advEnsureDeck(){
  // コレクションが30枚未満なら、無属性コモンで補充（救済）
  while(advRun.col.length<30){ const cs=AN.CARDS.filter(d=>d.attr.length===0&&d.rarity==='C'); advRun.col.push(cs[Math.floor(Math.random()*cs.length)]); }
  if(advRun.deck.length!==30 || advAttrs(advDeckDefs()).length>2) advAutoDeck();
}
function advPool(attr, rars){ return AN.CARDS.filter(d=>(attr? d.attr.includes(attr) : d.attr.length===0) && rars.includes(d.rarity)); }
// v3.13 ハード：記録（ノーマルの制覇回数・ハードで制覇した最高の周回）
const ADV_REC='anomaly_adv_record_v1';
function advRecord(){ try{ return Object.assign({normal:0,hard:0}, JSON.parse(localStorage.getItem(ADV_REC))||{}); }catch(e){ return {normal:0,hard:0}; } }
function advSaveRecord(r){ try{ localStorage.setItem(ADV_REC, JSON.stringify(r)); }catch(e){} }
function advLoop(){ return (advRun&&advRun.hard)||0; } // 0＝ノーマル、1以上＝ハードの周回
// ハードの敵：通常戦闘は敵のデッキが1段強い、強敵・主・最終ボスは敵のクリーチャーだけ体力+1、敵は常に強CPUでライフ+2〜3
function advHardMods(kind, strong){
  const L=advLoop(); if(!L) return null;
  const big = kind!=='battle' || strong;
  return { life: advRun.areaIdx===0?2:3, level:3, tierUp: kind==='battle' && !strong, buff: big?{atk:0,hp:1}:null };
}
// 最終ボス：封印の効き目はハードでは3分の2。周回ごとにライフ+3、3周目からエナジー+1、5周目から伝説が増え、6周目から攻撃力も+1
function advSealEff(){ const sl=advSeals(); return advLoop()? Math.floor(sl*2/3) : sl; }
function advFinalScale(){ const L=advLoop(); if(!L) return {life:0,energy:0,xl:0,buff:null};
  return { life:3+3*Math.min(7,L-1), energy:(L>=7?2:(L>=3?1:0)), xl:(L>=8?2:(L>=5?1:0)), buff:{atk:L>=6?1:0,hp:1} }; }
function advNewRun(color, loop){
  const seed='adv'+Math.floor(Math.random()*1e9).toString(36);
  advRun={ v:1, hard:loop||0, seed, counter:0, gold:60, hearts:3, maxHearts:3, col:[], deck:[], start:color, areas:[], areaIdx:0, floor:0, choices:null, wins:0, losses:0, stage:'map' };
  const rng=advRng('start');
  const others=rng.shuffle(AN.ATTR_ORDER.filter(a=>a!==color));
  advRun.areas=[others[0],others[1],others[2]];
  const cc=advPool(color,['C']), cu=advPool(color,['U']), nc=advPool(null,['C']);
  for(let i=0;i<18;i++) advRun.col.push(rng.pick(cc));
  for(let i=0;i<4;i++) advRun.col.push(rng.pick(cu));
  for(let i=0;i<10;i++) advRun.col.push(rng.pick(nc));
  advRun.col.push(AN.makeAnomaly(rng, 1, null));
  advRun.col.push(AN.makeAnomaly(rng, 2, null));
  advAutoDeck(); advGenChoices(); advSave();
}
function advArea(){ return advRun.areaIdx<advRun.areas.length ? advRun.areas[advRun.areaIdx] : null; }
function advExtra(){ return Math.max(0, advRun.areas.length-3); }
function advSeals(){ return Math.max(0,(advRun.bossWins||0)-3); }
function advGenChoices(){
  const rng=advRng('choice'); const f=advRun.floor;
  if(advRun.areaIdx>=advRun.areas.length){ advRun.choices=['final','continue']; return; }
  if(f>=5){ advRun.choices=['boss']; return; }
  const bag=['battle','battle','battle','elite','shop','inn','event','event'];
  const n= f===0 ? 2 : 3; const out=['battle'];
  if(f===0){ out.push(rng.pick(['event','shop','elite'])); advRun.choices=rng.shuffle(out); return; }
  while(out.length<n){ const t=rng.pick(bag); if(t==='battle' && out.filter(x=>x==='battle').length>=2) continue; if(t!=='battle' && out.includes(t)) continue; out.push(t); }
  advRun.choices=rng.shuffle(out);
}
const ADV_NODE={ battle:{n:'戦闘',i:'sword',d:'この地の住人と戦う。勝てば賭けたカードとゴールド。'}, elite:{n:'強敵',i:'helm',d:'手強い相手。この地の力（属性+1/+1）を受ける。勝てばカードを1枚選べる。'}, shop:{n:'店',i:'barrel',d:'カードを買う・売る。'}, inn:{n:'宿',i:'lantern',d:'休んでハートを回復する。'}, event:{n:'謎の出来事',i:'eye',d:'何かが起きる。'}, boss:{n:'地域の主',i:'crown',d:'この地域の主。強化されたリーダー能力を持つ。倒せば次の地域へ。'}, final:{n:'歪みの果てへ',i:'darkcrown',d:'すべての歪みを喰らう者が待つ。最終決戦。'}, continue:{n:'さらに旅を続ける',i:'runner',d:'まだ訪れていない地域へ（あと数回まで）。デッキを鍛えられるが、敵は強くなり、ハートを失う危険もある。最終ボスの強さは変わらない。'} };

// ---------- 画面：開始 ----------
let advDiffSel=0; // 開始画面で選んだ難易度（0＝ノーマル、1＝ハード）
function renderAdvStart(){
  const s=screenEl('advStart'); const saved=advLoad(); const rec=advRecord(); const nextLoop=rec.hard+1;
  s.innerHTML='<div class="topbar"><button class="ghost" id="back">←</button><div class="t">冒険モード</div></div><div class="scroll wrap">'
   +'<div class="sub" style="line-height:1.8">1人用の冒険です。最初の色のカードを持って旅立ち、3つの地域を巡って「歪みの果て」を目指します。戦闘に勝つと、あなたのデッキの色のカードから1枚を選んで手に入れられます。負けるとハートが1つ減り、0になると冒険は終わりです。道中の出来事には、うまい話も危険もあります。</div>'
   +(saved?'<div class="menu"><button class="primary" id="cont">続きから（'+(saved.hard?'ハード'+saved.hard+'周目・':'')+esc(ADV_AREA[saved.areas[Math.min(saved.areaIdx,saved.areas.length-1)]].name)+'・所持金'+saved.gold+'G・ハート'+saved.hearts+'）</button></div><div class="field-label" style="margin-top:20px">新しく始める（今の冒険は失われます）</div>':'')
   +'<div class="field-label" style="margin-top:14px">難易度</div><div class="seg" id="segD"><button data-v="0" class="'+(advDiffSel?'':'on')+'">ノーマル</button><button data-v="1" class="'+(advDiffSel?'on':'')+'">ハード'+(nextLoop>1?'（'+nextLoop+'周目）':'')+'</button></div>'
   +'<div class="sub advdiff">'+(advDiffSel?'敵は常に強いCPU。通常戦闘の敵はデッキが1段強く、強敵・地域の主・最終ボスは敵のクリーチャーだけ体力+1。封印の効き目は3分の2。報酬のゴールドは+25%。ハードを制覇するたびに周回が進み、最終ボスはさらに強くなります。':'はじめての方はこちら。')
     +(rec.normal||rec.hard?'<br>記録：ノーマル制覇 '+rec.normal+'回'+(rec.hard?' ・ ハード '+rec.hard+'周目まで制覇':''):'')+'</div>'
   +'<div class="field-label" style="margin-top:14px">最初の色を選ぶ</div>'
   +'<div class="advcolors">'+AN.ATTR_ORDER.map(a=>'<button data-c="'+a+'" style="--ac:'+AN.ATTRS[a].c+'"><span class="ico">'+AN.iconSvg({i:ADV_AREA[a].icon})+'</span>'+AN.ATTRS[a].n+'<small>'+AN.ATTRS[a].k+'</small></button>').join('')+'</div></div>';
  s.querySelector('#back').onclick=()=>show('title');
  s.querySelectorAll('#segD button').forEach(b=>b.onclick=()=>{ advDiffSel=+b.dataset.v; renderAdvStart(); });
  const c=s.querySelector('#cont'); if(c) c.onclick=()=>{ advRun=saved; const m={ante:'advAnte',event:'advEvent',shop:'advShop',inn:'advInn',reward:'advReward'}; show((advRun.stage==='battle')?'advAnte':(m[advRun.stage]||'advMap')); };
  s.querySelectorAll('.advcolors button').forEach(b=>b.onclick=()=>{ const go=()=>{ advNewRun(b.dataset.c, advDiffSel?nextLoop:0); show('advMap'); }; if(saved) askConfirm('今の冒険を捨てて、'+AN.ATTRS[b.dataset.c].n+'で新しく始めますか？（今の冒険は失われます）','新しく始める',go); else go(); });
}
function advHeader(){
  const a=advArea(); const A=a?ADV_AREA[a]:null;
  return '<div class="advhead'+(a?' hasbg':'')+'" style="--ac:'+(a?AN.ATTRS[a].c:'#C58CFF')+(a?';--art:url('+ART('region_'+a)+')':'')+'"><div class="an">'+(A?esc(A.name)+' ・ '+(advRun.floor<5?(advRun.floor+1)+'階':'主の間'):'歪みの果て')+'</div><div class="st">♥'+'♥'.repeat(Math.max(0,advRun.hearts-1))+'<span class="lost">'+'♡'.repeat(advRun.maxHearts-advRun.hearts)+'</span>　'+advRun.gold+'G　所持'+advRun.col.length+'枚</div>'
   +(advLoop()?'<div class="buff" style="color:#FF8A7A">ハード '+advLoop()+'周目</div>':'')
   +(advSeals()?'<div class="buff" style="color:#C58CFF">歪みの封印：'+advSeals()+(advLoop()?'（ハードでの効き目 '+advSealEff()+'）':'')+'</div>':'')
   +(a&&advRun.areaIdx>0?'<div class="buff">強敵との戦いでは、'+AN.ATTRS[a].n+'属性のクリーチャーが+1/+1</div>':(a?'<div class="buff">最初の地域では、まだ地域の力は働かない</div>':''))+'</div>';
}
// ---------- 画面：地図（分かれ道） ----------
function renderAdvMap(){
  if(!advRun){ show('advStart'); return; }
  advRun.stage='map'; if(!advRun.choices) advGenChoices(); advEnsureDeck(); advSave();
  const s=screenEl('advMap');
  const startI=Math.max(0, advRun.areas.length-5);
  const prog=(startI>0?'<i>…</i>':'')+advRun.areas.map((x,i)=>i).filter(i=>i>=startI).map(i=>'<span class="'+(i<advRun.areaIdx?'done':(i===advRun.areaIdx?'now':''))+'" style="--ac:'+AN.ATTRS[advRun.areas[i]].c+'">'+AN.ATTRS[advRun.areas[i]].n+'</span>').join('<i>›</i>')+'<i>›</i><span class="'+(advRun.areaIdx>=advRun.areas.length?'now':'')+'" style="--ac:#C58CFF">？</span>';
  s.innerHTML='<div class="topbar"><button class="ghost" id="back">←</button><div class="t">冒険</div><button class="ghost" id="deck">デッキ</button></div>'
   +advHeader()+'<div class="scroll wrap"><div class="advprog">'+prog+'</div><div class="field-label">次に進む道を選んでください</div>'
   +'<div class="advnodes">'+advRun.choices.map((t,i)=>{ const N=ADV_NODE[t]; const d = (t==='final'&&advLoop()) ? '光と闇、二つの冠を戴く者が待つ。最終決戦。'+(advSeals()?'　封印'+advSeals()+'：その力は削がれている。':'') : t==='continue' ? '別の地域へ（何度でも）。デッキを鍛えられ、地域の主を倒すたびに歪みを1つ封印して万象喰らいの力を削げる。ただし敵は手強く、ハートを失う危険もある。' : (t==='final' ? N.d+(advSeals()?'　封印'+advSeals()+'：その力は削がれている。':'') : N.d); return '<button data-i="'+i+'"><span class="ico">'+AN.iconSvg({i:N.i})+'</span><b>'+N.n+'</b><small>'+d+'</small></button>'; }).join('')+'</div>'
   +'<div class="sub" style="margin-top:14px">デッキ：30枚・属性は2つまで（無属性とアノマリーは自由）。戦闘前でもいつでも組み替えられます。</div></div>';
  s.querySelector('#back').onclick=()=>show('title');
  s.querySelector('#deck').onclick=()=>show('advDeck');
  s.querySelectorAll('.advnodes button').forEach(b=>b.onclick=()=>advGo(advRun.choices[+b.dataset.i]));
}
function advContinue(){
  const unvisited=AN.ATTR_ORDER.filter(a=>!advRun.areas.includes(a) && a!==advRun.start);
  const rng=advRng('cont');
  const last=advRun.areas[advRun.areas.length-1];
  const next = unvisited.length ? unvisited[0] : (!advRun.areas.includes(advRun.start) ? advRun.start : rng.pick(AN.ATTR_ORDER.filter(a=>a!==last)));
  advRun.areas.push(next); advRun.floor=0; advRun.choices=null; advGenChoices(); advSave();
  toast(ADV_AREA[next].name+'へ向かう');
  show('advMap');
}
function advNext(){ advRun.floor++; advRun.choices=null; advRun.shop=null; advRun.event=null; advRun.picks=null; if(advRun.floor>5){ advRun.areaIdx++; advRun.floor=0; } advGenChoices(); advSave(); show('advMap'); }
function advGo(t){
  if(t==='continue') return advContinue();
  if(t==='battle'||t==='elite'||t==='boss'||t==='final') return advPrepBattle(t);
  if(t==='shop'){ advMakeShop(); advRun.stage='shop'; advSave(); return show('advShop'); }
  if(t==='inn'){ advRun.stage='inn'; advSave(); return show('advInn'); }
  if(t==='event'){ advRun.event=advPickEvent(); advRun.stage='event'; advSave(); return show('advEvent'); }
}
// ---------- 敵 ----------
function advMakeEnemy(kind, strong){
  const rng=advRng('enemy'); const ai=Math.min(2, advRun.areaIdx+(strong?1:0)); const a=advArea(); const xl=Math.min(3, Math.max(0,advRun.areaIdx-2)*3);
  if(kind==='final' && advLoop()){
    // v3.14 ハードの最終ボス：光と闇の双冠を戴く者。能力はプレイヤーには伏せる
    let pool=[]; AN.CARDS.forEach(d=>{ if(d.attr.includes('void')||d.attr.includes('ray')||d.attr.length===0){ const k=d.rarity==='L'?1:2; for(let i=0;i<k;i++) pool.push(d); } });
    const vals=d=>AN.cardValue(d)/Math.max(1,d.cost)*(d.cost<=4?1.15:1)+rng()*0.4;
    pool.sort((a,b)=>vals(b)-vals(a));
    const sl=advSealEff(), FS=advFinalScale();
    const an=[AN.makeLegend(rng,1700),AN.makeAnomaly(rng,1704,null),AN.makeAnomaly(rng,1705,null)].slice(0, Math.max(0,3-sl));
    for(let k=0;k<FS.xl;k++) an.push(AN.makeLegend(rng,1800+k*3));
    const commons=AN.CARDS.filter(d=>(d.attr.includes('void')||d.attr.includes('ray'))&&d.rarity==='C');
    const nC=Math.min(27, sl*3);
    const deck=an.concat(pool.slice(12, 12+(30-an.length)-nC)).concat(Array.from({length:nC},()=>rng.pick(commons)));
    const rules = sl>=6 ? null : (sl>=4 ? {mirror:4} : {mirror:3, phase:15, phaseLeader:'judge'});
    return { name:'双冠の審判者 ルクス＝ノクティア', attr:'ray', icon:'halo', life:Math.max(12,30-3*sl)+FS.life, leader:null, energy:FS.energy, buff:FS.buff, level:3, deck:deck.slice(0,30), final:true, secret:true, hardFinal:true, rules, kind };
  }
  if(kind==='final'){
    let pool=[]; AN.CARDS.forEach(d=>{ if(d.attr.includes('void')||d.attr.includes('flare')||d.attr.length===0){ const k=d.rarity==='L'?1:2; for(let i=0;i<k;i++) pool.push(d); } });
    const vals=d=>AN.cardValue(d)/Math.max(1,d.cost)*(d.cost<=4?1.15:1)+rng()*0.4;
    pool.sort((a,b)=>vals(b)-vals(a));
    // v3.9.1: 封印（3体目以降に倒した地域の主の数）ごとに力が削がれる
    const sl=advSealEff(), FS=advFinalScale();
    const an=[AN.makeLegend(rng,1500),AN.makeAnomaly(rng,1504,null),AN.makeAnomaly(rng,1505,null)].slice(0, Math.max(0,3-sl));
    for(let k=0;k<FS.xl;k++) an.push(AN.makeLegend(rng,1600+k*3));
    const commons=AN.CARDS.filter(d=>(d.attr.includes('void')||d.attr.includes('flare'))&&d.rarity==='C');
    const nC=Math.min(27, sl*3);
    const deck=an.concat(pool.slice(12, 12+(30-an.length)-nC)).concat(Array.from({length:nC},()=>rng.pick(commons)));
    const rules = sl>=6 ? null : (sl>=4 ? {devour:true} : {devour:true, phase:15});
    return { name:'万象喰らい ザルヴァ＝ネクス', attr:'void', life:Math.max(12,30-3*sl)+FS.life, leader:null, energy:FS.energy, buff:FS.buff, level:3, deck:deck.slice(0,30), final:true, secret:true, rules, kind };
  }
  const A=ADV_AREA[a];
  // v3.8: 最初の地域は、敵も初期デッキと同じ作り方（ランダムなコモン中心・選り好みなし）にし、階が進むほど少しずつ強くする
  if(advRun.areaIdx===0 && !strong){
    const floor=advRun.floor;
    const cc=advPool(a,['C']), cu=advPool(a,['U']), nc=advPool(null,['C']);
    const nu = kind==='elite'?4:(kind==='boss'?3:Math.round(2*Math.min(1,floor/5)));
    const deck=[]; for(let k=0;k<30-nu-8;k++) deck.push(rng.pick(cc)); for(let k=0;k<nu;k++) deck.push(rng.pick(cu)); for(let k=0;k<8;k++) deck.push(rng.pick(nc));
    if(kind==='elite') deck[0]=AN.makeAnomaly(rng,701,null);
    const HM=advHardMods(kind, false);
    const life = (kind==='battle' ? 16+Math.floor(floor/2) : 20) + (HM?HM.life:0);
    const level = HM ? HM.level : (kind==='battle' ? (floor<=2?1:2) : (kind==='boss'?3:2));
    return { name: kind==='boss'?A.boss:(kind==='elite'?A.elite:rng.pick(A.enemies)), attr:a, life, leader: kind==='boss'?A.bossLeader:null, energy:0, level, deck, kind, buff:HM?HM.buff:null };
  }
  // v3.5: 地域の主は通常戦闘と同じデッキ強度・ライフで、リーダー能力だけが強化されている
  const HM=advHardMods(kind, strong);
  const tiers={battle:[['C'],['C','U'],['C','U','R']], elite:[['C','U'],['C','U','R'],['C','U','R','L']], boss:[['C'],['C','U'],['C','U','R']]}[kind][HM&&HM.tierUp?Math.min(2,ai+1):ai];
  let pool=[]; AN.CARDS.forEach(d=>{ if((d.attr.includes(a)||d.attr.length===0) && tiers.includes(d.rarity)) pool.push(d); });
  pool=rng.shuffle(pool.concat(pool)).slice(0, 50);
  const nAn = kind==='elite' ? 1 : (ai>=1?1:0);
  for(let i=0;i<nAn;i++) pool.unshift(AN.makeAnomaly(rng, 701+i*3, null));
  if(strong) pool.unshift(AN.makeLegend(rng, 760));
  const deck=AN.AI.autoDeck(pool, rng, a);
  while(deck.length<30) deck.push(rng.pick(pool));
  const life = (kind==='elite' ? 25+ai*3 : 20+ai*3) + (strong?5:0) + xl + (HM?HM.life:0);
  return { name: strong? rng.pick(['さすらいの剣豪','古き魔導王','放浪の竜騎士','影を連れた旅人']) : kind==='boss'?A.boss:(kind==='elite'?A.elite:rng.pick(A.enemies)), attr:a, life, strong:!!strong, leader: kind==='boss'?A.bossLeader:null, energy:0, level: HM?3:(kind==='battle'&&ai===0?2:3), deck, kind, buff:HM?HM.buff:null };
}
function advPrepBattle(kind, opt){
  opt=opt||{};
  const en=advMakeEnemy(kind, opt.strong);
  advRun.pending={ kind, en, bonus:opt.bonus||0, rewardKind: opt.strong?'champion':kind };
  advRun.stage='ante'; advSave(); show('advAnte');
}
function advRewardText(rk){ return ({battle:'カード1枚（あなたの色のコモン〜アンコモンから3枚提示）',elite:'カード1枚（あなたの色のアンコモン〜レアから3枚提示）',boss:'地域の主の秘宝（冒険限定の強力なカード）＋カード1枚（あなたの色のレア〜レジェンドと伝説のアノマリーから3枚提示）',champion:'カード1枚（あなたの色のレア〜レジェンドと伝説のアノマリーから3枚提示）'})[rk]||''; }
function advGoldFor(P){ const ai=advRun.areaIdx; return Math.round(((P.kind==='battle' ? 25+ai*10 : P.kind==='elite' ? 50+ai*15 : P.kind==='boss' ? 100 : 0) + (P.bonus||0)) * (advLoop()?1.25:1)); } // ハードは報酬のゴールド+25%
function advMyColors(){ const st=new Set(advAttrs(advDeckDefs())); st.add(advRun.start); return [...st]; }
function advRewardPicks(rk, rng){
  const cols=advMyColors();
  const rars = rk==='battle'?['C','U'] : rk==='elite'?['U','R'] : ['R','L'];
  let pool=[]; cols.forEach(a=>{ pool=pool.concat(advPool(a,rars)); }); pool=pool.concat(advPool(null,rars));
  const out=[]; const seen=new Set();
  for(let k=0;k<40 && out.length<3;k++){ const d=rng.pick(pool); if(seen.has(d.id)) continue; seen.add(d.id); out.push(d); }
  if(rk==='boss'||rk==='champion') out[2]=AN.makeLegend(rng, 800+advRun.counter);
  return out;
}
function renderAdvAnte(){
  const P=advRun.pending; if(!P){ show('advMap'); return; }
  const s=screenEl('advAnte');
  const a=P.en.attr; const buff = a && P.kind==='elite' && advRun.areaIdx>0;
  const pk = P.en.hardFinal?'boss_judge':(P.en.final?'boss_devourer':(P.kind==='boss'&&a?'lord_'+a:null));
  s.innerHTML=advHeader()+'<div class="scroll wrap" style="text-align:center">'
   +(pk?'<div class="advport'+(P.en.final?' final':'')+'" style="--ac:'+(a?AN.ATTRS[a].c:'#C58CFF')+'"><img src="'+ART(pk)+'" alt="" onerror="this.parentNode.remove()"></div>':'')
   +'<div class="advfoe" style="--ac:'+(a?AN.ATTRS[a].c:'#C58CFF')+'"><span class="ico">'+AN.iconSvg({i:P.en.icon?P.en.icon:P.kind==='boss'?'crown':(P.en.strong?'knight':(P.kind==='elite'?'helm':(P.en.final?'darkcrown':'soldier')))})+'</span><div><div class="fn">'+esc(P.en.name)+'</div><div class="sub">'
   +(P.en.secret?'最終決戦 ・ '+(advLoop()?'ハード'+advLoop()+'周目の力 ・ ':'')+(advSeals()?'封印'+advSeals()+'により、その力は削がれている':'その力は計り知れない'):(({battle:'',elite:'強敵 ・ ',boss:'地域の主 ・ ',final:'最終決戦 ・ '}[P.kind])+(P.en.strong?'さすらいの強者 ・ ':'')+'ライフ'+P.en.life+(P.en.leader?' ・ 能力「'+esc(AN.LEADER_EX[P.en.leader].name)+'」':'')))+'</div></div></div>'
   +(buff?'<div class="sub" style="margin-bottom:8px;color:#FFD86B">この戦いでは'+AN.ATTRS[a].n+'属性のクリーチャーが敵味方とも+1/+1</div>':'')
   +(advLoop()&&!P.en.secret?(()=>{ const HM=advHardMods(P.kind,P.en.strong); const t=['強いCPU','ライフ+'+HM.life]; if(HM.tierUp&&advRun.areaIdx>0) t.push('デッキが1段強い'); if(P.en.buff) t.push('敵のクリーチャーだけ体力+1'); return '<div class="sub" style="margin-bottom:8px;color:#FF8A7A">ハード：'+t.join('・')+'</div>'; })():'')
   +(P.kind!=='final'?'<div class="advreward"><b>勝利報酬</b><div>'+advGoldFor(P)+'G ・ '+advRewardText(P.rewardKind)+'</div><div class="sub">負けるとハートが1つ減ります（カードは失いません）</div></div>':'')
   +'<div class="menu"><button class="primary" id="fight">戦う</button><button class="ghost" id="deck">デッキを確認</button></div></div>';
  s.querySelector('#fight').onclick=advFight;
  s.querySelector('#deck').onclick=()=>show('advDeck');
}
function advFight(){
  const P=advRun.pending; if(!P) return;
  advEnsureDeck();
  const myDefs=advDeckDefs(); const myMain=advMain(myDefs);
  const a=advArea(); const buffOn = a && P.kind==='elite' && advRun.areaIdx>0;
  series={ adv:true, online:null, boss:null, level:P.en.level, wins:[0,0], gameNo:1, format:1, mains:[myMain,P.en.attr], pools:[[],[]], decks:[[],[]] };
  ui.me=0;
  game=new AN.Game({ seed:advRun.seed+':g'+advRng('g')(), decks:[myDefs, P.en.deck], names:['あなた', P.en.name], mains:[myMain, P.en.attr], choosers:[null, AN.AI.chooser(P.en.level)],
    lifes:[0,P.en.life], leaders:[null,P.en.leader], energyBonus:[0,P.en.energy], sideBuff:[null,P.en.buff||null], fieldBuff: buffOn?{attr:a,n:1}:null, bossRules: P.en.final?[null,P.en.rules]:null });
  if(buffOn) game.say('この地の力：'+AN.ATTRS[a].n+'属性のクリーチャーは+1/+1','turn');
  if(P.en.buff) game.say('ハード：'+P.en.name+'のクリーチャーは'+(P.en.buff.atk?'+'+P.en.buff.atk:'+0')+'/+'+P.en.buff.hp+(P.en.energy?'、最大エナジー+'+P.en.energy:''),'turn');
  game.uiPause=true;
  ui.attackFrom=null; evSeen=0; ui.mullSel=new Set();
  game.mulligan(game.players[1], AN.AI.mullPick(game,1));
  advRun.stage='battle'; advSave();
  show('battle'); scheduleCpu();
}
function advFinish(winner){
  const P=advRun.pending; const won=winner===0;
  let gold=0;
  let treasure=null;
  if(won){ advRun.wins++; gold=advGoldFor(P); advRun.gold+=gold; if(P.kind!=='final') advRun.picks=advRewardPicks(P.rewardKind, advRng('reward')); if(P.kind==='boss'){ advRun.bossWins=(advRun.bossWins||0)+1; const tid=ADV_AREA[P.en.attr].treasure; if(advRun.col.some(d=>d.id===tid)){ advRun.gold+=100; gold+=100; } else { advRun.col.push(AN.CARD_BY_ID[tid]); treasure=tid; } } }
  else { advRun.losses++; advRun.hearts--; }
  advRun.pending=null; advRun.lastResult={ won, kind:P.kind, gold, final:P.kind==='final', treasure };
  advRun.stage='reward'; advSave();
  show('advReward');
}
function renderAdvReward(){
  const R=advRun.lastResult; if(!R){ show('advMap'); return; }
  if(!R.won && advRun.hearts<=0){ return advEnd(false); }
  if(R.won && R.final){ return advEnd(true); }
  const s=screenEl('advReward');
  s.innerHTML=advHeader()+'<div class="scroll wrap" style="text-align:center"><div class="big" style="font-family:var(--disp);font-size:30px;color:'+(R.won?'#7be0b0':'#f28f8f')+';margin:10px 0">'+(R.won?'勝利':'敗北')+'</div>'
   +(R.won?'<div class="sub">'+R.gold+'Gを得た</div>':'<div class="sub">ハートが1つ減った</div>')
   +(R.treasure?'<div class="field-label" style="margin-top:12px;color:#FFD86B">地域の主の秘宝を手に入れた！</div><div class="picks" id="trs"></div>':'')
   +(advRun.picks&&R.won?'<div class="field-label" style="margin-top:14px">報酬：1枚選んで持ち帰る</div><div class="picks" id="picks"></div>':'')
   +'<div class="menu" style="margin-top:16px"><button class="'+(advRun.picks&&R.won?'ghost':'primary')+'" id="next">'+(advRun.picks&&R.won?'選ばずに進む':'先へ進む')+'</button></div></div>';
  if(R.treasure){ const d=AN.CARD_BY_ID[R.treasure]; const e=cardEl(d,{}); e.onclick=()=>cardSheet(d,{},[]); s.querySelector('#trs').appendChild(e); }
  if(advRun.picks&&R.won){ const pk=s.querySelector('#picks'); advRun.picks.forEach(d=>{ const e=cardEl(d,{}); e.onclick=()=>cardSheet(d,{},[{label:'これを選ぶ',cls:'primary',fn:()=>{ advRun.col.push(d); advRun.picks=null; advAfterReward(R); }}]); pk.appendChild(e); }); }
  s.querySelector('#next').onclick=()=>{ advRun.picks=null; advAfterReward(R); };
}
function advAfterReward(R){ advRun.lastResult=null; advEnsureDeck(); if(!R.won){ advRun.choices=null; advGenChoices(); advRun.stage='map'; advSave(); show('advMap'); return; } advNext(); }
function advEnd(victory){
  const s=screenEl('advEnd'); const r=advRun; const L=r.hard||0;
  if(victory){ const rec=advRecord(); if(L) rec.hard=Math.max(rec.hard,L); else rec.normal++; advSaveRecord(rec); }
  s.innerHTML='<div class="result"><div class="big" style="color:'+(victory?'#FFD86B':'#f28f8f')+'">'+(victory?(L?'双冠を砕いた':'歪みの果てを制覇'):'冒険の終わり')+'</div><div class="sub">'+(victory?(L?'光と闇の審判は終わり、歪みの玉座は空になった。':'すべての歪みを鎮め、あなたの名は語り継がれる。'):'ハートが尽きた。')+'</div>'+(L?'<div class="sub" style="color:#FF8A7A">ハード '+L+'周目'+(victory?'を制覇。次の周回では、審判者がさらに強くなって待っている。':'')+'</div>':'')+(victory&&!L?'<div class="sub">冒険モードの開始画面で「ハード」を選べます。</div>':'')+'<div class="sub">勝利 '+r.wins+' ・ 敗北 '+r.losses+' ・ 所持カード '+r.col.length+'枚 ・ '+r.gold+'G</div><div class="menu" style="width:100%;max-width:320px"><button class="primary" id="home">タイトルへ</button></div></div>';
  advClear(); advRun=null;
  s.querySelector('#home').onclick=()=>show('title');
}
// ---------- 店 ----------
function advMakeShop(){
  const rng=advRng('shop'); const mine=advMyColors(); const area=advArea()||rng.pick(AN.ATTR_ORDER);
  const rr=()=>{ const r=rng()*100; return r<45?'C':r<80?'U':r<95?'R':'L'; };
  const pick=(attr)=>{ const k=rr(); const p=advPool(attr,[k]); return p.length?rng.pick(p):rng.pick(advPool(attr,['C'])); };
  const items=[pick(rng.pick(mine)),pick(rng.pick(mine)),pick(rng.pick(mine)),pick(rng.pick(mine)),pick(null),pick(area)];
  if(rng()<0.35) items.push(AN.makeAnomaly(rng, 900, null));
  advRun.shop=items.map(d=>({d, price:ADV_PRICE[d.anomaly?'A':d.rarity], sold:false}));
}
function renderAdvShop(){
  if(!advRun.shop) advMakeShop();
  const s=screenEl('advShop');
  s.innerHTML=advHeader()+'<div class="scroll wrap"><div class="advscene"><span class="ico">'+AN.iconSvg({i:'barrel'})+'</span><div>旅の商人の店。「あんたの好みはだいたい分かるよ」</div></div>'
   +'<div class="field-label">買う（タップで詳細）</div><div class="grid" id="buy"></div>'
   +'<div class="field-label">売る（デッキに入っていないカードを半額で）</div><div class="grid" id="sell"></div>'
   +'<div class="menu"><button class="primary" id="leave">店を出る</button></div></div>';
  const buy=s.querySelector('#buy');
  advRun.shop.forEach(o=>{ const w=document.createElement('div'); w.className='pcard'+(o.sold?' out':''); w.appendChild(cardEl(o.d,{})); w.innerHTML+='<div class="price">'+(o.sold?'売約済':o.price+'G')+'</div>'; w.onclick=()=>{ if(o.sold) return cardSheet(o.d,{},[]); cardSheet(o.d,{},[{label:o.price+'Gで買う',cls:'primary',disabled:advRun.gold<o.price,fn:()=>{ advRun.gold-=o.price; o.sold=true; advRun.col.push(o.d); advSave(); renderAdvShop(); }}]); }; buy.appendChild(w); });
  const sell=s.querySelector('#sell');
  advRun.col.forEach((d,i)=>{ if(advRun.deck.includes(i)) return; const p=Math.floor(ADV_PRICE[d.anomaly?'A':d.rarity]/2); const w=document.createElement('div'); w.className='pcard'; w.appendChild(cardEl(d,{})); w.innerHTML+='<div class="price">'+p+'G</div>'; w.onclick=()=>cardSheet(d,{},[{label:p+'Gで売る',cls:'primary',fn:()=>{ advRun.gold+=p; advRemoveCol(i); advSave(); renderAdvShop(); }}]); sell.appendChild(w); });
  if(!sell.children.length) sell.innerHTML='<div class="sub">デッキ外のカードがありません</div>';
  s.querySelector('#leave').onclick=()=>advNext();
}
// ---------- 宿 ----------
function renderAdvInn(){
  const s=screenEl('advInn'); const cost=30;
  s.innerHTML=advHeader()+'<div class="scroll wrap" style="text-align:center"><div class="advscene big"><span class="ico">'+AN.iconSvg({i:'lantern'})+'</span><div>小さな宿屋。暖炉の火が揺れている。</div></div>'
   +'<div class="menu"><button class="primary" id="rest" '+(advRun.hearts>=advRun.maxHearts||advRun.gold<cost?'disabled':'')+'>泊まる（'+cost+'G・ハート+1）</button><button id="deck">デッキを組み直す</button><button class="ghost" id="leave">発つ</button></div>'
   +(advRun.hearts>=advRun.maxHearts?'<div class="sub">ハートは満タンです</div>':'')+'</div>';
  s.querySelector('#rest').onclick=()=>{ advRun.gold-=cost; advRun.hearts=Math.min(advRun.maxHearts,advRun.hearts+1); advSave(); toast('ハートが回復した'); advNext(); };
  s.querySelector('#deck').onclick=()=>show('advDeck');
  s.querySelector('#leave').onclick=()=>advNext();
}
// ---------- 謎の出来事 ----------
const ADV_EVENTS=[
  { key:'altar', icon:'gate', title:'古い祭壇', text:'苔むした祭壇が脈打っている。血を捧げれば、歪みの力を授けるという。', choices:[
    { label:'ハートを1つ捧げる', ok:r=>r.hearts>1, run:(r,rng)=>{ r.hearts--; const d=AN.makeLegend(rng,1200); r.col.push(d); return {msg:'ハートを1つ失い、伝説のアノマリーを授かった。', card:d}; } },
    { label:'立ち去る', run:()=>({msg:'あなたは祭壇に背を向けた。'}) } ] },
  { key:'chest', icon:'barrel', title:'古びた宝箱', text:'道の脇に宝箱が転がっている。どこか、呼吸しているようにも見える。', choices:[
    { label:'開ける', run:(r,rng)=>{ if(rng()<0.4){ return {msg:'宝箱は魔物だった！　倒せば中身は手に入る。', fight:{kind:'elite', bonus:60}}; } const g=50+rng.int(41); r.gold+=g; return {msg:g+'Gを見つけた。'}; } },
    { label:'放っておく', run:()=>({msg:'触らぬ神に祟りなし。'}) } ] },
  { key:'merchant', icon:'scroll', title:'行商人', text:'「掘り出し物があるよ。今日だけ半額だ」', offer:true, choices:[
    { label:'買う', ok:(r,o)=>r.gold>=o.price, run:(r,rng,o)=>{ r.gold-=o.price; r.col.push(o.d); return {msg:'「毎度あり」', card:o.d}; } },
    { label:'断る', run:()=>({msg:'行商人は肩をすくめた。'}) } ] },
  { key:'spring', icon:'drop', title:'冷たい泉', text:'澄んだ泉が湧いている。飲めば傷は癒えるが、水底が財布を引きずり込むという言い伝えがある。', choices:[
    { label:'飲む（ハート+1・所持金が半分に）', ok:r=>r.hearts<r.maxHearts, run:(r)=>{ r.hearts=Math.min(r.maxHearts,r.hearts+1); const lost=Math.floor(r.gold/2); r.gold-=lost; return {msg:'ハートが1つ回復した。'+lost+'Gが泉に沈んだ。'}; } },
    { label:'やめておく', run:()=>({msg:'あなたは泉を後にした。'}) } ] },
  { key:'mirror', icon:'mirror', title:'呪いの鏡', text:'覗き込むと、手持ちのカードが歪んで見える。何に変わるかは分からない。', choices:[
    { label:'覗き込む', run:(r,rng)=>{ const idx=r.col.map((d,i)=>i).filter(i=>!r.col[i].anomaly); if(!idx.length) return {msg:'何も起きなかった。'}; const i=rng.pick(idx); const old=r.col[i]; const d=AN.makeAnomaly(rng,1300+r.counter,null); r.col[i]=d; return {msg:'「'+old.name+'」が歪み、アノマリーに変わった。', card:d}; } },
    { label:'鏡を割る', run:(r)=>{ r.gold+=20; return {msg:'破片の中から20Gが出てきた。'}; } } ] },
  { key:'library', icon:'book', title:'禁書庫', text:'鎖でつながれた書物の間に、カードが挟まっている。持ち出せば、番人が黙ってはいないだろう。', pick3:true, choices:[] },
  { key:'champion', icon:'knight', title:'さすらいの強者', text:'道の真ん中に、只者ではない気配の旅人が立っている。「腕試しはどうだ。勝てば良いものをやろう」', choices:[
    { label:'挑む（手強い。勝てば大きな報酬）', run:()=>({msg:'旅人は静かに構えた。', fight:{kind:'elite', strong:true, bonus:80}}) },
    { label:'会釈して通り過ぎる', run:()=>({msg:'旅人は小さく笑って道を譲った。'}) } ] },
  { key:'bandits', icon:'mask', title:'野盗', text:'「ここを通りたけりゃ、通行料を置いていきな」', choices:[
    { label:'40G払う', ok:r=>r.gold>=40, run:(r)=>{ r.gold-=40; return {msg:'野盗は金を数えながら去っていった。'}; } },
    { label:'戦う', run:()=>({msg:'「身の程を教えてやる！」', fight:{kind:'battle', bonus:30}}) } ] },
  { key:'blade', icon:'sword', title:'呪われた武器庫', text:'錆びた武器の山の中に、強い力を放つカードがある。触れた者の命を削るという。', choices:[
    { label:'手に取る（ハート-1）', ok:r=>r.hearts>1, run:(r,rng)=>{ r.hearts--; const cols=advMyColors(); let pool=[]; cols.forEach(a=>{ pool=pool.concat(advPool(a,['R','L'])); }); const d=rng.pick(pool); r.col.push(d); return {msg:'ハートを1つ失ったが、「'+d.name+'」を手に入れた。', card:d}; } },
    { label:'立ち去る', run:()=>({msg:'あなたは武器庫を後にした。'}) } ] },
];
function advPickEvent(){
  const rng=advRng('event'); const e=rng.pick(ADV_EVENTS); const ev={key:e.key};
  const cols=advMyColors();
  if(e.offer){ let p=[]; cols.forEach(a=>{ p=p.concat(advPool(a,['R'])); }); const d=rng.pick(p); ev.offer={d:d.id, price:Math.floor(ADV_PRICE.R/2)}; }
  if(e.pick3){ let p=[]; cols.forEach(a=>{ p=p.concat(advPool(a,['U','R'])); }); p=p.concat(advPool(null,['R'])); ev.pick=[rng.pick(p).id,rng.pick(p).id,rng.pick(p).id]; }
  return ev;
}
function renderAdvEvent(){
  const ev=advRun.event; if(!ev){ advNext(); return; }
  const E=ADV_EVENTS.find(x=>x.key===ev.key); if(!E){ advNext(); return; }
  const s=screenEl('advEvent');
  const offer=ev.offer?{d:AN.CARD_BY_ID[ev.offer.d], price:ev.offer.price}:null;
  s.innerHTML=advHeader()+'<div class="scroll wrap" style="text-align:center"><div class="advscene big'+(ADV_EV_ART[E.key]?' hasimg':'')+'">'+(ADV_EV_ART[E.key]?'<img class="evimg" src="'+ART(ADV_EV_ART[E.key])+'" alt="" onerror="this.parentNode.classList.remove(\'hasimg\');this.remove()">':'')+'<span class="ico">'+AN.iconSvg({i:E.icon})+'</span><div class="et">'+esc(E.title)+'</div><div>'+esc(E.text)+'</div></div>'
   +(ev.done?'<div class="evmsg">'+esc(ev.done.msg)+'</div><div class="picks" id="evcard"></div><div class="menu"><button class="primary" id="go">'+(ev.done.fight?'戦う':'先へ進む')+'</button></div>':
     (offer?'<div class="picks" id="offer"></div><div class="sub">'+offer.price+'G</div>':'')+(E.pick3?'<div class="sub" style="margin:6px 0">1枚を選ぶと番人（強敵）との戦闘になります。負けてもカードは手元に残ります。</div><div class="picks" id="pk3"></div><div class="menu"><button class="ghost" id="skip">何も持たずに去る</button></div>':'<div class="menu" id="ch"></div>'))+'</div>';
  if(ev.done){
    if(ev.done.card){ const d=advDeser([ev.done.card])[0]; const e=cardEl(d,{}); e.onclick=()=>cardSheet(d,{},[]); s.querySelector('#evcard').appendChild(e); }
    s.querySelector('#go').onclick=()=>{ const f=ev.done.fight; if(f){ advRun.event=null; advPrepBattle(f.kind,{strong:f.strong, bonus:f.bonus}); } else advNext(); };
    return;
  }
  if(offer){ const e=cardEl(offer.d,{}); e.onclick=()=>cardSheet(offer.d,{},[]); s.querySelector('#offer').appendChild(e); }
  if(E.pick3){ const pk=s.querySelector('#pk3'); ev.pick.forEach(id=>{ const d=AN.CARD_BY_ID[id]; const e=cardEl(d,{}); e.onclick=()=>cardSheet(d,{},[{label:'これを持ち出す',cls:'primary',fn:()=>{ advRun.col.push(d); ev.done={msg:'「'+d.name+'」を手に取った瞬間、番人が目を覚ました！', card:d.id, fight:{kind:'elite', bonus:0}}; advSave(); renderAdvEvent(); }}]); pk.appendChild(e); }); s.querySelector('#skip').onclick=()=>advNext(); return; }
  const ch=s.querySelector('#ch');
  E.choices.forEach((c,ci)=>{ const b=document.createElement('button'); b.textContent=c.label; const ok=!c.ok||c.ok(advRun,offer); b.disabled=!ok; if(ci===0) b.className='primary'; b.onclick=()=>{ const r=c.run(advRun, advRng('ev'), offer); ev.done={msg:r.msg, card:r.card?advSer([r.card])[0]:null, fight:r.fight||null}; advSave(); renderAdvEvent(); }; ch.appendChild(b); });
}
// ---------- デッキ編集 ----------
function renderAdvDeck(){
  const s=screenEl('advDeck'); const col=advRun.col; const deck=advRun.deck;
  const inDeck=advDeckDefs(); const attrs=advAttrs(inDeck); const ok=deck.length===30 && attrs.length<=2;
  const groups=new Map(); col.forEach((d,i)=>{ const k=d.anomaly?d.id+i:d.id; if(!groups.has(k)) groups.set(k,{d,idx:[]}); groups.get(k).idx.push(i); });
  const arr=[...groups.values()].sort((a,b)=>(a.d.anomaly?-1:0)-(b.d.anomaly?-1:0) || (a.d.attr[0]||'z').localeCompare(b.d.attr[0]||'z') || a.d.cost-b.d.cost);
  const curve=[0,0,0,0,0,0,0,0,0]; inDeck.forEach(d=>curve[Math.min(8,d.cost)]++); const maxC=Math.max(1,...curve);
  s.innerHTML='<div class="topbar"><button class="ghost" id="back">←</button><div class="t">デッキ編集 <span class="sub">所持'+col.length+'枚</span></div><button class="ghost helpbtn" id="help">？</button><button class="ghost" id="auto">おまかせ</button></div>'
   +'<div class="sub" style="padding:6px 12px">30枚ちょうど。属性は2つまで（無属性・アノマリーは自由）。多い方の属性のリーダー能力を使います。</div>'
   +'<div class="scroll"><div class="grid" id="grid"></div></div>'
   +'<div class="deckbar"><div class="n '+(ok?'ok':'')+'">'+deck.length+'<span class="sub" style="font-family:var(--font);font-size:11px">/30</span></div><div class="attrs">'+attrs.map(a=>'<span style="color:'+AN.ATTRS[a].c+'">'+AN.ATTRS[a].n+inDeck.filter(d=>d.attr.includes(a)).length+'</span>').join('')+(attrs.length>2?'<span style="color:#f28f8f">属性3以上</span>':'')+'</div><div class="curve">'+curve.slice(1).map((c,i)=>'<i data-c="'+(i+1)+'" style="height:'+Math.max(2,c/maxC*22)+'px"></i>').join('')+'</div><div style="flex:1"></div><button class="primary" id="done" '+(ok?'':'disabled')+'>決定</button></div>';
  const grid=s.querySelector('#grid');
  arr.forEach(g=>{ const n=g.idx.filter(i=>deck.includes(i)).length; const w=document.createElement('div'); w.className='pcard'+(n===0?' out':''); w.appendChild(cardEl(g.d,{})); w.innerHTML+='<div class="have">×'+g.idx.length+'</div>'+(n?'<div class="cnt">'+n+'</div>':'');
    w.onclick=()=>{ const n=g.idx.filter(i=>deck.includes(i)).length; cardSheet(g.d,{},[
      {label:'− 外す（'+n+'）',disabled:n===0,fn:()=>{ const i=g.idx.find(i=>deck.includes(i)); deck.splice(deck.indexOf(i),1); advSave(); renderAdvDeck(); }},
      {label:'＋ 入れる',cls:'primary',disabled:n>=g.idx.length||deck.length>=30,fn:()=>{ const i=g.idx.find(i=>!deck.includes(i)); deck.push(i); advSave(); renderAdvDeck(); }} ]); };
    grid.appendChild(w); });
  const leave=()=>{ advSave(); show(advRun.stage==='ante'?'advAnte':(advRun.stage==='inn'?'advInn':'advMap')); };
  const back=()=>{ if(!ok){ askConfirm('デッキが条件（30枚・属性2つまで）を満たしていません。おまかせで組み直して戻りますか？','組み直して戻る',()=>{ advAutoDeck(); leave(); }); return; } leave(); };
  s.querySelector('#back').onclick=back; s.querySelector('#done').onclick=back;
  s.querySelector('#auto').onclick=()=>{ advAutoDeck(); advSave(); renderAdvDeck(); };
  s.querySelector('#help').onclick=showGlossary;
}

window.__adv={ run:()=>advRun, show:(n)=>show(n), save:()=>advSave() };
