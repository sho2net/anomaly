// 強CPUに冒険の初期デッキを持たせ、地域1の敵と戦わせる（現行ルールの再現）
const AN=require('./ai.js');
const MODE=process.env.MODE||'current';
function starter(rng,color){ const pc=AN.CARDS.filter(d=>d.attr.includes(color)&&d.rarity==='C'), pu=AN.CARDS.filter(d=>d.attr.includes(color)&&d.rarity==='U'), nc=AN.CARDS.filter(d=>!d.attr.length&&d.rarity==='C');
  const col=[]; for(let k=0;k<18;k++) col.push(rng.pick(pc)); for(let k=0;k<4;k++) col.push(rng.pick(pu)); for(let k=0;k<10;k++) col.push(rng.pick(nc)); col.push(AN.makeAnomaly(rng,1,null),AN.makeAnomaly(rng,2,null)); return AN.AI.autoDeck(col,rng,color); }
function enemy(rng,a,kind,floor){
  if(MODE==='current'){
    const tiers={battle:['C'],elite:['C','U'],boss:['C']}[kind];
    let pool=[]; AN.CARDS.forEach(d=>{ if((d.attr.includes(a)||!d.attr.length)&&tiers.includes(d.rarity)) pool.push(d); });
    pool=rng.shuffle(pool.concat(pool)).slice(0,50); if(kind==='elite') pool.unshift(AN.makeAnomaly(rng,701,null));
    const deck=AN.AI.autoDeck(pool,rng,a); while(deck.length<30) deck.push(rng.pick(pool));
    return {deck, life: kind==='elite'?25:20, level: kind==='battle'?2:3};
  }
  // new: 地域1は初期デッキと同じ作り方（ランダムなコモン中心・選り好みなし）。階が進むほど少しずつ強く
  const q = Math.min(1, floor/5);
  const cc=AN.CARDS.filter(d=>d.attr.includes(a)&&d.rarity==='C'), cu=AN.CARDS.filter(d=>d.attr.includes(a)&&d.rarity==='U'), nc=AN.CARDS.filter(d=>!d.attr.length&&d.rarity==='C');
  const col=[]; const nu = kind==='elite'?4:(kind==='boss'?3:Math.round(2*q));
  for(let k=0;k<30-nu-8;k++) col.push(rng.pick(cc)); for(let k=0;k<nu;k++) col.push(rng.pick(cu)); for(let k=0;k<8;k++) col.push(rng.pick(nc));
  if(kind==='elite') col[0]=AN.makeAnomaly(rng,701,null);
  const life = kind==='elite'?20:(kind==='boss'?20:16+Math.floor(floor/2));
  const level = (kind==='battle' && floor<=2) ? 1 : (kind==='boss'?3:2);
  return {deck:col, life, level};
}
const AREA={flare:'inferno',tide:'boss_tide',grow:'bloom',ray:'boss_ray',void:'boss_void'};
for(const [kind,floor] of [['battle',0],['battle',2],['battle',4],['elite',2],['boss',5]]){
  let w=0,N=300;
  for(let i=0;i<N;i++){
    const rng=AN.makeRng(MODE+kind+floor+'_'+i); const [me,a]=rng.shuffle(AN.ATTR_ORDER);
    const my=starter(rng,me); const en=enemy(rng,a,kind,floor);
    const g=new AN.Game({seed:'e'+i,decks:[my,en.deck],names:['P','E'],mains:[me,a],choosers:[AN.AI.chooser(3),AN.AI.chooser(en.level)],lifes:[0,en.life],leaders:[null,kind==='boss'?AREA[a]:null],fieldBuff:(kind==='elite'&&MODE==='current')?{attr:a,n:1}:null});
    let s=0; while(g.winner==null&&s++<5000) AN.AI.step(g,[3,en.level][g.active]); if(g.winner===0) w++;
  }
  console.log(MODE, kind, floor+1+'階', 'プレイヤー役の勝率', Math.round(w/N*100)+'%');
}
