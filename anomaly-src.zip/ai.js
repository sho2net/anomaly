// ===== ANOMALY ai.js =====
var AN = (typeof AN !== 'undefined') ? AN : (typeof require!=='undefined' ? require('./engine.js') : {});
(function(){
const LV = { 1:{name:'弱', block:0.0, smart:false, rnd:0.5}, 2:{name:'中', block:0.7, smart:true, rnd:0.15}, 3:{name:'強', block:1.0, smart:true, rnd:0.0} };

// ---- deck auto build from 90 pool ----
function bestMain(pool){
  let best=null, bv=-1;
  AN.ATTR_ORDER.forEach(a=>{ const cs=pool.filter(d=>d.attr.includes(a)); const v=cs.reduce((s,d)=>s+AN.cardValue(d),0)+cs.length*0.5; if(v>bv){bv=v;best=a;} });
  return best;
}
function autoDeck(pool, rng, main){
  const ok=d=>d.anomaly || d.attr.length===0 || (main? d.attr.includes(main) : true);
  const cands=pool.filter(ok).map(d=>({d, v:AN.cardValue(d)/Math.max(1,d.cost)*(d.cost<=4?1.15:1) + (d.anomaly?(d.weird?1:3):0) + (main&&d.attr.includes(main)?0.8:0) + (rng?rng()*0.3:0)}));
  cands.sort((a,b)=>b.v-a.v);
  const N=AN.CONST.DECK_SIZE;
  let deck=cands.slice(0,N).map(x=>x.d);
  if(deck.length<N){ const rest=pool.filter(d=>!ok(d)).map(d=>({d,v:AN.cardValue(d)})).sort((a,b)=>b.v-a.v); for(const r of rest){ if(deck.length>=N) break; deck.push(r.d); } }
  return deck.slice(0,N);
}

function lp(g,c){ return g.hasKw(c,'deathtouch')&&g.power(c)>0 ? 99 : g.power(c); }
function creatureThreat(g, cr){ return g.power(cr)+g.health(cr)*0.5+ (g.hasKw(cr,'unblockable')?2:0)+(g.hasKw(cr,'breakthrough')?1:0)+cr.c.d.effects.length; }

// ---- chooser ----
function chooser(level){
  const L=LV[level];
  return function(g, q){
    const p=g.players[q.p], o=g.opp(p);
    if(q.type==='target'){
      const e=q.eff.e;
      if(e==='ping'){
        const crs=q.cands.filter(u=>u!=='player').map(u=>g.findCr(u)).filter(Boolean);
        const k=crs.filter(c=>g.health(c)<=q.eff.n && !(g.hasKw(c,'armor')&&!c.armorUsed)).sort((a,b)=>creatureThreat(g,b)-creatureThreat(g,a));
        if(k.length) return k[0].c.uid;
        return 'player';
      }
      if(e==='weaken'){ const crs=q.cands.map(u=>g.findCr(u)).filter(Boolean); const nn=q.eff.n+(q.eff.bonus&&g.reqOk(p,q.eff.bonus.req,{},false)?q.eff.bonus.n:0); const k=crs.filter(c=>g.health(c)<=nn); const L2=(k.length?k:crs).sort((x,y)=>creatureThreat(g,y)-creatureThreat(g,x)); return L2[0].c.uid; }
      if(['destroy','dmg','bounce','freeze','tap','steal','polymorph','copyEnemy','shuffleBack','morph'].includes(e)){
        const crs=q.cands.map(u=>g.findCr(u)).filter(Boolean);
        crs.sort((a,b)=>creatureThreat(g,b)-creatureThreat(g,a));
        if(e==='dmg'){ const k=crs.filter(c=>g.health(c)<=q.eff.n && !(g.hasKw(c,'armor')&&!c.armorUsed)); if(k.length) return k[0].c.uid; }
        if(e==='tap'||e==='freeze'){ const un=crs.filter(c=>!c.stun); const ready=p.field.filter(c=>g.canAttackWith(p,c)); const k=un.filter(c=>ready.some(a=>g.power(a)>=g.health(c)&&g.power(c)>=g.health(a))); if(k.length) return k[0].c.uid; if(un.length) return un[0].c.uid; }
        return crs[0].c.uid;
      }
      if(e==='revive'){ const cs=q.cands.map(u=>p.grave.find(c=>c.uid===u)); cs.sort((a,b)=>b.d.cost-a.d.cost); return cs[0].uid; }
      if(e==='fight'){
        const mine=p.field.slice().sort((a,b)=>g.power(b)-g.power(a))[0]; const pm=g.power(mine)+(q.eff.n||0);
        const crs=q.cands.map(u=>g.findCr(u)).filter(Boolean);
        const kill=crs.filter(c=>g.power(c)<pm).sort((a,b)=>creatureThreat(g,b)-creatureThreat(g,a));
        if(kill.length) return kill[0].c.uid;
        crs.sort((a,b)=>g.power(a)-g.power(b)); return crs[0].c.uid;
      }
      if(e==='sac'){ const crs=q.cands.map(u=>g.findCr(u)).filter(Boolean); crs.sort((a,b)=>(AN.cardValue(a.c.d)-(a.c.d.token?3:0))-(AN.cardValue(b.c.d)-(b.c.d.token?3:0))); return crs[0].c.uid; }
      if(e==='grant'){
        const crs=q.cands.map(u=>g.findCr(u)).filter(Boolean); const kw=q.eff.kw;
        if(kw==='haste'){ const sk=crs.filter(c=>c.sick&&!c.attacked); if(sk.length) return sk.sort((a,b)=>g.power(b)-g.power(a))[0].c.uid; }
        if(kw==='blocker'||kw==='armor'){ crs.sort((a,b)=>g.health(b)-g.health(a)); return crs[0].c.uid; }
        crs.sort((a,b)=>g.power(b)-g.power(a)); return crs[0].c.uid;
      }
      if(e==='evolve'){ const crs=q.cands.map(u=>g.findCr(u)).filter(Boolean); crs.sort((a,b)=>(AN.cardValue(a.c.d)-a.dmg)-(AN.cardValue(b.c.d)-b.dmg)); return crs[0].c.uid; }
      if(e==='pumpTarget'){ const crs=q.cands.map(u=>g.findCr(u)).filter(Boolean); crs.sort((a,b)=>(g.power(b)+(b.tapped?-2:0))-(g.power(a)+(a.tapped?-2:0))); return crs[0].c.uid; }
      if(e==='buff'){ const crs=q.cands.map(u=>g.findCr(u)).filter(Boolean); const ready=crs.filter(c=>!c.tapped&&(!c.sick||g.hasKw(c,'haste'))); (ready.length?ready:crs).sort((a,b)=>g.power(b)-g.power(a)); return (ready.length?ready:crs)[0].c.uid; }
      return q.cands[0];
    }
    if(q.type==='pick'){
      let best=0, bv=-1;
      q.opts.forEach((o2,i)=>{ let v=AN.cardValue(o2.d); if(o2.d.cost>p.energyMax+2) v-=1; if(v>bv){bv=v;best=i;} });
      return best;
    }
    if(q.type==='equip'){
      const crs=q.cands.map(u=>g.findCr(u)).filter(Boolean);
      crs.sort((a,b)=>(g.power(b)+(b.tapped?-1:0))-(g.power(a)+(a.tapped?-1:0)));
      return crs[0].c.uid;
    }
    if(q.type==='block'){
      if(g.rng()>=L.block) return null;
      const atk=g.findCr(q.attacker); const pa=g.power(atk);
      const blockers=q.cands.map(u=>g.findCr(u)).filter(Boolean);
      const incoming = q.target==='player' ? pa : 0;
      // kill it without dying
      const ha=g.health(atk);
      const win=blockers.filter(b=>g.power(b)>=ha && g.health(b)>pa).sort((a,b)=>g.power(a)-g.power(b));
      if(win.length) return win[0].c.uid;
      const surv=blockers.filter(b=>g.health(b)>pa).sort((a,b)=>g.power(b)-g.power(a));
      if(surv.length && incoming>0) return surv[0].c.uid;
      // survive via armor
      const arm=blockers.filter(b=>g.hasKw(b,'armor')&&!b.armorUsed);
      if(arm.length && incoming>0) return arm[0].c.uid;
      // trade if attacker is at least as valuable
      const tie=blockers.filter(b=>g.power(b)>=ha);
      if(tie.length && (AN.cardValue(atk.c.d)>=AN.cardValue(tie[0].c.d) || incoming>=p.life-6)) return tie[0].c.uid;
      // chump if lethal-ish
      if(q.target==='player' && (p.life-pa<=3 || pa>=p.life)){
        blockers.sort((a,b)=>AN.cardValue(a.c.d)-AN.cardValue(b.c.d)); return blockers[0].c.uid;
      }
      // breakthrough: blocking still reduces damage
      if(q.target==='player' && g.hasKw(atk,'breakthrough') && p.life<=8){ blockers.sort((a,b)=>g.power(b)-g.power(a)); return blockers[0].c.uid; }
      return null;
    }
    return q.cands ? q.cands[0] : null;
  };
}

// ---- one step of the CPU turn. returns a string when it acted, null when the turn was ended ----
// v3.9.2: リーダー能力の価値を、カード1枚と同じ尺度で見積もる
function abilityValue(g, p){
  const L=g.leaderDef(p); if(!L) return -99; const o=g.opp(p); let v=0;
  const enemies=o.field.filter(c=>g.health(c)>0);
  for(const x of [].concat(L.ef)){
    const n=x.n||0;
    switch(x.e){
      case 'destroy': { const cs=g.candidates(p,x,null).map(u=>g.findCr(u)).filter(Boolean); if(!cs.length) return -99; v+=3+Math.max(...cs.map(c=>creatureThreat(g,c))); break; }
      case 'dmg': case 'weaken': { const k=enemies.filter(c=>g.health(c)<=n); v+= k.length? 2+Math.max(...k.map(c=>creatureThreat(g,c))) : (enemies.length?n*0.4:-99); break; }
      case 'ping': { const k=enemies.filter(c=>g.health(c)<=n); v+= k.length? 2+Math.max(...k.map(c=>creatureThreat(g,c))) : n*0.7; if(o.life<=n) v+=99; break; }
      case 'weakenAll': case 'dmgAll': { const k=enemies.filter(c=>g.health(c)<=n).length; v+=k*2.5+enemies.length*0.4; break; }
      case 'damage': v+= o.life<=n ? 99 : n*0.7; break;
      case 'heal': v+= p.life<=12 ? n*0.7 : n*0.3; break;
      case 'draw': v+= p.hand.length<8 ? 1.8*n : 0; break;
      case 'pumpTarget': v+= p.field.length ? 1.3*n+0.5 : -99; break;
      case 'buffAll': v+= p.field.filter(c=>g.canAttackWith(p,c)).length*0.9*n; break;
      case 'tokens': { const t=AN.TOKENS[x.tok||'none']; v+= p.field.length<7 ? (t.power+t.hp)*0.6*n : -99; break; }
      case 'randomDmg': v+=0.8*n; break;
      case 'castRandom': v+=2; break;
      case 'scry': v+=1.5; break;
      case 'boostHand': v+=p.hand.filter(c=>c.d.sb).length*0.7; break;
      default: v+=1;
    }
  }
  return v;
}
function mullPick(g, i){
  const p=g.players[i];
  // 5コスト以上は戻す（アノマリーは6コスト以上なら戻す）。3コスト以下が1枚もなければ4コストも戻す
  const cheap=p.hand.filter(c=>c.d.cost<=3).length;
  return p.hand.filter(c=>{ if(c.d.id==='sp_shard') return false; if(c.d.anomaly) return c.d.cost>=6; if(c.d.cost>=5) return true; if(c.d.cost===4 && cheap===0) return true; return false; }).map(c=>c.uid);
}
function step(g, level){
  if(g.phase==='mulligan'){ [0,1].forEach(i=>{ if(!g.mullDone[i] && g.choosers[i]) g.mulligan(g.players[i], mullPick(g,i)); }); return null; }
  const L=LV[level]; const p=g.activePlayer(), o=g.opp(p);
  if(g.winner!=null||g.pending) return null;
  const energyN=p.energyMax, free=p.energy;
  {
    // 2. play best card
    const playable=p.hand.filter(c=>g.canPlay(p,c));
    if(playable.length){
      const scored=playable.map(c=>{
        const d=c.d; let s=AN.cardValue(d); const scoredCard=c;
        if(d.type==='spell'){
          const tgt=d.effects.filter(x=>g.needsTarget(x));
          const oField=o.field, oPow=oField.reduce((m,x)=>Math.max(m,g.power(x)),0);
          d.effects.forEach(x=>{
            if(x.e==='dmg'){ const k=oField.filter(c=>g.health(c)<=x.n && !(g.hasKw(c,'armor')&&!c.armorUsed)); s = k.length? 3+Math.max(...k.map(c=>creatureThreat(g,c))) : (oField.length? 0.5 : -5); }
            if(x.e==='dmgAll'){ const k=oField.filter(c=>g.health(c)<=x.n).length; s = k>=2? 4+k*2 : (k===1? 2 : (oField.length?0:-5)); }
            if(x.e==='destroy'||x.e==='bounce'||x.e==='freeze'){ const cs=g.candidates(p,x); s = cs.length? 3+Math.max(...cs.map(u=>creatureThreat(g,g.findCr(u)))) : -5; }
            if(x.e==='destroyAll'){ const k=oField.filter(cr=>(!x.tapped||cr.tapped)).length; s = k>=2? 4+k*2 : (k===1? 2 : -5); }
            if(x.e==='bounceAll'){ s = oField.length>=2? 3+oField.length*1.5 : -3; }
            if(x.e==='tap'){ const ready=p.field.filter(c=>g.canAttackWith(p,c)); const un=oField.filter(c=>!c.stun); const k=un.filter(c=>ready.some(a=>g.power(a)>=g.health(c)&&g.power(c)>=g.health(a))); s = k.length? 3+Math.max(...k.map(c=>creatureThreat(g,c))) : (un.some(c=>g.hasKw(c,'blocker'))&&ready.length? 2 : -4); }
            if(x.e==='tapAll'){ const ready=p.field.filter(c=>g.canAttackWith(p,c)); s = oField.filter(c=>!c.stun).length>=2 && ready.length>=2 ? 5+ready.length : -4; }
            if(x.e==='heal'){ s = p.life<=12 ? 3+(20-p.life)/3 : -2; }
            if(x.e==='draw'){ s = p.hand.length<=3 ? 4 : 2; }
            if(x.e==='ramp'){ s = energyN<7 ? 4 : -2; }
            if(x.e==='energyNow'){ const after=free-g.costOf(p,d,scoredCard)+x.n; s = p.hand.some(c=>c!==scoredCard && g.costOf(p,c.d,c)<=after && g.costOf(p,c.d,c)>free-g.costOf(p,d,scoredCard)) ? 6 : -3; }
            if(x.e==='damage'){ s = o.life<=x.n ? 100 : 2+ (o.life<10?2:0); }
            if(x.e==='discard'){ s = o.hand.length>=3 ? 3 : -2; }
            if(x.e==='buff'||x.e==='buffAll'){ s = p.field.some(c=>!c.tapped&&!c.sick) && o.life<= (x.n*(x.e==='buffAll'?p.field.length:1)+p.field.reduce((a,c)=>a+g.power(c),0)) ? 20 : -3; }
            if(x.e==='fight'){ const mine=p.field.slice().sort((a,b)=>g.power(b)-g.power(a))[0]; if(!mine) s=-5; else { const pm=g.power(mine)+(x.n||0); const k=oField.filter(c=>g.power(c)<pm); s = k.length? 3+Math.max(...k.map(c=>creatureThreat(g,c))) : -5; } }
            if(x.e==='pumpTarget'){ s = p.field.length? 2.5+x.n*0.5 : -5; }
            if(x.e==='freezeAll'){ s = oField.filter(c=>!c.tapped).length>=2 ? 5+oField.length : -4; }
            if(x.e==='steal'||x.e==='copyEnemy'){ const cs=g.candidates(p,x); s = cs.length? 4+Math.max(...cs.map(u=>creatureThreat(g,g.findCr(u)))) : -5; }
            if(x.e==='polymorph'){ const cs=g.candidates(p,x); s = cs.length? 2+Math.max(...cs.map(u=>creatureThreat(g,g.findCr(u)))) : -5; }
            if(x.e==='swapBoards'){ const tp=oField.reduce((a,c)=>a+g.power(c),0), mp=p.field.reduce((a,c)=>a+g.power(c),0); s = tp-mp>=4 ? 6+(tp-mp) : -6; }
            if(x.e==='swapLife'){ s = o.life-p.life>=5 ? 8+(o.life-p.life) : -10; }
            if(x.e==='equalize'){ const tm=oField.reduce((m,c)=>Math.max(m,g.power(c)),0), mm=p.field.reduce((m,c)=>Math.max(m,g.power(c)),0); s = (tm>x.n+2 && mm<=x.n+1) || p.field.length>oField.length+1 ? 5 : -4; }
            if(x.e==='mill'){ s = o.deck.length<=x.n+4 ? 8 : 1; }
            if(x.e==='handRefresh'){ s = p.hand.length<=2 && o.hand.length>=4 ? 4 : -2; }
            if(x.e==='massRevive'){ const k=p.grave.filter(c=>c.d.type==='creature').reduce((a,c)=>a+c.d.cost,0), ko=o.grave.filter(c=>c.d.type==='creature').reduce((a,c)=>a+c.d.cost,0); s = k-ko>=4 ? 3+(k-ko)/2 : -5; }
            if(x.e==='dmgAllBoth'){ const tk=oField.filter(c=>g.health(c)<=x.n).length, mk=p.field.filter(c=>g.health(c)<=x.n).length; s = tk>=mk+1 ? 3+tk*2 : -5; }
            if(x.e==='coin'){ s = oField.length>=2 && p.life>8 ? 3 : -3; }
            if(x.e==='resetAll'){ const tp=oField.reduce((a,c)=>a+g.power(c),0), mp=p.field.reduce((a,c)=>a+g.power(c),0); s = tp>mp+3 ? 5 : -4; }
            if(x.e==='graveSteal'){ const cs=o.grave.filter(c=>c.d.type==='creature'); s = cs.length? 2+Math.max(...cs.map(c=>c.d.cost)) : -5; }
            if(x.e==='silenceAll'){ const k=oField.filter(c=>c.c.d.kw.length||c.c.d.effects.length).length; s = k>=1 ? 2+k*2 : -5; }
            if(x.e==='weaken'){ const nn=x.n+(x.bonus&&g.reqOk(p,x.bonus.req,{},false)?x.bonus.n:0); const k=oField.filter(c=>g.health(c)<=nn); s = k.length? 3+Math.max(...k.map(c=>creatureThreat(g,c))) : (oField.length?1:-5); }
            if(x.e==='weakenAll'){ const nn=x.n+(x.bonus&&g.reqOk(p,x.bonus.req,{},false)?x.bonus.n:0); const k=oField.filter(c=>g.health(c)<=nn).length; s = k>=2? 4+k*2 : (k===1?2:-4); }
            if(x.e==='halveLife'){ s = p.life<=10 ? 2 : -6; }
            if(x.e==='setLeader'){ s = p.leaderOverride ? 1 : 4; }
            if(x.e==='swapLeader'){ s = -2; }
            if(x.e==='randomDmgCr'){ s = oField.length? 2+oField.filter(c=>g.health(c)<=x.n).length*2 : -3; }
            if(x.e==='pumpAll'){ s = p.field.length>=2 ? 2+p.field.length*x.n : -2; }
            if(x.e==='boostHand'){ s = 1.5+p.hand.filter(c=>c.d.sb).length; }
            if(x.e==='sac'){ const own=p.field.filter(c=>c.c.d.token||AN.cardValue(c.c.d)<3); s = own.length? 2 : -6; }
            if(x.e==='recallSpell'){ s = p.grave.some(c=>c.d.type==='spell') ? 2.5 : -3; }
            if(x.e==='reviveAllSelf'){ const k=p.grave.filter(c=>c.d.type==='creature').length; s = (p.souls>=10 && k>=2) ? 6+k : -4; }
            if(x.e==='swapHands'){ s = o.hand.length-p.hand.length>=2 ? 2 : -4; }
            if(x.e==='setLifeBoth'){ s = p.life<13 && o.life>13 ? 6 : -8; }
            if(x.e==='castRandom'){ s = 2; }
            if(x.e==='swapEnergy'){ s = o.energyMax>p.energyMax ? 4 : -6; }
            if(x.e==='coins'){ s = p.life>10 ? 1 : -5; }
            if(x.e==='deckTopBoth'){ s = 0.5; }
            if(x.e==='timeSkip'){ s = -1; }
            if(x.e==='anomalyHand'){ s = p.hand.length<=3 ? 2 : -2; }
            if(x.e==='giftAnomaly'||x.e==='doubleEnemy'||x.e==='drawOpp'||x.e==='healOpp'){ s = -8; }
            if(x.e==='swapGraveDeck'){ s = p.deck.length<=3 && p.grave.length>5 ? 6 : -6; }
            if(x.e==='shuffleOwners'){ const tp=o.field.reduce((a,c)=>a+g.power(c),0), mp=p.field.reduce((a,c)=>a+g.power(c),0); s = tp>mp+4 ? 3 : -4; }
            if(x.e==='shrinkAll'){ const tp=o.field.reduce((a,c)=>a+g.power(c),0), mp=p.field.reduce((a,c)=>a+g.power(c),0); s = tp>mp+4 ? 4 : -4; }
            if(x.e==='tokens'){ s = p.field.length+x.n<=7 ? 2+x.n : -3; }
            if(x.e==='discover'||x.e==='randomCard'||x.e==='tutor'){ s = p.hand.length<=4 ? 3 : 1; }
            if(x.e==='scry'){ s = 2.5; }
            if(x.e==='randomDmg'){ s = 2+oField.filter(c=>g.health(c)<=2).length; }
            if(x.e==='shuffleBack'){ const cs=g.candidates(p,x); s = cs.length? 3+Math.max(...cs.map(u=>creatureThreat(g,g.findCr(u)))) : -5; }
            if(x.e==='morph'){ const cs=g.candidates(p,x); s = cs.length? 1+Math.max(...cs.map(u=>creatureThreat(g,g.findCr(u))))-2 : -5; }
            if(x.e==='grant'){ const cs=g.candidates(p,x); s = cs.length? (x.kw==='haste'? (p.field.some(c=>c.sick&&!c.attacked)?4:-3) : 2.5) : -5; }
            if(x.e==='grantAll'){ s = p.field.length>=2 ? 2+p.field.length : -3; if(x.kw==='haste') s = p.field.filter(c=>c.sick&&!c.attacked).length>=2 ? 5 : -4; }
            if(x.e==='addCard'){ s = x.to==='opp' ? (o.hand.length>=6?3:1.5) : (p.hand.length<=5?2.5:0); }
            if(x.e==='deckAdd'){ s = 3+(o.deck.length<15?2:0); }
            if(x.e==='transformHand'){ s = x.all ? -2 : 1.5; }
            if(x.e==='evolve'){ s = p.field.length? (x.all? 3+p.field.length : 2.5) : -5; }
            if(x.e==='copyHand'){ s = o.hand.length? 2.5 : -5; }
            if(x.e==='graveCopy'){ s = o.grave.length? 2 : -5; }
            if(x.e==='stealHand'){ s = o.hand.length? 3 : -5; }
            if(x.e==='shuffleHand'){ s = o.hand.length>=4 ? 2 : -3; }
            if(x.e==='swapStatsAll'){ const gain=[...p.field].reduce((a,c)=>a+(g.maxHealth(c)-g.power(c)),0)-[...oField].reduce((a,c)=>a+(g.maxHealth(c)-g.power(c)),0); s = gain>=3 ? 4 : -4; }
            if(x.e==='discountHand'){ s = p.hand.length>=3 ? 3+p.hand.length*0.5 : -2; }
            if(x.e==='revive'){ s = g.candidates(p,x).length? 3+Math.max(...g.candidates(p,x).map(u=>p.grave.find(c=>c.uid===u).d.cost)) : -5; }
          });
        } else if(d.legend){
          const tp=o.field.reduce((a,c)=>a+g.power(c),0), mp=p.field.reduce((a,c)=>a+g.power(c),0);
          if(d.legendType==='titan') s = (tp>mp+2) ? 12 : 1;
          else if(d.legendType==='usurp') s = (o.field.length>=2 && p.life>=8) ? 10 : -4;
          else if(d.legendType==='jester') s = 3+Math.min(8,p.hand.length+o.hand.length)*0.8;
          else if(d.legendType==='queen') s = 2+o.hand.length*1.5;
          else if(d.legendType==='undead') s = 2+Math.min(3,p.grave.filter(c=>c.d.type==='creature').length)*3;
          else if(d.legendType==='soul'){ const x=d.effects[0]; s = 2+Math.min(12, g.scaleCount(p,x,{src:c})); }
          else s = 9;
        } else if(d.type==='creature' && d.weird){
          d.effects.forEach(x=>{ if(['doubleEnemy','giftAnomaly'].includes(x.e)) s-=6; if(x.e==='setLifeBoth' && !(p.life<13&&o.life>13)) s-=8; if(x.e==='swapEnergy' && o.energyMax<=p.energyMax) s-=4; if(x.e==='swapGraveDeck' && p.deck.length>6) s-=5; if(x.e==='shrinkAll'){ const tp=o.field.reduce((a,c)=>a+g.power(c),0), mp=p.field.reduce((a,c)=>a+g.power(c),0); if(tp<=mp) s-=5; } });
        } else if(d.type==='relic'){
          s = AN.cardValue(d) + (d.effects.some(x=>x.e==='aura')? p.field.length : 1);
        } else if(d.type==='trap'){
          s = 2.5 + (o.field.length? 1:0);
        } else if(d.type==='equip'){
          s = p.field.some(c=>!c.tapped) ? AN.cardValue(d) : -3;
        } else {
          s += d.cost*0.3; // prefer using energy
          if(o.field.length===0 && d.kw.includes('blocker')) s-=0.5;
        }
        // signature mechanics
        d.effects.forEach(x=>{
          const r=x.req;
          if(r){
            const ok=g.reqOk(p,r,{snap:{combo:p.plays},src:c},false);
            if(ok) s+=2.5;
            else if(r.combo && L.smart){ const others=playable.filter(z=>z!==c && g.costOf(p,z.d,z)+g.costOf(p,d,c)<=p.energy); if(others.length) s-=3; }
            else if(r.awaken && p.energyMax>=5 && L.smart) s-=1.5;
          }
          if(x.bonus && g.reqOk(p,x.bonus.req,{src:c},false)) s+=2;
          if(x.scale==='combo' && L.smart){ const others=playable.filter(z=>z!==c && g.costOf(p,z.d,z)+g.costOf(p,d,c)<=p.energy); if(others.length && p.plays===0) s-=2; s+=p.plays; }
          if(x.scale==='spells') s+=Math.min(6,p.spellsCast)-2;
          if(x.scale==='pray') s+=Math.min(6,p.pray)-2;
          if(x.scale==='boost') s+=(c.boost||0);
        });
        if(d.sb && L.smart && d.type==='creature' && (c.boost||0)<1 && playable.some(z=>z!==c&&z.d.type==='spell')) s-=1.5;
        // cheap cards first so later cards get 連撃
        if(p.main==='flare' && L.smart) s+= (4-g.costOf(p,d,c))*0.3;
        if(!L.smart) s+= (g.rng()-0.5)*3;
        return {c,s};
      }).sort((a,b)=>b.s-a.s);
      if(L.smart && g.canUseAbility(p)){ const av=abilityValue(g,p); if(av>0 && av>=scored[0].s && g.useAbility(p)) return 'ability'; }
      if(scored[0].s>0 && g.play(p,scored[0].c)) return 'play';
    }
  }
  // 2b. leader ability: use whenever energy would otherwise go unused (like a hero power)
  if(g.canUseAbility(p)){
    const playable=p.hand.filter(c=>g.canPlay(p,c));
    const cheapest=playable.reduce((m,c)=>Math.min(m,g.costOf(p,c.d,c)),99);
    const LD=g.leaderDef(p); const ac=LD?LD.cost:2;
    const spare = playable.length===0 || p.energy-cheapest>=ac || (p.energy>=ac && !playable.some(c=>g.costOf(p,c.d,c)>p.energy-ac));
    let want=spare && abilityValue(g,p)>0;
    switch(p.leaderOverride ? 'x' : p.main){
      case 'x': want = spare; break;
      case 'tide': want = spare && p.hand.length<=6 && p.life>5; break;
      case 'grow': want = spare && p.field.length>0; break;
      case 'ray': want = spare && p.life<=24; break;
      case 'void': want = spare && p.field.length<7; break;
    }
    if(want && g.useAbility(p)) return 'ability';
  }
  // 3. attack (v1.2 guard rules: targets may be forced)
  const ready=p.field.filter(c=>g.canAttackWith(p,c));
  if(ready.length){
    const totalPow=ready.reduce((a,c)=>a+g.power(c),0);
    const guards=o.field.filter(c=>!c.tapped&&g.hasKw(c,'blocker'));
    const guardHp=guards.reduce((a,c)=>a+g.health(c),0);
    const lethal = totalPow-guardHp >= o.life;
    for(const cr of ready){
      const pw=g.hasKw(cr,'deathtouch')&&g.power(cr)>0?99:g.power(cr), myH=g.health(cr), myVal=AN.cardValue(cr.c.d); const facePw=g.power(cr);
      const targets=g.attackTargets(p,cr);
      const noArmor=c=>!(g.hasKw(c,'armor')&&!c.armorUsed);
      const canFace=targets.includes('player');
      const crs=targets.filter(u=>u!=='player').map(u=>g.findCr(u)).filter(Boolean);
      const kills=crs.filter(c=>noArmor(c) && g.health(c)<=pw && (c.stun || lp(g,c)<myH)).sort((a,b)=>creatureThreat(g,b)-creatureThreat(g,a));
      const trades=crs.filter(c=>noArmor(c) && g.health(c)<=pw && !c.stun && lp(g,c)>=myH).sort((a,b)=>AN.cardValue(b.c.d)-AN.cardValue(a.c.d));
      const theirPow=o.field.reduce((a,c)=>a+g.power(c),0), myPow=p.field.reduce((a,c)=>a+g.power(c),0);
      let target=null;
      // v3.13: ダメージレースの判定。相手の盤面の方が先に自分を倒せるなら、顔を殴らずに盤面を取る
      const clock=(life,pow)=>pow>0?Math.ceil(life/pow):99;
      const myBoard=p.field.reduce((s2,c)=>s2+(g.hasKw(c,'noattack')?0:g.power(c)),0);
      const theirBoard=o.field.reduce((s2,c)=>s2+(g.hasKw(c,'noattack')||c.frozen?0:g.power(c)),0);
      const myClock=clock(o.life,myBoard), theirClock=clock(p.life,theirBoard);
      const raceBad = L.smart && !lethal && o.life>facePw && theirBoard>0 && (theirClock<myClock || (theirClock===myClock && myClock>=3));
      if(raceBad && crs.length){
        const armored=c=>g.hasKw(cr,'armor')&&!cr.armorUsed;
        const atkDies=c=>!c.stun && lp(g,c)>=myH && !armored(c);
        const teamPow=ready.filter(c=>g.canAttackWith(p,c)).reduce((s2,c)=>s2+(g.hasKw(c,'deathtouch')&&g.power(c)>0?99:g.power(c)),0);
        const opts=crs.filter(noArmor).map(c=>{
          const worth=creatureThreat(g,c)+g.power(c)*1.2, loss=atkDies(c)? creatureThreat(g,cr)*0.7 : 0;
          let sc=-99;
          if(g.health(c)<=pw) sc=worth-loss;                                  // この1体で倒せる
          else if(teamPow>=g.health(c)) sc=worth*0.8-loss-0.5;                  // 残りの攻撃と合わせれば倒せる
          else if(!atkDies(c) && g.power(c)>=3) sc=g.power(c)*0.4;             // 生き残れるなら削っておく（ダメージは残る）
          return {c,sc}; }).sort((x,y)=>y.sc-x.sc);
        if(opts.length && opts[0].sc>0.5 && g.attack(p,cr,opts[0].c.c.uid)) return 'attack';
      }
      if(canFace){
        if(!L.smart || lethal || o.life<=facePw) target='player';
        else if(kills.length && o.life>facePw*2 && creatureThreat(g,kills[0])>=Math.max(2,pw-3)) target=kills[0].c.uid;
        else if(trades.length && o.life>facePw*2 && (AN.cardValue(trades[0].c.d)>myVal || theirPow>myPow)) target=trades[0].c.uid;
        else target='player';
        if(!L.smart && g.rng()<0.15) target=null;
      } else {
        // must attack a guard: do it if we kill it, or trade favourably, or when racing
        if(kills.length) target=kills[0].c.uid;
        else if(trades.length && (AN.cardValue(trades[0].c.d)>=myVal-1 || theirPow>myPow)) target=trades[0].c.uid;
        else if(!L.smart || lethal || g.turn>30 || p.deck.length<=3) target=crs.sort((a,b)=>g.health(a)-g.health(b))[0].c.uid;
        else {
          // chip damage into the guard when it dies to two hits and we survive
          const soft=crs.filter(c=>lp(g,c)<myH).sort((a,b)=>g.health(a)-g.health(b));
          if(soft.length && ready.length>=2) target=soft[0].c.uid;
        }
      }
      if(target && g.attack(p,cr,target)) return 'attack';
    }
  }
  g.endTurn(); return null;
}

function bossDeck(boss, rng){
  if(boss.special==='anomaly'){
    const pool=[];
    AN.CARDS.forEach(d=>{ if(d.rarity!=='C') pool.push(d); });
    const an=[];
    for(let i=0;i<boss.legends;i++) an.push(AN.makeLegend(rng, 9100+i*3));
    for(let i=0;i<boss.anomalies-boss.legends;i++) an.push(AN.makeAnomaly(rng, 9101+i, null));
    const rest=autoDeck(pool, rng, null).slice(0, 30-an.length);
    return {pool: an.concat(pool), deck: an.concat(rest)};
  }
  const pool=[];
  const okR = boss.tier===1 ? ['C','U'] : boss.tier===2 ? ['C','U','R'] : ['C','U','R','L'];
  AN.CARDS.forEach(d=>{ if((d.attr.includes(boss.attr) || d.attr.length===0) && okR.includes(d.rarity)){ const k=d.rarity==='L'?1:2; for(let i=0;i<k;i++) pool.push(d); } });
  for(let i=0;i<boss.legends;i++) pool.unshift(AN.makeLegend(rng, 9000+i*3));
  for(let i=0;i<boss.anomalies-boss.legends;i++) pool.unshift(AN.makeAnomaly(rng, 9001+i*3, null));
  const deck=autoDeck(pool, rng, boss.attr);
  // 伝説は必ず入れる
  pool.filter(d=>d.legend).forEach(d=>{ if(!deck.includes(d)){ deck.pop(); deck.unshift(d); } });
  return {pool, deck};
}
AN.AI={LV, autoDeck, bestMain, chooser, step, mullPick, bossDeck};
if(typeof module!=='undefined') module.exports = AN;
})();
