# ANOMALY 画像 生成指示書（Z-Image Turbo）

ANOMALY（ダークファンタジーのデジタルカードゲーム）の一枚絵を作るための指示書。カードの絵は作らない。
生成したら PNG のままで、ANOMALY のチャットに添付してもらえれば、こちらで軽量化（WebP）して組み込む。

## 共通ルール

- **文字を入れない**：看板・巻物・紋章などにも文字が出ないようにする（Z-Image は文字を描けてしまうため、プロンプトで明示）
- **画風をそろえる**：すべてのプロンプトの末尾に、次の「共通の画風」を付ける

```
dark fantasy painterly digital illustration, rich deep colors, dramatic cinematic lighting, highly detailed, atmospheric, no text, no letters, no watermark, no signature, no border, no frame
```

- **設定**：Turbo の標準設定のまま（ステップ8前後・CFG 1前後）でよい。1つのプロンプトで2〜4枚出し、良いものを1枚選ぶ
- **ファイル名**：下の表の「ファイル名」で保存（拡張子は .png のままでよい）
- **ゲームの色**：アノマリー（歪み）の色は ピンク #FF6BD6・紫 #8B5CFF・水色 #4DD9FF。属性の色は 炎 赤・水 青・森 緑・光 金・闇 紫

## 優先度1（まずこれだけでも入れる）

### タイトル画面　縦 768×1344

| ファイル名 | プロンプト（＋共通の画風） |
|---|---|
| title | A single mysterious playing card floating above an ancient stone altar in a vast dark hall, the card glowing and tearing open a small rift of pink, violet and cyan light, dozens of other cards drifting around it in the air like leaves, faint magic circles on the floor, vertical composition, the upper third of the image is calm dark empty space |

上3分の1を暗く空けてあるのは、ロゴ「ANOMALY」を重ねるため。

### 冒険モードの地域　横 1344×768

地図の見出しと、戦闘前の画面の背景に使う。

| ファイル名 | 地域 | プロンプト（＋共通の画風） |
|---|---|---|
| region_flare | 灼熱の火山 | A volcanic caldera at dusk, rivers of glowing lava winding between black obsidian ruins, ash and embers filling a red sky, a distant fortress carved into the mountain, wide landscape |
| region_tide | 深き海底神殿 | A sunken temple deep beneath the sea, colossal pillars covered in bioluminescent coral, shafts of pale blue light from far above, schools of fish, drifting bubbles, wide landscape |
| region_grow | 太古の大森林 | An ancient forest of colossal trees older than kingdoms, moss-covered stone ruins among the roots, glowing green spores floating in misty light, wide landscape |
| region_ray | 天空の聖都 | A white holy city floating above the clouds, golden spires and bridges, radiant sunbeams, winged silhouettes in the distance, wide landscape |
| region_void | 冥府の墓所 | An underworld necropolis of endless tombs and stairways, violet ghost-fire burning in iron braziers, a black sky with a pale dead moon, wide landscape |

### 最終ボス　縦 896×1152

戦闘前の画面と、真の姿が目覚めたときの演出に使う。

| ファイル名 | ボス | プロンプト（＋共通の画風） |
|---|---|---|
| boss_devourer | 万象喰らい ザルヴァ＝ネクス（ノーマル） | A colossal cosmic devourer rising from an abyss, a shapeless mass of darkness and molten fire with countless glowing mouths and eyes, swallowing falling stars and shattered cards, pink, violet and cyan cracks of distorted reality around it, towering, terrifying, centered portrait |
| boss_judge | 双冠の審判者 ルクス＝ノクティア（ハード） | A divine judge whose body is split down the middle into light and darkness, the left half radiant white and gold with a halo crown, the right half black and violet with a crown of thorns, holding great scales of judgment, standing in a ruined cathedral with bells, majestic and terrifying, centered portrait |

## 優先度2（地域の主）　縦 896×1152

冒険モードで各地域の最後に戦う主。戦闘前の画面に使う。

| ファイル名 | ボス | プロンプト（＋共通の画風） |
|---|---|---|
| lord_flare | 火山の主イグナ | A towering sovereign of the volcano made of cooling magma and living flame, a crown of fire, glowing cracks across the body, standing before a lava lake, centered portrait |
| lord_tide | 海の支配者ネレア | A sea empress with hair of flowing water, a crown of coral and pearls, holding a trident, surrounded by swirling currents in a sunken temple, centered portrait |
| lord_grow | 森の古王ガイオス | An ancient treant king with great antlers of branches, a beard of moss, eyes glowing green, roots spreading from his body into the forest floor, centered portrait |
| lord_ray | 天光の主セラフ | A radiant angel knight with six wings of light, a golden halo, silver armor, a sword of sunlight, above the clouds of a holy city, centered portrait |
| lord_void | 冥王ハーデン | A skeletal king of the underworld on a throne of bones, a dark iron crown, violet flames in his eye sockets, a black cloak like smoke, centered portrait |

## 優先度3（あれば入れる）

### ボスに挑戦（6体）　縦 896×1152

| ファイル名 | ボス | プロンプト（＋共通の画風） |
|---|---|---|
| chal_1 | 炎獄の番人 | A hulking guardian of a hellfire prison, armor of blackened iron glowing red from within, a chained flaming axe, centered portrait |
| chal_2 | 渦潮の魔導師 | A sorcerer standing in the eye of a great whirlpool, robes of deep blue, spell circles of water orbiting him, centered portrait |
| chal_3 | 大森林の王 | A great beast king of the forest, a giant stag-like creature crowned with blooming branches, wild and noble, centered portrait |
| chal_4 | 天光の審判者 | A stern arbiter of light in white and gold robes, a blindfold, a blazing gavel, pillars of light behind, centered portrait |
| chal_5 | 冥府の支配者 | A ruler of the dead in a hooded black robe, a scythe, a court of ghosts kneeling behind, centered portrait |
| chal_6 | 特異点アノマリア | A being made of broken reality, a humanoid silhouette filled with shifting fragments of cards and galaxies, pink, violet and cyan light leaking from cracks, centered portrait |

### 謎の出来事（9種）　横 1344×768

| ファイル名 | 出来事 | プロンプト（＋共通の画風） |
|---|---|---|
| ev_altar | 古い祭壇 | A moss-covered ancient altar pulsing with red light, blood-red runes without letters, a dark forest clearing |
| ev_chest | 古びた宝箱 | An old treasure chest by a forest path that seems to be breathing, faint teeth along its lid |
| ev_merchant | 行商人 | A hooded traveling merchant with a cart full of strange goods and glowing cards, lantern light |
| ev_spring | 冷たい泉 | A clear cold spring in a cave, glowing blue water, coins glinting at the bottom |
| ev_mirror | 呪いの鏡 | A cursed ornate mirror in an abandoned room, the reflection twisted and distorted |
| ev_library | 禁書庫 | A forbidden library, books bound in chains, a glowing card trapped between pages, a sleeping stone guardian |
| ev_champion | さすらいの強者 | A lone wandering swordsman standing in the middle of a road at sunset, cloak in the wind, calm and dangerous |
| ev_bandits | 野盗 | Masked bandits blocking a mountain road, torches, one pointing a blade |
| ev_armory | 呪われた武器庫 | A rusted armory, piles of old weapons, one card glowing with a sinister light among them |

## 組み込み先（ANOMALY 側でやること）

- title → タイトル画面の背景（ロゴの下に敷く）
- region_* → 冒険モードの見出しと戦闘前の画面の背景
- boss_* / lord_* / chal_* → 戦闘前の画面の敵の肖像、ボス選択のカード、最終ボスの「真の姿」演出
- ev_* → 謎の出来事の画面
- 画像は index.html に埋め込まず、GitHub の art フォルダに WebP で置く（1枚100KB前後）
