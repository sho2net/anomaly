# v3.16 一枚絵の表示確認（タイトル・ボス選択・冒険の見出し・主/最終ボスの肖像・出来事）
import asyncio, subprocess, time
from playwright.async_api import async_playwright
async def main():
    srv=subprocess.Popen(['python3','-m','http.server','8765'],cwd='/home/claude/anomaly',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(0.6)
    try:
      async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':780}, device_scale_factor=2)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e))); bad=[]
        pg.on('response', lambda r: bad.append(r.url) if r.status>=400 else None)
        await pg.goto('http://localhost:8765/index.html'); await pg.wait_for_timeout(300)
        await pg.evaluate('localStorage.clear()'); await pg.reload(); await pg.wait_for_timeout(900)
        await pg.screenshot(path='art1.png')
        await pg.click('#btnBoss'); await pg.wait_for_timeout(700); await pg.screenshot(path='art2.png')
        await pg.evaluate("__adv.show('title')"); await pg.wait_for_timeout(200)
        await pg.click('#btnAdv'); await pg.wait_for_timeout(300)
        await pg.click('.advcolors button[data-c="flare"]'); await pg.wait_for_timeout(300)
        btns=await pg.query_selector_all('.advnodes button'); 
        for x in btns:
            t=await x.inner_text()
            if '戦' in t or '敵' in t: await x.click(); break
        await pg.wait_for_timeout(600); await pg.screenshot(path='art3.png')
        n=0
        for kind,extra in [('boss',{}),('final',{'final':True,'secret':True}),('final',{'final':True,'secret':True,'hardFinal':True})]:
            n+=1
            await pg.evaluate("([k,e])=>{ const r=__adv.run(); r.pending.kind=k; Object.assign(r.pending.en,e); __adv.show('advAnte'); }",[kind,extra]); await pg.wait_for_timeout(700)
            await pg.screenshot(path='art4_%d.png'%n)
        for k in ['altar','bandits','library']:
            await pg.evaluate("k=>{ const r=__adv.run(); r.event={key:k,pick:['F01','F02','F03']}; __adv.show('advEvent'); }",k); await pg.wait_for_timeout(700)
            await pg.screenshot(path='art5_%s.png'%k)
        print('errors',errs,'404',bad)
        await b.close()
    finally: srv.terminate()
asyncio.run(main())
