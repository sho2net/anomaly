# v3.17 戦闘背景の表示確認
import asyncio, subprocess, time
from playwright.async_api import async_playwright
async def main():
    srv=subprocess.Popen(['python3','-m','http.server','8766'],cwd='/home/claude/anomaly',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(0.6)
    try:
      async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':780}, device_scale_factor=2)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('http://localhost:8766/index.html'); await pg.evaluate('localStorage.clear()'); await pg.reload(); await pg.wait_for_timeout(400)
        await pg.click('#btnAdv'); await pg.wait_for_timeout(300)
        await pg.click('.advcolors button[data-c="grow"]'); await pg.wait_for_timeout(300)
        bs=await pg.query_selector_all('.advnodes button')
        for x in bs:
            t=await x.inner_text()
            if '戦' in t or '敵' in t: await x.click(); break; await pg.wait_for_timeout(500)
        if await pg.query_selector('#fight'):
            await pg.click('#fight'); await pg.wait_for_timeout(900)
            mg=await pg.query_selector('#mgo')
            if mg: await mg.click(); await pg.wait_for_timeout(1500)
        await pg.screenshot(path='bg1.png')
        await pg.evaluate("()=>{ const r=__adv.run(); r.pending.en.final=true; __rb(); }"); await pg.wait_for_timeout(500); await pg.screenshot(path='bg2.png')
        print(await pg.evaluate("document.getElementById('app').dataset.bg"))
        print('errors',errs)
        await b.close()
    finally: srv.terminate()
asyncio.run(main())
