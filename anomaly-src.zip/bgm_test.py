# BGM の確認：場面ごとに正しい曲へ切り替わるか、ループ点、サウンド設定。ローカルのHTTPサーバー（port 8765）で開く
import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
        pg=await b.new_page(viewport={'width':390,'height':800})
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('http://localhost:8765/index.html'); await pg.wait_for_timeout(300)
        await pg.evaluate("localStorage.clear()"); await pg.reload(); await pg.wait_for_timeout(300)
        async def cur(label):
            await pg.wait_for_timeout(1500); print(label, '→', await pg.evaluate("AN.BGM.current()+' ('+AN.BGM.track()+')'"))
        await pg.mouse.click(10,10); await cur('タイトル')
        await pg.click('#btnNew'); await cur('対戦設定')
        await pg.fill('#seed','bg'); await pg.click('#go'); await cur('デッキ構築')
        await pg.click('#auto'); await pg.click('#go'); await cur('対戦')
        if await pg.query_selector('#mgo'): await pg.click('#mgo'); await pg.wait_for_timeout(400)
        await pg.click('#snd'); await pg.wait_for_timeout(200); await pg.screenshot(path='bgm_sheet.png')
        await pg.click('#sgM button[data-v="0"]'); await pg.wait_for_timeout(300); print('音楽オフ', await pg.evaluate("AN.BGM.isOn()"))
        await pg.click('#sgM button[data-v="1"]'); await pg.wait_for_timeout(1500); print('音楽オン →', await pg.evaluate("AN.BGM.current()"))
        await pg.click('#sdone')
        await pg.goto('http://localhost:8765/index.html'); await pg.wait_for_timeout(300); await pg.mouse.click(10,10)
        await pg.click('#btnAdv'); await pg.click('#segD button[data-v="1"]'); await pg.click('.advcolors button[data-c="tide"]'); await cur('冒険の地図')
        await pg.evaluate("__adv.show('advShop')"); await cur('店')
        await pg.evaluate("(()=>{ const r=__adv.run(); r.areaIdx=r.areas.length; r.choices=['final','continue']; r.stage='map'; __adv.save(); __adv.show('advMap'); })()")
        await pg.click('.advnodes button:has-text("歪みの果て")'); await pg.click('#fight'); await cur('ハード最終ボス')
        info=await pg.evaluate("""(async()=>{ const out={}; for(const k of AN.BGM.tracks){ const r=await fetch('bgm/'+k+'.mp3'); const ab=await r.arrayBuffer(); const c=new OfflineAudioContext(2,48000,48000); const buf=await c.decodeAudioData(ab); out[k]=+buf.duration.toFixed(3); } return out; })()""")
        print('decoded durations', info)
        print('errors', errs or 'none')
        await b.close()
asyncio.run(main())
