const AN=require('./ai.js');
const N=parseInt(process.env.N||'200');
AN.BOSSES.forEach((b,bi)=>{
  let w=0,t=0;
  for(let i=0;i<N;i++){
    const rng=AN.makeRng('boss'+bi+'_'+i);
    const pool=AN.drawPool(rng,87,null); for(let j=0;j<3;j++) pool.unshift(AN.makeAnomaly(rng,j,null));
    const main=AN.AI.bestMain(pool); const deck=AN.AI.autoDeck(pool,rng,main);
    const bd=AN.AI.bossDeck(b,rng);
    const g=new AN.Game({seed:'bs'+i,decks:[deck,bd.deck],names:['P',b.name],mains:[main,b.attr],choosers:[AN.AI.chooser(3),AN.AI.chooser(3)],lifes:[0,b.life],leaders:[null,b.leader],energyBonus:[0,b.energy],bossRules:[null,b.special==='anomaly'?{chaos:true}:null]});
    let s=0; while(g.winner==null&&s++<5000) AN.AI.step(g,3);
    if(g.winner===0) w++; t+=g.turn;
  }
  console.log(b.name, 'プレイヤー側（強CPU）の勝率', Math.round(w/N*100)+'%', '平均手番', (t/N).toFixed(1));
});
