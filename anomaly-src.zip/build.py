import re
page=open('page.html',encoding='utf-8').read()
import json, os
BGMT=json.dumps(json.load(open('bgm/tracks.json',encoding='utf-8'))) if os.path.exists('bgm/tracks.json') else '{}'
parts=[open(f,encoding='utf-8').read().replace('/*BGM_TRACKS*/{}',BGMT) for f in ['cards.js','icons.js','engine.js','ai.js','net.js','fx.js','ui.js']]
parts[-1]=parts[-1].replace('/*ADV*/', open('adv_ui.js',encoding='utf-8').read()+'\n'+open('tut_ui.js',encoding='utf-8').read())
js='\n'.join(parts)
out=page.replace('<!--SCRIPTS-->','<script>\n'+js+'\n</script>')
open('index.html','w',encoding='utf-8').write(out)
print(len(out))
# 効果音・エフェクトの試聴ページ（ゲーム本体とは別。Firebase は読まない）
lab_page=re.sub(r'<!-- Firebase.*?</script>\s*<script>.*?</script>\s*', '', page, flags=re.S).replace('<title>ANOMALY</title>','<title>ANOMALY 効果音テスト</title>')
lab_js='\n'.join(open(f,encoding='utf-8').read().replace('/*BGM_TRACKS*/{}',BGMT) for f in ['cards.js','icons.js','fx.js','lab.js'])
open('lab.html','w',encoding='utf-8').write(lab_page.replace('<!--SCRIPTS-->','<script>\n'+lab_js+'\n</script>'))
