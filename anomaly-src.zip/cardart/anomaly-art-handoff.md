# ANOMALY 追加の画像 生成の引き継ぎ（アノマリー絵・共有用画像）

ANOMALY のチャットから、画像生成を担当するセッションへの引き継ぎ。前回のカード絵と同じ流れで、今回は **アノマリー（毎試合生まれる謎のカード）の絵** と、**SNS で共有したときに出る画像** を作る。

## 前回の学びをそのまま使う

- 「trading card illustration」とは書かない（カードそのものを描いてしまう）
- 否定形（no text, no border…）は使わず、肯定形で書く
- 「painting」ではなく「digital artwork」
- 文字が出やすい題材（本・巻物・看板）は避ける

## 1. アノマリーの絵（28種・各2枚）

- サイズ：**縦 768×1024**（カード絵と同じ）
- 保存先：`C:\Users\user\Downloads\ANOMALY_art\anomaly\`、ファイル名は `<ファイル名>_1.png`・`_2.png`
- すべてのプロンプトの末尾に次を付ける：

```
, dark fantasy digital artwork filling the entire canvas edge to edge, one clear subject in the center, bold readable silhouette, simple dark background, dramatic lighting, glowing cracks of pink, violet and cyan light around the subject like distorted reality, mysterious and uncanny
```

### 伝説のアノマリー（11種）

| ファイル名 | 型 | プロンプト（＋共通部分） |
|---|---|---|
| anom_jester | 狂乱の道化 | A frenzied jester juggling glowing orbs of many different spells, a manic grin, tattered motley clothes |
| anom_seer | 星詠みの賢者 | An old star-reading sage holding a floating astrolabe, constellations swirling around his hands |
| anom_usurp | 簒奪の魔王 | A demon lord seizing a crown from the air, clawed hand, a throne of broken chains behind him |
| anom_gear | からくり技師 | A mad clockwork inventor surrounded by small mechanical golems, brass gears floating in the air |
| anom_reckless | 無謀な英雄 | A reckless hero charging forward with two swords raised, cape torn, fearless expression |
| anom_titan | 終末の巨神 | A colossal titan of the apocalypse towering over a ruined world, cracked stone body |
| anom_sun | 灼熱の太陽神 | A sun god with a blazing sun disc behind the head, radiant and merciless, heat waves |
| anom_soul | 英霊の王 | A king of heroic spirits surrounded by ghostly fallen warriors rising behind him |
| anom_time | 時の支配者 | A master of time holding a giant hourglass, clock hands orbiting around the body |
| anom_queen | 鏡の女王 | A queen made of mirrors, her dress of glass shards reflecting many copies of herself |
| anom_undead | 冥府の王 | A king of the underworld raising the dead from open graves with one hand |

### ふつうのアノマリー（クリーチャー6種・スペル4種）

名前も効果もランダムなので、絵は「謎の存在」として作る。

| ファイル名 | プロンプト（＋共通部分） |
|---|---|
| anom_cr1 | A strange creature whose body is made of shifting playing card fragments |
| anom_cr2 | A masked wanderer with a glowing hole in the chest where the heart should be |
| anom_cr3 | A beast with too many eyes, fur flowing like smoke |
| anom_cr4 | A knight whose armor is cracked open, revealing starlight inside instead of a body |
| anom_cr5 | A floating serpent made of glass and light, coiling in the air |
| anom_cr6 | A small hooded creature holding a lantern that shines with impossible colors |
| anom_sp1 | A tear in the air opening onto a swirling galaxy, fragments of reality floating around it |
| anom_sp2 | A glowing sigil circle unfolding in the dark, runes made only of geometric shapes |
| anom_sp3 | A hand reaching out of a cracked mirror, light pouring through the cracks |
| anom_sp4 | An orb of liquid light bursting outward, shards of color spiraling |

### 奇妙なアノマリー（クリーチャー4種・スペル3種）

役に立つかどうか分からない「奇妙」枠。少しユーモラスで不気味な雰囲気。

| ファイル名 | プロンプト（＋共通部分） |
|---|---|
| anom_wc1 | A tiny odd creature wearing a teacup as a hat, staring with huge round eyes |
| anom_wc2 | A walking puppet with tangled strings rising into the darkness above |
| anom_wc3 | A cat-like shadow with a crescent smile floating in the air |
| anom_wc4 | A stack of mismatched masks balancing on thin legs |
| anom_ws1 | A spinning wheel of fortune made of cards, blurred with motion |
| anom_ws2 | A door standing alone in empty space, slightly open, colored light leaking out |
| anom_ws3 | A pair of dice made of glass tumbling in the air, stars inside them |

## 2. SNS で共有したときの画像（1種・3枚）

X や LINE でゲームのURLを貼ったときに表示される横長の画像。**文字（ロゴ）は ANOMALY 側で後から重ねる**ので、絵には入れない。

- サイズ：**横 1344×768**（ANOMALY 側で 1200×630 に切り抜く）
- 保存先：`C:\Users\user\Downloads\ANOMALY_art\ogp\`、ファイル名 `ogp_1.png`〜`ogp_3.png`
- プロンプト：

```
A single mysterious glowing card floating above an ancient stone altar in a vast dark hall, the card tearing open a rift of pink, violet and cyan light, many other cards drifting in the air like leaves, the right half of the image is calm dark empty space, wide cinematic composition, dark fantasy digital artwork filling the entire canvas edge to edge, rich deep colors, dramatic lighting, atmospheric
```

（右半分を暗く空けてあるのは、ロゴと一言紹介を重ねるため）

## 作り直す条件（その1枚だけもう1回）

- 文字・記号・ロゴが目立って入っている
- 枠・額縁・カードの枠が描かれている
- 実在のキャラクターや有名作品にそっくり
- ほとんど何も描かれていない

## 終わったら

ショウさんに、できた枚数と作り直した枚数を伝える。選別と組み込みは ANOMALY のチャットでやる。
