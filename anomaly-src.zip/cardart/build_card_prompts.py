# カード絵の生成リスト（JSON と指示書の表）を作る：python3 cardart/build_card_prompts.py
import json, subprocess, sys
sys.path.insert(0,'cardart'); from subjects import S
cards=json.loads(subprocess.check_output(['node','-e',"const AN=require('./cards.js'); console.log(JSON.stringify(AN.CARDS.map(d=>({id:d.id,name:d.name,attr:d.attr[0]||'none',type:d.type,rarity:d.rarity}))))"]))
LIGHT={'flare':'red and orange firelight','tide':'deep blue and cyan water light','grow':'emerald green forest light',
       'ray':'golden and white holy light','void':'violet and black shadowy light','none':'warm neutral lantern light, grey stone tones'}
STYLE='dark fantasy trading card illustration, one clear subject in the center, bold readable silhouette, simple dark background, painterly digital art, dramatic lighting, no text, no letters, no symbols, no border, no frame, no card frame, no watermark'
order={'L':0,'R':1,'U':2,'C':3}
cards.sort(key=lambda c:(order[c['rarity']], c['id']))
out=[]
for i,c in enumerate(cards,1):
    p=S[c['id']]+', lit by '+LIGHT[c['attr']]+', '+STYLE
    out.append({'no':i,'file':'card_'+c['id']+'.png','name':c['name'],'rarity':c['rarity'],'width':768,'height':1024,'prompt':p})
json.dump(out,open('cardart/card_prompts.json','w'),ensure_ascii=False,indent=1)
print(len(out), out[0]['prompt'])
