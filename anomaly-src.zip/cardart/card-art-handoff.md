# ANOMALY カード絵 生成の引き継ぎ（Runpod／Z-Image Turbo 担当向け）

ANOMALY のチャットから、画像生成を担当するセッションへの引き継ぎ。前回（タイトル・地域・ボス・出来事）と同じ流れで、今回はカード231種の絵を作る。

## 今回のやり方（前回との違い）

- **1枚につき1回だけ生成する**（前回のように3枚ずつは作らない）。231種あるので、時間を優先する
- 作り直すのは、明らかな失敗だけにする（下の「作り直す条件」）。出来の良し悪しで何度も作り直さない
- 選別と組み込みは ANOMALY のチャットでやる。こちらは生成して保存するだけでよい

## 生成リスト

- `claude/anomaly-card-prompts.json`（プロジェクトのドキュメント）に231件入っている。ショウさんの PC の `Downloads\Claude outputs\anomaly\cardart\card_prompts.json` にも同じものがある
- 各項目：`no`（通し番号）、`file`（保存するファイル名）、`name`（カード名。参考用）、`rarity`、`width`/`height`、`prompt`
- **プロンプトは完成形**なので、そのまま使う。画風・属性の光・「文字なし・枠なし」の指定も末尾に入っている
- 並び順は、伝説（L 11枚）→ レア（R 34枚）→ アンコモン（U 72枚）→ コモン（C 114枚）。**途中で止まっても、目立つカードから揃うように、この順番で進める**

## 設定

- サイズ：**768×1024（縦長 3:4）**。全件共通
- Turbo の標準設定のまま（ステップ8前後・CFG 1前後）
- シードはランダムでよい

## 保存先

- `C:\Users\user\Downloads\ANOMALY_art\cards\` に、リストの `file` の名前（例：`card_F31.png`）で PNG のまま保存
- 前回の画像（`ANOMALY_art` の直下）はそのまま残す

## 作り直す条件（この場合だけ、その1枚をもう1回生成）

- 絵の中に文字・記号・ロゴが目立って入っている
- 白い枠・カードの枠・額縁が描かれている
- 真っ黒・真っ白など、ほとんど何も描かれていない
- 道路・車・現代の建物など、ファンタジーの世界に合わないものが写っている

それ以外（多少好みでない、構図が平凡など）は作り直さずに先へ進む。

## ついでにお願い（出来事の絵 2枚、作り直し）

前回の絵に不具合があった2つ。これだけは**3枚ずつ**生成して、同じ `ANOMALY_art` の直下に保存する。

| ファイル名 | 横 1344×768 | プロンプト |
|---|---|---|
| ev_library_v4_1〜3 | 禁書庫 | A forbidden library in a dark vault, tall shelves of old books bound in iron chains, one glowing playing card trapped between pages on a lectern, a sleeping stone guardian statue, candlelight, the book spines are plain leather with no writing, dark fantasy painterly digital illustration, rich deep colors, dramatic cinematic lighting, highly detailed, atmospheric, no text, no letters, no runes, no signs, no watermark, no border, no frame |
| ev_champion_v2_1〜3 | さすらいの強者 | A lone wandering swordsman standing on a narrow dirt path across a wild windswept moor at sunset, medieval, long cloak blowing in the wind, a sheathed sword, distant ruined castle, calm and dangerous, no road markings, no asphalt, no modern objects, dark fantasy painterly digital illustration, rich deep colors, dramatic cinematic lighting, highly detailed, atmospheric, no text, no letters, no watermark, no border, no frame |

（前回の不具合：禁書庫は本の背などに崩れた文字が出た。さすらいの強者は白線のあるアスファルトの道路が写った）

## 追加：戦闘画面の背景（9種・各2枚）

戦闘中、カードの後ろに暗くして敷く背景。**各2枚**生成して `C:\Users\user\Downloads\ANOMALY_art\bg\` に `ファイル名_1.png`・`_2.png` で保存する（例：`bg_battle_1.png`）。**カード絵より先にこちらを作ってよい**（9種しかないので短時間で済む）。

- サイズ：**縦 768×1344**（タイトル画面と同じ）
- 上にカードが並ぶので、**人物・怪物は入れず、景色だけ**。画面の中央は静かで暗めに
- すべてのプロンプトの末尾に次を付ける：

```
empty environment background plate, no people, no creatures, no characters, calm dark center, soft depth of field, low contrast, vertical composition, dark fantasy painterly digital illustration, rich deep colors, atmospheric, no text, no letters, no watermark, no border, no frame
```

| ファイル名 | 使う場面 | プロンプト（＋上の共通部分） |
|---|---|---|
| bg_battle | 標準（属性が決まらないとき） | An ancient circular stone arena inside a vast candlelit hall, worn floor with a faint engraved magic circle, pillars fading into darkness |
| bg_flare | 炎の相手・火山の地域 | A battleground on black volcanic rock, distant rivers of lava glowing, embers drifting in the air, red haze |
| bg_tide | 水の相手・海底神殿 | The floor of a sunken temple deep underwater, broken pillars, pale blue light shafts from above, drifting bubbles |
| bg_grow | 森の相手・大森林 | A mossy clearing in an ancient forest surrounded by colossal tree roots, green glowing spores, misty light |
| bg_ray | 光の相手・天空の聖都 | A white marble terrace above the clouds, golden light rays, distant spires, soft glowing haze |
| bg_void | 闇の相手・冥府の墓所 | A necropolis courtyard among tombs, violet ghost-fire in iron braziers, dark mist, a pale moon |
| bg_anomaly | ボス「特異点アノマリア」 | A void of broken reality, floating fragments of stone and cards, cracks of pink, violet and cyan light in the darkness |
| bg_devourer | 最終ボス 万象喰らい | The edge of a bottomless abyss, falling stars and shattered cards being pulled into the darkness, faint pink and violet cracks |
| bg_judge | ハード最終ボス 審判者 | The interior of a ruined cathedral split into light and darkness, the left side golden light, the right side violet shadow, great bells hanging |

## 終わったら

- ショウさんに、背景とカード絵がそれぞれ何枚できたか・作り直した枚数・生成できなかったもの（あれば番号）を伝える
- 途中で区切る場合は、最後に保存した `no` を伝えてもらえれば、次回はその続きから始める
