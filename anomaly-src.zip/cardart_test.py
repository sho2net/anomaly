# v3.17 カード絵の表示確認（戦闘・拡大表示・図鑑・出来事）
import asyncio, subprocess, time
from playwright.async_api import async_playwright
async def main():
    srv=subprocess.Popen(['python3','-m','http.server','8767'],cwd='/home/claude/anomaly',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(0.6)
    try:
      async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':780}, device_scale_factor=2)
        errs=[]; bad=[]; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('response', lambda r: bad.append(r.url) if r.status>=400 else None)
        await pg.goto('http://localhost:8767/index.html'); await pg.evaluate('localStorage.clear()'); await pg.reload(); await pg.wait_for_timeout(400)
        await pg.click('#btnCodex'); await pg.wait_for_timeout(1200); await pg.screenshot(path='ca1.png')
        await pg.click('.card'); await pg.wait_for_timeout(600); await pg.screenshot(path='ca2.png')
        await pg.evaluate("__adv.show('title')"); await pg.wait_for_timeout(200)
        await pg.click('#btnAdv'); await pg.wait_for_timeout(300); await pg.click('.advcolors button[data-c="flare"]'); await pg.wait_for_timeout(300)
        for x in await pg.query_selector_all('.advnodes button'):
            t=await x.inner_text()
            if '戦' in t or '敵' in t: await x.click(); break
        await pg.wait_for_timeout(500)
        if await pg.query_selector('#fight'):
            await pg.click('#fight'); await pg.wait_for_timeout(900)
            mg=await pg.query_selector('#mgo')
            if mg: await mg.click()
        await pg.wait_for_timeout(6000); await pg.screenshot(path='ca3.png')
        for k in ['library','champion']:
            await pg.evaluate("k=>{ const r=__adv.run(); r.event={key:k,pick:['F01','F02','F03']}; __adv.show('advEvent'); }",k); await pg.wait_for_timeout(700)
            await pg.screenshot(path='ca_%s.png'%k)
        print('errors',errs,'404',[u for u in bad if 'bg_' not in u])
        await b.close()
    finally: srv.terminate()
asyncio.run(main())
