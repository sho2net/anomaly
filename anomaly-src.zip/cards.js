// ===== ANOMALY cards.js =====
var AN = (typeof AN !== 'undefined') ? AN : {};
(function(){

// ---- seeded RNG ----
function hashStr(s){ let h=1779033703^s.length; for(let i=0;i<s.length;i++){ h=Math.imul(h^s.charCodeAt(i),3432918353); h=h<<13|h>>>19; } return (h>>>0); }
function makeRng(seed){
  let a = (typeof seed==='number') ? seed>>>0 : hashStr(String(seed));
  const f = function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; };
  f.int = (n)=>Math.floor(f()*n);
  f.pick = (arr)=>arr[Math.floor(f()*arr.length)];
  f.shuffle = (arr)=>{ const a=arr.slice(); for(let i=a.length-1;i>0;i--){ const j=Math.floor(f()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; } return a; };
  return f;
}

const ATTRS = {
  flare:{ n:'炎', k:'フレア', c:'#E5533D', c2:'#5A2118' },
  tide: { n:'水', k:'タイド', c:'#3D8FE5', c2:'#17355C' },
  grow: { n:'森', k:'グロウ', c:'#4CAF6A', c2:'#1B4A2A' },
  ray:  { n:'光', k:'レイ',   c:'#E8C45C', c2:'#5E4A15' },
  void: { n:'闇', k:'ヴォイド', c:'#9B8CCB', c2:'#2E2547' },
  none: { n:'無', k:'ニュートラル', c:'#9AA7B2', c2:'#3A4750' },
};
const ATTR_ORDER = ['flare','tide','grow','ray','void'];
const ATTR_ALL = ['flare','tide','grow','ray','void','none'];
const RARITY = { T:{n:'秘宝',w:0}, C:{n:'コモン',w:60}, U:{n:'アンコモン',w:28}, R:{n:'レア',w:10}, L:{n:'レジェンド',w:2}, A:{n:'アノマリー',w:0} };
const KW = {
  haste:'速攻', blocker:'守護', unblockable:'不可視', breakthrough:'突破', armor:'装甲', drain:'吸収', double:'二段攻撃', deathtouch:'猛毒', noattack:'攻撃不能'
};
const KW_HELP = {
  haste:'出したターンに攻撃できる', blocker:'このクリーチャーがスタンドしている間、相手はこのクリーチャー以外を攻撃できない',
  unblockable:'守護を無視して攻撃できる', breakthrough:'クリーチャーを攻撃したとき、相手の残り体力を超えた分のダメージが相手プレイヤーのライフに通る（装甲には止められる）',
  armor:'1回だけダメージまたは破壊を無効にする', drain:'相手のライフを減らした分、自分のライフを回復する', double:'1ターンに2回攻撃できる', deathtouch:'このクリーチャーから1以上のダメージを受けたクリーチャーは破壊される（装甲で防げる）', noattack:'このクリーチャーは攻撃できない（守護にはなれる）'
};
const BASE_POWER = {1:2,2:3,3:4,4:5,5:6,6:7,7:8,8:9};

// ---- helpers to define cards ----
function C(id,name,attr,cost,power,hp,rarity,kw,effects,flavor){ return {id,name,attr:attr==='none'?[]:[attr],type:'creature',cost,power,hp,rarity,kw:kw||[],effects:effects||[],flavor}; }
function S(id,name,attr,cost,rarity,effects,flavor){ return {id,name,attr:attr==='none'?[]:[attr],type:'spell',cost,power:0,hp:0,rarity,kw:[],effects:effects||[],flavor}; }
function E(id,name,attr,cost,rarity,equip,flavor){ return {id,name,attr:attr==='none'?[]:[attr],type:'equip',cost,power:0,hp:0,rarity,kw:[],effects:[],equip,flavor}; }
const ef = (t,e,o)=>Object.assign({t,e},o||{});


// ================= v2.0 カードプール =================
// 属性ごとの看板メカニクス：炎=連撃（このターンに他のカードをN枚プレイ済み）、水=詠唱（手札にある間、スペルを唱えるたびに強化）、
// 森=繁茂（最大エナジー7以上）、光=祈り（このゲームで回復した回数）、闇=供物（墓地に送られた自分のカード数を消費）
function K(id,name,attr,cost,rarity,kw,effects,o){ return Object.assign({id,name,attr:attr==='none'?[]:[attr],type:'creature',cost,rarity,kw:kw||[],effects:effects||[],power:0,hp:0},o||{}); }
function R_(id,name,attr,cost,rarity,effects,o){ return Object.assign({id,name,attr:attr==='none'?[]:[attr],type:'relic',cost,rarity,kw:[],effects:effects||[],power:0,hp:0},o||{}); }
function T_(id,name,attr,cost,rarity,effects,o){ return Object.assign({id,name,attr:attr==='none'?[]:[attr],type:'trap',cost,rarity,kw:[],effects:effects||[],power:0,hp:0},o||{}); }
function P(id,name,attr,cost,rarity,effects,o){ return Object.assign({id,name,attr:attr==='none'?[]:[attr],type:'spell',cost,rarity,kw:[],effects:effects||[],power:0,hp:0},o||{}); }
const R1=(o)=>Object.assign({},o);
const CARDS = [
// ---------- 炎：連撃（ウィニー／バーン）----------
K('F01','火花の小鬼','flare',1,'C',['haste'],[],{i:'imp',st:[2,1]}),
K('F02','灰かぶり','flare',1,'C',[],[ef('etb','dmg',{n:1,req:{combo:1}})],{i:'hood'}),
K('F03','炎の斥候','flare',1,'C',[],[ef('etb','tokens',{n:1,tok:'flare',req:{combo:1}})],{i:'runner'}),
P('F04','火の粉','flare',1,'C',[ef('cast','dmg',{n:2}),ef('cast','damage',{n:1,req:{combo:1}})],{i:'spark'}),
K('F05','突撃兵','flare',2,'C',['haste'],[ef('etb','pumpSelf',{n:1,req:{combo:1}})],{i:'banner'}),
K('F06','火吹き','flare',2,'C',[],[ef('etb','ping',{n:1})],{i:'flame'}),
K('F07','鍛冶の見習い','flare',2,'C',[],[ef('etb','buff',{n:2})],{i:'axe'}),
P('F08','火の玉','flare',2,'C',[ef('cast','dmg',{n:2,scale:'combo',k:1,max:4})],{i:'fireball'}),
P('F09','炎の軍勢','flare',3,'C',[ef('cast','tokens',{n:2,tok:'flare'}),ef('cast','tokens',{n:1,tok:'flare',req:{combo:2}})],{i:'bonfire'}),
K('F10','双剣の傭兵','flare',3,'C',['haste','double'],[],{i:'sword',st:[2,2]}),
P('F11','火炎放射','flare',3,'C',[ef('cast','dmgAll',{n:1}),ef('cast','damage',{n:2,req:{combo:1}})],{i:'sun'}),
K('F12','赤熱の斧使い','flare',3,'C',[],[ef('etb','dmg',{n:2})],{i:'axe'}),
K('F13','爆竹の精','flare',2,'C',[],[ef('death','randomDmg',{n:2})],{i:'spark'}),
K('F14','焔の伝令','flare',3,'C',[],[ef('play','damage',{n:1})],{i:'banner'}),
P('F15','猛火','flare',4,'C',[ef('cast','damage',{n:3,scale:'combo',k:1,max:3})],{i:'bonfire'}),
K('F16','火竜の幼体','flare',4,'C',['haste'],[ef('etb','dmg',{n:2,req:{combo:1}})],{i:'dragon'}),
K('F17','炎の指揮官','flare',4,'U',[],[ef('static','aura',{n:1,attr:'flare'})],{i:'helm'}),
P('F18','連鎖爆発','flare',2,'U',[ef('cast','randomDmg',{n:2,scale:'combo',k:2,max:6})],{i:'explosion'}),
P('F19','火花の祭典','flare',1,'U',[ef('cast','energyNow',{n:1}),ef('cast','draw',{n:1})],{i:'star'}),
K('F20','爆炎の魔導士','flare',3,'U',[],[ef('ability','randomDmgCr',{n:2})],{i:'mage'}),
P('F21','突撃の号令','flare',3,'U',[ef('cast','grantAll',{kw:'haste'}),ef('cast','buffAll',{n:1})],{i:'banner'}),
K('F22','灼熱の槍兵','flare',5,'U',['haste'],[ef('etb','dmg',{n:3,req:{combo:1}})],{i:'spear'}),
K('F23','火薬樽','flare',1,'U',[],[ef('death','dmgAllBoth',{n:2})],{i:'barrel'}),
K('F24','業火の魔女','flare',4,'U',[],[ef('spell','damage',{n:1})],{i:'witch'}),
K('F25','炎の予言者','flare',2,'U',[],[ef('etb','randomCard',{req:{combo:1}})],{i:'eye'}),
K('F26','焔の双子','flare',3,'R',['haste'],[ef('etb','cloneSelf',{req:{combo:1}})],{i:'imp'}),
K('F27','火山竜','flare',6,'R',['haste'],[ef('etb','dmgAll',{n:2})],{i:'dragon'}),
K('F28','燃え尽きる英雄','flare',2,'R',['haste'],[ef('endturn','selfDestroy',{})],{i:'phoenix',st:[5,1]}),
K('F29','炎帝の親衛','flare',5,'R',['haste'],[ef('play','pumpSelf',{n:1})],{i:'knight'}),
P('F30','流星雨','flare',5,'R',[ef('cast','randomDmg',{n:8})],{i:'meteor'}),
K('F31','炎帝イグニス','flare',7,'L',['haste'],[ef('etb','dmgAll',{n:1,scale:'combo',k:1,max:4}),ef('etb','damage',{n:5,req:{combo:3}})],{i:'crown'}),
K('F32','紅蓮の申し子','flare',1,'L',['haste'],[ef('play','pumpSelf',{n:1}),ef('play','damage',{n:1})],{i:'flame',st:[1,1]}),
// ---------- 水：詠唱（テンポ／スペルコントロール）----------
K('T01','水の精','tide',1,'C',[],[],{i:'drop'}),
K('T02','泡の見習い','tide',1,'C',[],[ef('spell','pumpSelf',{n:1})],{i:'bubbles'}),
K('T03','潮読みの学徒','tide',2,'C',[],[ef('etb','boostHand',{n:1})],{i:'scroll'}),
P('T04','知識の泉','tide',3,'C',[ef('cast','draw',{n:2})],{i:'book',sb:'cost'}),
P('T05','凍てつく手','tide',1,'C',[ef('cast','freeze',{})],{i:'hand'}),
P('T06','引き波','tide',2,'C',[ef('cast','bounce',{})],{i:'undertow'}),
K('T07','霧の忍び','tide',2,'C',['unblockable'],[],{i:'ninja'}),
P('T08','水鏡','tide',1,'C',[ef('cast','tap',{})],{i:'mirror'}),
K('T09','深海の書記','tide',4,'C',[],[ef('etb','draw',{n:1})],{i:'fish',sb:'cost'}),
K('T10','波濤の術士','tide',3,'C',[],[ef('etb','dmg',{n:1,scale:'boost',k:1,max:5})],{i:'mage',sb:'grow'}),
K('T11','氷の番兵','tide',3,'C',[],[ef('etb','freeze',{})],{i:'snowflake'}),
K('T12','海馬','tide',4,'C',[],[ef('etb','draw',{n:1})],{i:'seahorse'}),
P('T13','渦潮','tide',3,'C',[ef('cast','dmg',{n:2,scale:'boost',k:1,max:6})],{i:'swirl',sb:'grow'}),
K('T14','潮流の魚群','tide',2,'C',[],[ef('etb','tap',{})],{i:'shoal'}),
P('T15','泡沫の術','tide',0,'C',[ef('cast','boostHand',{n:1}),ef('cast','draw',{n:1})],{i:'bubbles'}),
P('T16','大渦','tide',6,'C',[ef('cast','freezeAll',{})],{i:'wave',sb:'cost'}),
K('T17','海蛇','tide',4,'U',['unblockable'],[ef('spell','pumpSelf',{n:1})],{i:'serpent'}),
K('T18','潮流の賢者','tide',4,'U',[],[ef('spell','randomDmgCr',{n:1})],{i:'elder'}),
P('T19','記憶の消去','tide',3,'U',[ef('cast','shuffleBack',{})],{i:'moon'}),
P('T20','泡沫の呪い','tide',4,'U',[ef('cast','polymorph',{})],{i:'mask'}),
K('T21','氷結の魔女','tide',4,'U',[],[ef('etb','freeze',{}),ef('etb','draw',{n:1,req:{boost:2}})],{i:'witch',sb:'flag'}),
P('T22','深淵の書','tide',6,'U',[ef('cast','draw',{n:3})],{i:'book',sb:'cost'}),
P('T23','思考の盗み','tide',1,'U',[ef('cast','copyHand',{})],{i:'eye'}),
K('T24','幻影の暗殺者','tide',6,'U',['unblockable'],[],{i:'dagger',sb:'cost'}),
K('T25','深海の予言者','tide',3,'U',[],[ef('etb','scry',{n:3})],{i:'seahorse'}),
P('T26','大海嘯','tide',8,'R',[ef('cast','bounceAll',{})],{i:'bigwave',sb:'cost'}),
P('T27','時の逆流','tide',3,'R',[ef('cast','draw',{n:2}),ef('cast','boostHand',{n:2})],{i:'hourglass'}),
K('T28','水の大精霊','tide',9,'R',[],[ef('etb','freezeAll',{})],{i:'tentacles',sb:'cost'}),
K('T29','深淵の大海獣','tide',6,'R',[],[ef('etb','bounce',{})],{i:'tentacles'}),
K('T30','鏡の魔術師','tide',3,'R',[],[ef('etb','recallSpell',{}),ef('etb','boostHand',{n:1})],{i:'mirror'}),
K('T31','潮王ネレイス','tide',8,'L',['unblockable'],[ef('spell','draw',{n:1})],{i:'trident',sb:'cost'}),
K('T32','大賢者アクア','tide',5,'L',[],[ef('etb','randomDmg',{n:0,scale:'spells',k:1,max:12})],{i:'staff'}),
// ---------- 森：繁茂（ランプ／成長ビート）----------
K('G01','若葉の妖精','grow',2,'C',[],[ef('etb','ramp',{n:1})],{i:'leaf'}),
K('G02','森の狼','grow',2,'C',[],[],{i:'wolf'}),
K('G03','苗木の妖精','grow',2,'C',[],[ef('etb','tokens',{n:1,tok:'grow'})],{i:'sprout'}),
P('G04','芽吹き','grow',1,'C',[ef('cast','energyNow',{n:2})],{i:'bud'}),
K('G05','樹人の見習い','grow',3,'C',[],[ef('turnstart','pumpSelf',{n:1})],{i:'treant'}),
K('G06','突進猪','grow',3,'C',['breakthrough'],[],{i:'boar'}),
P('G07','大地の恵み','grow',2,'C',[ef('cast','ramp',{n:1}),ef('cast','draw',{n:1})],{i:'seed'}),
P('G08','格闘','grow',2,'C',[ef('cast','fight',{n:0})],{i:'fist'}),
K('G09','苔熊','grow',4,'C',[],[ef('etb','pumpSelf',{n:2,req:{awaken:1}})],{i:'bear'}),
K('G10','蔦の巨人','grow',5,'C',['breakthrough'],[ef('etb','tokens',{n:1,tok:'grow',req:{awaken:1}})],{i:'vine'}),
P('G11','大地の息吹','grow',1,'C',[ef('cast','pumpTarget',{n:2})],{i:'arrowup'}),
P('G12','実り','grow',3,'C',[ef('cast','draw',{n:2}),ef('cast','ramp',{n:1})],{i:'wheat'}),
K('G13','森の番人','grow',4,'C',[],[ef('ability','pumpSelf',{n:1})],{i:'shieldleaf'}),
K('G14','大角鹿','grow',4,'C',[],[ef('atk','pumpSelf',{n:1})],{i:'antler'}),
P('G15','森の呼び声','grow',2,'C',[ef('cast','tutor',{})],{i:'leaf'}),
K('G16','群れの長','grow',3,'C',[],[ef('summon','pumpSelf',{n:1})],{i:'wolf'}),
K('G17','大森林の賢樹','grow',5,'U',[],[ef('etb','ramp',{n:1}),ef('etb','draw',{n:1})],{i:'treant'}),
P('G18','自然の怒り','grow',3,'U',[ef('cast','fight',{n:3})],{i:'cloudbolt'}),
P('G19','巨大化','grow',2,'U',[ef('cast','pumpTarget',{n:3})],{i:'giant'}),
K('G20','樹海の巨獣','grow',7,'U',['breakthrough'],[ef('etb','pumpSelf',{n:2,req:{awaken:1}})],{i:'claw'}),
P('G21','恵みの雨','grow',4,'U',[ef('cast','ramp',{n:2}),ef('cast','heal',{n:3})],{i:'drop'}),
P('G22','大群','grow',4,'U',[ef('cast','tokens',{n:3,tok:'grow'})],{i:'wolf'}),
P('G23','進化','grow',3,'U',[ef('cast','evolve',{n:2})],{i:'bud'}),
K('G24','森の長老','grow',5,'U',[],[ef('static','aura',{n:1,attr:'grow'})],{i:'elder'}),
K('G25','世界樹の芽','grow',4,'U',[],[ef('turnstart','ramp',{n:1})],{i:'sprout'}),
P('G26','大進化','grow',5,'R',[ef('cast','evolve',{n:1,all:true})],{i:'tusk'}),
K('G27','太古の巨獣','grow',8,'R',['breakthrough'],[ef('etb','dmgAll',{n:2,req:{awaken:1}})],{i:'tusk'}),
K('G28','翠竜','grow',6,'R',[],[ef('etb','destroy',{req:{awaken:1}})],{i:'dragon',st:[6,6]}),
K('G29','森の王','grow',6,'R',[],[ef('etb','buffAll',{n:2}),ef('static','aura',{n:1})],{i:'crown'}),
K('G30','大地の心臓','grow',3,'R',[],[ef('turnstart','discountHand',{n:1,req:{awaken:1}})],{i:'heart',st:[2,4]}),
K('G31','大地母神ガイア','grow',9,'L',['breakthrough'],[ef('etb','pumpAll',{n:3})],{i:'goddess'}),
K('G32','森羅の守り手','grow',5,'L',[],[ef('etb','pumpAll',{n:1,req:{awaken:1}}),ef('etb','grantAll',{kw:'breakthrough',req:{awaken:1}})],{i:'oldtree'}),
// ---------- 光：祈り（守護コントロール／小型の群れ）----------
K('R01','光の従者','ray',1,'C',['blocker'],[],{i:'candle'}),
K('R02','見習い僧','ray',1,'C',[],[ef('etb','heal',{n:2})],{i:'hood'}),
K('R03','盾持ち','ray',2,'C',['blocker'],[],{i:'shield'}),
P('R04','癒しの詩','ray',1,'C',[ef('cast','heal',{n:3}),ef('cast','draw',{n:1,req:{pray:3}})],{i:'pray'}),
P('R05','光の羽の召喚','ray',2,'C',[ef('cast','tokens',{n:2,tok:'ray'}),ef('cast','heal',{n:1})],{i:'wings'}),
K('R06','天使の使い','ray',3,'C',[],[ef('etb','heal',{n:3})],{i:'wings'}),
P('R07','聖なる裁き','ray',2,'C',[ef('cast','destroy',{damaged:true})],{i:'scales'}),
P('R08','光の矢','ray',1,'C',[ef('cast','tap',{}),ef('cast','heal',{n:2})],{i:'arrow'}),
K('R09','守護騎士','ray',4,'C',['blocker'],[ef('etb','heal',{n:2})],{i:'knight'}),
K('R10','修道士','ray',2,'C',[],[ef('heal','pumpSelf',{n:1})],{i:'pray'}),
K('R11','光の壁','ray',3,'C',['blocker'],[],{i:'bricks'}),
K('R12','聖歌隊','ray',3,'C',[],[ef('heal','randomDmgCr',{n:1})],{i:'bell'}),
P('R13','天秤の裁き','ray',2,'C',[ef('cast','destroy',{damaged:true,maxCost:4})],{i:'gavel'}),
K('R14','聖堂の守り手','ray',4,'C',['blocker','armor'],[],{i:'cathedral'}),
K('R15','光の司祭','ray',3,'C',[],[ef('etb','heal',{n:2}),ef('etb','draw',{n:1,req:{pray:3}})],{i:'candle'}),
K('R16','巡礼者','ray',2,'C',[],[ef('etb','heal',{n:1}),ef('etb','pumpSelf',{n:2,req:{pray:5}})],{i:'lantern'}),
K('R17','聖騎士団長','ray',5,'U',[],[ef('static','aura',{n:1,attr:'ray'})],{i:'banner'}),
P('R18','天の裁き','ray',6,'U',[ef('cast','dmgAll',{n:1}),ef('cast','destroyAll',{damaged:true})],{i:'cloudbolt'}),
K('R19','守護天使','ray',5,'U',['blocker'],[ef('etb','heal',{n:4})],{i:'angel'}),
P('R20','聖なる盾','ray',1,'U',[ef('cast','grant',{kw:'armor'})],{i:'shield'}),
P('R21','光の軍旗','ray',4,'U',[ef('cast','grantAll',{kw:'armor'})],{i:'banner'}),
P('R22','天使の軍勢','ray',4,'U',[ef('cast','tokens',{n:2,tok:'ray'}),ef('cast','heal',{n:2})],{i:'wings'}),
P('R23','祈りの導き','ray',2,'U',[ef('cast','discover',{})],{i:'candle'}),
K('R24','光の審判者','ray',5,'U',[],[ef('etb','destroy',{damaged:true,anyIf:{pray:6}})],{i:'scales',st:[4,5]}), // v3.18.2: 祈り6で2体破壊→「対象の制限が外れる」に。4/6→4/5（冒険で3枚積むと勝率+13pt、レア並みに）
K('R25','慈愛の聖女','ray',3,'U',[],[ef('turnstart','heal',{n:2})],{i:'dove'}),
P('R26','大天使の慈悲','ray',4,'U',[ef('cast','heal',{n:6}),ef('cast','draw',{n:1})],{i:'heart'}),
K('R27','大天使','ray',6,'R',['blocker','armor'],[ef('turnstart','heal',{n:2})],{i:'angel'}),
P('R28','審判の光','ray',4,'R',[ef('cast','dmgAll',{n:0,scale:'pray',k:1,max:6})],{i:'sun'}),
K('R29','聖域の主','ray',5,'R',[],[ef('heal','pumpAll',{n:1})],{i:'halo'}),
K('R30','光の預言者','ray',3,'R',[],[ef('etb','scry',{n:3}),ef('etb','heal',{n:2})],{i:'eye'}),
K('R31','天光の女王セラフィナ','ray',7,'L',['blocker','armor'],[ef('turnstart','heal',{n:3}),ef('static','aura',{n:1})],{i:'crown'}),
K('R32','聖杯の守護者','ray',3,'L',[],[ef('etb','damage',{n:10,req:{pray:10}})],{i:'chalice',st:[2,4]}),
// ---------- 闇：供物（生贄・蘇生／手札破壊）----------
K('V01','骸の兵','void',1,'C',[],[ef('death','damage',{n:1})],{i:'skull'}),
K('V02','影の狩人','void',2,'C',[],[ef('etb','pumpSelf',{n:2,req:{souls:2}})],{i:'bow'}),
P('V03','悪夢','void',2,'C',[ef('cast','discard',{n:1,bonus:{req:{souls:3},n:1}})],{i:'moon'}),
P('V04','死の宣告','void',3,'C',[ef('cast','destroy',{maxCost:3})],{i:'scythe'}),
K('V05','吸血蝙蝠','void',2,'C',['drain'],[],{i:'bat'}),
K('V06','墓荒らし','void',3,'C',[],[ef('etb','revive',{maxCost:2})],{i:'shovel'}),
K('V07','呪いの人形','void',2,'C',[],[ef('death','draw',{n:1})],{i:'doll'}),
P('V08','腐敗','void',1,'C',[ef('cast','dmg',{n:1,bonus:{req:{souls:2},n:2}})],{i:'ooze'}),
K('V09','屍食鬼','void',4,'C',[],[ef('etb','lifecost',{n:2})],{i:'fangs'}),
K('V10','闇の司祭','void',3,'C',[],[ef('etb','damage',{n:2,bonus:{req:{souls:3},n:2}})],{i:'hood'}),
P('V11','生贄の祭壇','void',1,'C',[ef('cast','sac',{}),ef('cast','draw',{n:2})],{i:'tomb'}),
P('V12','骨の雨','void',3,'C',[ef('cast','randomDmg',{n:3}),ef('cast','tokens',{n:1,tok:'void'})],{i:'bones'}),
P('V13','屍の軍勢','void',3,'C',[ef('cast','tokens',{n:2,tok:'void'})],{i:'bones'}),
K('V14','影の小鬼','void',1,'C',[],[ef('death','discard',{n:1})],{i:'imp'}),
K('V15','夜の狩人','void',2,'C',[],[ef('etb','lifecost',{n:1})],{i:'ninja'}),
K('V16','墓守','void',3,'C',['drain'],[ef('death','revive',{maxCost:2})],{i:'tomb'}),
K('V17','死霊術士','void',5,'U',[],[ef('etb','revive',{maxCost:4}),ef('etb','revive',{maxCost:4,req:{souls:4}})],{i:'staff'}),
P('V18','吸魂','void',3,'U',[ef('cast','damage',{n:3}),ef('cast','heal',{n:3})],{i:'vortex'}),
P('V19','絶望','void',4,'U',[ef('cast','discard',{n:2,bonus:{req:{souls:4},n:1}})],{i:'brokenheart'}),
K('V20','骨の巨人','void',5,'U',[],[ef('allyDeath','pumpSelf',{n:1})],{i:'bones'}),
K('V21','影の刺客','void',4,'U',['drain'],[ef('etb','dmg',{n:3,req:{souls:3}})],{i:'mask'}),
P('V22','魂の契約','void',2,'U',[ef('cast','draw',{n:2}),ef('cast','lifecost',{n:2})],{i:'scroll'}),
P('V23','暗殺','void',4,'U',[ef('cast','destroy',{})],{i:'dagger'}),
P('V24','呪詛の書','void',3,'U',[ef('cast','deckAdd',{card:'hex',n:3})],{i:'book'}),
P('V25','死者の囁き','void',2,'U',[ef('cast','graveCopy',{})],{i:'ghost'}),
K('V26','死神','void',7,'R',[],[ef('etb','destroy',{})],{i:'scythe',st:[6,6]}),
P('V27','冥府の門','void',5,'R',[ef('cast','revive',{maxCost:6})],{i:'gate'}),
K('V28','影の王','void',5,'R',[],[ef('atk','dmg',{n:3})],{i:'darkcrown'}),
K('V29','屍竜','void',7,'R',[],[ef('etb','dmgAll',{n:2,bonus:{req:{souls:6},n:2}})],{i:'dragon'}),
K('V30','魂喰らい','void',3,'R',[],[ef('etb','devour',{})],{i:'ghost',st:[1,1]}),
K('V31','冥王ハデス','void',8,'L',['drain'],[ef('etb','destroy',{}),ef('death','revive',{maxCost:5})],{i:'skull'}),
P('V32','死の舞踏','void',6,'L',[ef('cast','reviveAllSelf',{req:{souls:10}}),ef('cast','draw',{n:2})],{i:'skull'}),
// ---------- 無属性 ----------
K('N01','見習い剣士','none',1,'C',[],[],{i:'sword'}),
K('N02','旅の商人','none',2,'C',[],[ef('etb','draw',{n:1})],{i:'scroll'}),
K('N03','傭兵','none',2,'C',[],[],{i:'soldier'}),
K('N04','石の守衛','none',3,'C',[],[],{i:'pillar'}),
K('N05','巨人の子','none',4,'C',[],[],{i:'giant'}),
K('N06','冒険者','none',3,'C',[],[ef('etb','draw',{n:1})],{i:'runner'}),
K('N07','治療師','none',2,'C',[],[ef('etb','heal',{n:2})],{i:'heart'}),
K('N08','斥候','none',1,'C',[],[ef('etb','scry',{n:2})],{i:'eye'}),
P('N09','狩りの網','none',2,'C',[ef('cast','dmg',{n:3})],{i:'spider'}),
P('N10','大砲','none',4,'C',[ef('cast','dmg',{n:4}),ef('cast','damage',{n:2})],{i:'meteor'}),
P('N11','交易','none',3,'C',[ef('cast','draw',{n:2}),ef('cast','heal',{n:2})],{i:'book'}),
P('N12','補給','none',2,'C',[ef('cast','heal',{n:4})],{i:'potion'}),
P('N13','民兵の召集','none',3,'C',[ef('cast','tokens',{n:2,tok:'none'})],{i:'banner'}),
K('N14','忠犬','none',1,'C',[],[ef('death','draw',{n:1})],{i:'dog'}),
K('N15','石像','none',6,'C',[],[],{i:'giant'}),
K('N16','旅の魔術師','none',3,'U',[],[ef('etb','transformHand',{n:1})],{i:'staff'}),
K('N17','傭兵隊長','none',4,'U',[],[ef('static','aura',{n:1})],{i:'helm'}),
P('N18','一騎当千','none',4,'U',[ef('cast','fight',{n:3})],{i:'fist'}),
P('N19','冒険の誘い','none',2,'U',[ef('cast','discover',{})],{i:'scroll'}),
P('N20','進化の秘薬','none',2,'U',[ef('cast','evolve',{n:1})],{i:'potion'}),
K('N21','英雄','none',5,'R',[],[ef('etb','pumpAll',{n:1})],{i:'crown'}),
K('N22','古代の巨像','none',8,'R',[],[],{i:'tusk',costFn:'allies'}),
K('N23','軍師','none',2,'U',[],[ef('etb','addCard',{card:'plan',n:1})],{i:'scroll'}),
P('N24','運命の一枚','none',1,'R',[ef('cast','randomCard',{})],{i:'star'}),
// ---- v3.3 追加：シナジーを軸にしたカード・置物・罠 ----
K('F50','火花の祭司','flare',3,'U',[],[ef('summon','damage',{n:1})],{i:'candle'}),
P('F51','焔の行進','flare',4,'U',[ef('cast','randomDmg',{n:0,scale:'field',k:1,max:7})],{i:'banner'}),
R_('F52','燃える戦旗','flare',2,'C',[ef('turnstart','damage',{n:1}),ef('expire','damage',{n:3})],{i:'banner',countdown:3}),
T_('F53','爆炎の罠','flare',2,'C',[ef('enemyAttack','dmg',{n:3})],{i:'explosion'}),
K('T50','知恵の番人','tide',3,'C',[],[ef('draw','pumpSelf',{n:1})],{i:'book'}),
P('T51','奔流','tide',5,'R',[ef('cast','dmg',{n:0,scale:'spells',k:1,max:10})],{i:'bigwave',sb:'cost'}),
K('T52','泡の群れ','tide',3,'C',[],[ef('etb','tokens',{n:1,tok:'tide'}),ef('spell','tokens',{n:1,tok:'tide'})],{i:'bubbles'}),
R_('T53','叡智の塔','tide',3,'U',[ef('spell','draw',{n:1})],{i:'pillar',countdown:3}),
T_('T54','渦の罠','tide',2,'C',[ef('enemyAttack','bounce',{})],{i:'swirl'}),
K('G50','群生の母','grow',5,'U',[],[ef('endturn','tokens',{n:1,tok:'grow'})],{i:'treant'}),
P('G51','森の大合唱','grow',5,'U',[ef('cast','pumpAll',{n:1}),ef('cast','pumpAll',{n:1,req:{allies:5}})],{i:'roar'}),
K('G52','傷を負った獣','grow',4,'C',[],[ef('damaged','pumpSelf',{n:1})],{i:'bear'}),
R_('G53','豊穣の祭壇','grow',3,'U',[ef('turnstart','pumpRandomAlly',{n:1})],{i:'wheat',countdown:4}),
T_('G54','茨の罠','grow',2,'C',[ef('enemySummon','dmg',{n:3})],{i:'vine'}),
K('R50','羽の司令','ray',3,'U',[],[ef('static','aura',{n:1,kwf:'blocker'})],{i:'wings'}),
K('R51','祝福の鐘','ray',2,'C',[],[ef('heal','tokens',{n:1,tok:'ray'})],{i:'bell'}),
P('R52','奇跡','ray',6,'R',[ef('cast','heal',{n:0,scale:'pray',k:1,max:12}),ef('cast','pumpAll',{n:1})],{i:'sun'}),
R_('R53','聖域の結界','ray',3,'C',[ef('endturn','heal',{n:2})],{i:'halo',countdown:4}),
T_('R54','審判の罠','ray',3,'C',[ef('enemySummon','tap',{})],{i:'scales'}),
K('V50','魂の収穫者','void',3,'U',[],[ef('allyDeath','damage',{n:1})],{i:'scythe'}),
P('V51','死者の行進','void',5,'U',[ef('cast','tokens',{n:0,tok:'void',scale:'fallen',k:1,max:5})],{i:'bones'}),
K('V52','死肉喰らい','void',3,'C',[],[ef('enemyDeath','pumpSelf',{n:1})],{i:'bat'}),
R_('V53','呪いの祭壇','void',3,'U',[ef('allyDeath','weakenRandom',{n:1})],{i:'tomb'}),
T_('V54','道連れの罠','void',3,'U',[ef('enemyAttack','destroy',{}),ef('enemyAttack','lifecost',{n:3})],{i:'skull'}),
R_('N50','古い軍旗','none',4,'U',[ef('static','aura',{n:1})],{i:'banner',countdown:3}),
T_('N51','対抗呪文の罠','none',3,'U',[ef('enemySpell','counter',{})],{i:'mirror'}),
P('N52','集結の号笛','none',3,'C',[ef('cast','tokens',{n:1,tok:'none'}),ef('cast','buffAll',{n:1,req:{allies:4}})],{i:'bell'}),
// ---- v2.4 追加：リーダー能力を書き換えるカード ----
K('F40','炎帝の後継者','flare',6,'R',[],[ef('etb','setLeader',{leader:'inferno'})],{i:'crown'}),
P('T40','潮の王冠','tide',4,'R',[ef('cast','setLeader',{leader:'deeptide'}),ef('cast','draw',{n:1})],{i:'trident'}),
K('G40','世界樹の心','grow',6,'R',[],[ef('etb','setLeader',{leader:'bloom'})],{i:'oldtree'}),
P('R40','聖女の祝福','ray',4,'R',[ef('cast','setLeader',{leader:'sanctus'}),ef('cast','heal',{n:3})],{i:'halo'}),
K('V40','冥界の門番','void',6,'R',[],[ef('etb','setLeader',{leader:'hex'})],{i:'gate'}),
K('N40','英雄の継承者','none',7,'L',[],[ef('etb','setLeader',{leader:'command'})],{i:'banner'}),
// ---- v2.2 追加：闇の猛毒と弱体化 ----
K('V33','毒牙の蛇','void',2,'C',['deathtouch'],[],{i:'serpent',st:[1,1]}),
K('V34','毒刃の刺客','void',3,'C',['deathtouch'],[ef('etb','weaken',{n:1})],{i:'dagger'}),
K('V35','猛毒の番犬','void',4,'U',['deathtouch'],[ef('allyDeath','pumpSelf',{n:1})],{i:'fangs'}),
P('V36','衰弱','void',1,'C',[ef('cast','weaken',{n:1,bonus:{req:{souls:2},n:2}})],{i:'ooze'}),
P('V37','呪いの囁き','void',2,'C',[ef('cast','weaken',{n:2})],{i:'moon'}),
P('V38','死の霧','void',5,'U',[ef('cast','weakenAll',{n:1,bonus:{req:{souls:4},n:1}})],{i:'cloud'}),
P('V39','毒の塗布','void',1,'C',[ef('cast','grant',{kw:'deathtouch'})],{i:'potion'}),
// ---- v2.1 追加：確定除去と水の守護 ----
P('F33','焼却','flare',4,'U',[ef('cast','dmg',{n:6})],{i:'bonfire'}),
P('R33','天罰','ray',4,'U',[ef('cast','destroy',{minPower:5})],{i:'cloudbolt'}),
P('T33','深淵への誘い','tide',5,'U',[ef('cast','shuffleBack',{}),ef('cast','draw',{n:1})],{i:'undertow',sb:'cost'}),
P('N25','縛鎖','none',5,'U',[ef('cast','destroy',{})],{i:'chains'}),
K('T34','泡の壁','tide',2,'C',['blocker'],[],{i:'bubbles',st:[1,3]}),
K('T35','珊瑚の守り手','tide',3,'C',['blocker'],[ef('etb','boostHand',{n:1})],{i:'shield',st:[1,4]}),
K('T36','氷壁の番人','tide',4,'U',['blocker'],[ef('etb','freeze',{})],{i:'snowflake',st:[1,5]}),
];
// ---- スタッツ自動算出（明示 st があれば優先）----
// v2.3: 一般的なDCGに寄せた配分。合計＝コスト×2＋1（R+1/L+2）、効果税は1つ1.5（条件付き・破壊時は0.5）、攻撃比率は0.5前後
(function(){
  const KWC={haste:1,unblockable:2,breakthrough:1,blocker:1,armor:2,drain:1,double:3,deathtouch:2};
  const RATIO={flare:0.52,tide:0.52,grow:0.5,ray:0.5,void:0.52};
  CARDS.forEach(d=>{
    if(d.type!=='creature') return;
    if(d.st){ d.power=d.st[0]; d.hp=d.st[1]; return; }
    let total=2*d.cost+1+({R:1,L:2}[d.rarity]||0)+(d.dev||0);
    d.kw.forEach(k=>total-=KWC[k]||0);
    d.effects.forEach(x=>{ if(x.e==='lifecost'||x.e==='selfDestroy'){ total+=2; return; } if(x.req||x.t==='death') total-=0.5; else total-=1.5; });
    if(d.attr[0]==='tide' && d.sb) total+=1;
    if(d.attr[0]==='flare') total-=1;
    if(!d.effects.length && !d.kw.length) total+=1;
    if(d.costFn) total=2*d.cost+1;
    total=Math.max(2,Math.round(total));
    let r=d.attr.length?RATIO[d.attr[0]]:0.5; if(d.kw.includes('blocker')) r=0.3;
    let a=Math.max(1,Math.min(total-1,Math.round(total*r-0.01))); let h=total-a;
    if(d.attr[0]==='grow' && d.cost>=5 && !d.effects.length) h+=1;
    if(d.attr[0]==='ray' && !d.kw.includes('blocker')) h+=1;
    d.power=a; d.hp=h;
  });
  // v3.18: 属性の勝率調整（CPU同士6000試合で 闇58%・森46% → 闇49%・森52%）。明示 st のカードにも適用
  CARDS.forEach(d=>{ if(d.type!=='creature') return; const a=d.attr[0];
    if(a==='void' && d.cost>=3 && d.hp>1) d.hp-=1;
    if(a==='grow' && d.cost>=3) d.hp+=1;
  });
})();
// ---- 冒険モード限定：地域の主の秘宝（v3.7）。通常のカードプールには含めない ----
const TREASURES = [
  R_('X01','イグナの炎心','none',3,'T',[ef('turnstart','dmgAll',{n:1}),ef('turnstart','damage',{n:1})],{i:'bonfire',treasure:true}),
  P('X02','ネレアの真珠','none',2,'T',[ef('cast','draw',{n:2}),ef('cast','discountHand',{n:1})],{i:'drop',treasure:true}),
  K('X03','ガイオスの種','none',3,'T',[],[ef('turnstart','pumpSelf',{n:2})],{i:'seed',treasure:true,st:[2,3]}),
  R_('X04','セラフの聖杯','none',3,'T',[ef('heal','damage',{n:2})],{i:'chalice',treasure:true}),
  K('X05','ハーデンの王冠','none',6,'T',['drain'],[ef('etb','reviveRandom',{n:2})],{i:'darkcrown',treasure:true,st:[5,5]}),
];
TREASURES.forEach(d=>{ if(d.st){ d.power=d.st[0]; d.hp=d.st[1]; } });
const CARD_BY_ID = {}; CARDS.forEach(c=>CARD_BY_ID[c.id]=c); TREASURES.forEach(c=>CARD_BY_ID[c.id]=c);

// ---- effect text ----
const TRIG = { etb:'登場時：', atk:'攻撃時：', death:'破壊時：', cast:'', turnstart:'自分のターン開始時：', oppturnstart:'相手のターン開始時：', static:'', endturn:'自分のターン終了時：', spell:'自分がスペルを唱えるたび：', ability:'リーダー能力を使うたび：', heal:'自分のライフが回復するたび（回復量にかかわらず1回の回復ごとに）：', allyDeath:'自分の他のクリーチャーが破壊されるたび：', summon:'自分がこのカード以外のクリーチャーを出すたび（トークンを含む）：', play:'自分がこのカード以外のカードをプレイするたび：', draw:'自分がカードを引くたび：', damaged:'このクリーチャーがダメージを受けて生き残るたび：', enemyDeath:'相手のクリーチャーが破壊されるたび：', expire:'カウントダウンが0になって消えるとき：', enemyAttack:'相手のクリーチャーが攻撃したとき：', enemySummon:'相手が手札からクリーチャーを出したとき：', enemySpell:'相手がスペルを唱えたとき：', handturn:'手札にある間、自分のターン開始時：' };
function condText(o){
  if(o.minPower!=null) return '攻撃力'+o.minPower+'以上の';
  if(o.damaged && o.maxCost!=null) return 'ダメージを受けているコスト'+o.maxCost+'以下の';
  if(o.damaged) return 'ダメージを受けている';
  if(o.tapped && o.maxCost!=null) return 'レスト状態でコスト'+o.maxCost+'以下の';
  if(o.tapped) return 'レスト状態の';
  if(o.maxPower!=null) return '攻撃力'+o.maxPower+'以下の';
  if(o.maxCost!=null) return 'コスト'+o.maxCost+'以下の';
  return '';
}
function attrName(a){ return a? AN.ATTRS[a].n : ''; }
function reqText(r){ if(!r) return ''; if(r.combo) return '連撃'+(r.combo>1?r.combo:''); if(r.awaken) return '繁茂'; if(r.pray) return '祈り'+r.pray; if(r.souls) return '供物'+r.souls; if(r.boost) return '詠唱'+r.boost; if(r.allies) return '自分のクリーチャーが'+r.allies+'体以上なら'; return ''; }
const SCALE_N={field:'自分の場のクリーチャー', hands:'お互いの手札の枚数の合計', hand:'自分の手札の枚数', fallen:'このゲームで破壊された自分のクリーチャー', combo:'このターンにプレイした他のカード', boost:'詠唱', pray:'祈り', souls:'供物', spells:'このゲームで唱えたスペル', allies:'自分の他のクリーチャー'};
function effectText(x){
  if(x.req||x.bonus||x.scale){
    const y=Object.assign({},x); delete y.req; delete y.bonus; delete y.scale;
    if(x.scale){ y.n = x.n ? x.n : 'X'; }
    let t=effectTextBase(y);
    if(x.scale){ t=t.replace(/。$/,'')+'（'+(x.n?SCALE_N[x.scale]+'1につき+'+(x.k||1):'X＝'+SCALE_N[x.scale]+(x.k>1?'×'+x.k:''))+(x.max?'、最大'+x.max:'')+'）。'; }
    if(x.bonus){ t=t.replace(/。$/,'')+'（'+reqText(x.bonus.req)+'：+'+x.bonus.n+'）。'; }
    if(x.req) t=reqText(x.req)+'：'+t;
    return t;
  }
  let t=effectTextBase(x);
  if(x.anyIf) t=t.replace(/。$/,'')+'（'+reqText(x.anyIf)+'なら、ダメージを受けていないクリーチャーも選べる）。';
  return t;
}
function effectTextBase(x){
  const n=x.n;
  const per = x.per==='attr' ? '自分の'+attrName(x.attrRef||'')+'クリーチャー1体につき、' : '';
  if(per){
    switch(x.e){
      case 'damage': return per+'相手プレイヤーのライフを'+n+'減らす。';
      case 'draw': return per+'自分はカードを'+n+'枚引く。';
      case 'heal': return per+'自分のライフを'+n+'回復する。';
    }
  }
  if(x.kwf && x.e==='aura') return (x._relic?'自分の':'自分の他の')+KW[x.kwf]+'を持つクリーチャーは+'+n+'/+'+n+'。';
  if(x.attr){
    if(x.e==='aura') return '自分の他の'+attrName(x.attr)+'クリーチャーは+'+n+'/+'+n+'。';
    if(x.e==='buffAll') return '自分の'+attrName(x.attr)+'クリーチャーはすべてターン終了時まで+'+n+'/+'+n+'。';
  }
  switch(x.e){
    case 'draw': return '自分はカードを'+n+'枚引く。';
    case 'destroy': return '相手の'+condText(x)+'クリーチャー1体を破壊する。';
    case 'dmg': return '相手のクリーチャー1体に'+n+'ダメージ。';
    case 'dmgAll': return '相手のクリーチャーすべてに'+n+'ダメージ。';
    case 'destroyAll': return '相手の'+condText(x)+'クリーチャーをすべて破壊する。';
    case 'bounce': return '相手の'+condText(x)+'クリーチャー1体を手札に戻す。';
    case 'bounceAll': return '相手のクリーチャーをすべて手札に戻す。';
    case 'freeze': return '相手のクリーチャー1体を凍結する（気絶し、持ち主の次のターンもスタンドしない）。';
    case 'tap': return '相手のクリーチャー1体をレストして気絶させる（持ち主の次のターン開始まで、攻撃できず、守護として働かず、攻撃されても反撃しない）。';
    case 'tapAll': return '相手のクリーチャーすべてをレストして気絶させる（持ち主の次のターン開始まで、攻撃できず、守護として働かず、攻撃されても反撃しない）。';
    case 'damage': return '相手プレイヤーのライフを'+n+'減らす。';
    case 'heal': return '自分のライフを'+n+'回復する。';
    case 'ramp': return '自分の最大エナジー+'+n+'（上限10）。';
    case 'energyNow': return 'このターンだけ、自分のエナジー+'+n+'。';
    case 'discard': return x.self ? '自分は手札をランダムに'+n+'枚捨てる。' : '相手は手札をランダムに'+n+'枚捨てる。';
    case 'revive': return '自分の墓地からコスト'+x.maxCost+'以下のクリーチャー1体（このカード自身を除く）を場に出す。';
    case 'buff': return '自分のクリーチャー1体'+(x._cr?'（このクリーチャーも選べる）':'')+'に、ターン終了時まで+'+n+'/+'+n+'。';
    case 'buffAll': return '自分のクリーチャーすべて'+(x._cr?'（このクリーチャーを含む）':'')+'に、ターン終了時まで+'+n+'/+'+n+'。';
    case 'pumpSelf': return 'このクリーチャーに+'+n+'/+'+n+'。';
    case 'lifecost': return '自分のライフを'+n+'失う。';
    case 'aura': return (x._relic?'自分のクリーチャーは+':'自分の他のクリーチャーは+')+n+'/+'+n+'。';
    case 'spellTax': return '相手が唱えるスペルのコスト+1。';
    case 'fight': return '自分の場で最も攻撃力の高いクリーチャー'+(n?'が、このときだけ攻撃力+'+n+'して、':'が、')+'相手のクリーチャー1体と戦闘する（お互いにダメージを与え合う）。';
    case 'pumpTarget': return '自分のクリーチャー1体'+(x._cr?'（このクリーチャーも選べる）':'')+'に+'+n+'/+'+n+'（永続）。';
    case 'freezeAll': return '相手のクリーチャーすべてを凍結する（気絶し、持ち主の次のターンもスタンドしない）。';
    case 'selfDestroy': return 'このクリーチャーを破壊する。';
    case 'steal': return '相手のクリーチャー1体のコントロールを得る。';
    case 'swapBoards': return '自分と相手の場のクリーチャーをすべて入れ替える'+(x._cr?'（このクリーチャーも相手の場に移る）':'')+'。';
    case 'swapLife': return '自分と相手のライフを入れ替える。';
    case 'cloneSelf': return '自分の場にこのクリーチャーのコピーを1体出す（強化は引き継がない）。';
    case 'polymorph': return '相手のクリーチャー1体を1/1の「カエル」に変える（元の能力・強化・受けたダメージはすべて失われる）。';
    case 'equalize': return 'お互いのクリーチャーすべて'+(x._cr?'（このクリーチャーを含む）':'')+'を'+n+'/'+n+'にする（強化とダメージは消える）。';
    case 'mill': return '相手の山札の上から'+n+'枚を相手の墓地に送る。';
    case 'handRefresh': return 'お互いに手札をすべて捨て、同じ枚数を引き直す。';
    case 'massRevive': return 'お互いの墓地のクリーチャーをすべて持ち主の場に出す（このカード自身を除く。場の上限まで）。';
    case 'dmgAllBoth': return 'お互いのクリーチャーすべて'+(x._cr?'（このクリーチャーを含む）':'')+'に'+n+'ダメージ。';
    case 'toHand': return 'このカードを手札に戻す。';
    case 'sacrifice': return '自分の他のクリーチャーをすべて破壊し、1体につきこのクリーチャーに+3/+3。';
    case 'coin': return 'コインを投げる。表なら相手のクリーチャーすべてに5ダメージ、裏なら自分のライフ-5。';
    case 'copyEnemy': return '相手のクリーチャー1体を選び、そのコピーを自分の場に出す（強化・ダメージは引き継がない）。';
    case 'resetAll': return 'お互いのクリーチャーすべて'+(x._cr?'（このクリーチャーを含む）':'')+'を持ち主の手札に戻す（トークンは消える）。';
    case 'graveSteal': return '相手の墓地で最もコストの高いクリーチャーを自分の場に出す。';
    case 'silenceAll': return '相手のクリーチャーすべての能力を失わせる（あとから与えられた能力も含む）。';
    case 'ping': return '相手のライフ、または相手のクリーチャー1体に'+n+'ダメージ。';
    case 'weaken': return '相手のクリーチャー1体に-'+n+'/-'+n+'（永続）。';
    case 'weakenAll': return '相手のクリーチャーすべてに-'+n+'/-'+n+'（永続）。';
    case 'stealTop': return '相手の場の攻撃力が高いクリーチャーから'+n+'体のコントロールを得る。';
    case 'wipeGrow': return 'このクリーチャー以外の、お互いのクリーチャーすべてを破壊し、破壊した数だけこのクリーチャーに+1/+1。';
    case 'extraTurn': return 'このターンの後に、もう1ターン自分のターンを行う。';
    case 'copyOppHand': return '相手の手札をすべて見て、そのコピーを自分の手札に加える（手札の上限まで）。';
    case 'reviveRandom': return '自分の墓地のクリーチャーからランダムに'+n+'体を自分の場に出す（このカード自身を除く）。';
    case 'halveLife': return '自分のライフを半分（端数切り上げ）にする。';
    case 'tokensRandom': return '自分の場に「からくり」（1/4守護・3/1速攻・2/2破壊時1〜4ダメージのいずれか）をランダムに'+n+'体出す。';
    case 'dmgOthers': return 'このクリーチャー以外の、お互いのクリーチャーすべてに'+n+'ダメージ。';
    case 'addDream': return '自分の手札に、ランダムな「夢カード」（夢の刃・夢の目覚め・夢の翼・夢の癒し・夢の高揚のいずれか）を1枚加える。';
    case 'becomeLord': { const L=LEADER_EX[x.leader]; return '自分のライフを'+n+'にする。自分のリーダー能力を「'+L.name+'」（'+L.cost+'エナジー：'+L.text+'）に変える（このゲーム中ずっと）。'; }
    case 'boomDmg': return '相手のクリーチャーか相手プレイヤーからランダムに1つを選び、1〜4のランダムなダメージ。';
    case 'wipeOthers': return 'このクリーチャー以外の、お互いのクリーチャーすべてを破壊する。';
    case 'discardSelfAll': return '自分の手札をすべて捨てる。';
    case 'bigRandom': return '相手のクリーチャーか相手プレイヤーからランダムに1つを選び、'+n+'ダメージ。';
    case 'setLeader': { const L=LEADER_EX[x.leader]; return '自分のリーダー能力を「'+L.name+'」（'+L.cost+'エナジー：'+L.text+'）に変える（このゲーム中ずっと）。'; }
    case 'swapLeader': return '自分と相手のリーダー能力を入れ替える（このゲーム中ずっと）。';
    case 'counter': return 'そのスペルを打ち消す（効果は発動しない）。';
    case 'pumpRandomAlly': return '自分のクリーチャーからランダムに1体に+'+n+'/+'+n+'（永続）。';
    case 'weakenRandom': return '相手のクリーチャーからランダムに1体に-'+n+'/-'+n+'（永続）。';
    case 'randomDmgCr': return 'ランダムな相手のクリーチャー1体に'+n+'ダメージ。';
    case 'pumpAll': return '自分のクリーチャーすべて'+(x._cr?'（このクリーチャーを含む）':'')+'に+'+n+'/+'+n+'（永続）。';
    case 'boostHand': return '自分の手札にある詠唱カードすべての詠唱+'+n+'。';
    case 'sac': return '自分の他のクリーチャー1体を破壊する。';
    case 'recallSpell': return '自分の墓地にあるスペルからランダムに1枚、そのコピーを自分の手札に加える。';
    case 'devour': return '自分の供物をすべて消費し、1つにつきこのクリーチャーに+1/+1。';
    case 'reviveAllSelf': return '自分の墓地のクリーチャーをすべて自分の場に出す（場の上限まで。相手の墓地には影響しない）。';
    case 'swapHands': return 'お互いの手札をすべて交換する。';
    case 'shiftSelf': return 'このカードは同じコストのランダムなカードに変わる。';
    case 'giveSelf': return 'このクリーチャーのコントロールが相手に移る。';
    case 'setLifeBoth': return 'お互いのライフを'+n+'にする。';
    case 'castRandom': return '全カードの中からランダムなスペルを'+n+'つ、自分が唱えたものとして使う（対象もランダム）。';
    case 'swapEnergy': return 'お互いの最大エナジーを入れ替える。';
    case 'reroll': return 'このクリーチャーの攻撃力と体力を1〜10でランダムに決め直す。';
    case 'coins': return 'コインを'+n+'回投げ、表の数だけカードを引き、裏の数だけライフを失う。';
    case 'deckTopBoth': return 'お互いの山札の一番上のカードを公開し、クリーチャーなら持ち主の場に出す。';
    case 'giftCopy': return '相手の場にこのクリーチャーのコピーを出す。';
    case 'timeSkip': return 'このターンを終える。次の自分のターン、エナジー+'+n+'。';
    case 'anomalyHand': return '自分の手札をすべて、新しく生まれるアノマリーに変える。';
    case 'giftAnomaly': return '相手の手札に新しく生まれるアノマリーを1枚加える。';
    case 'swapGraveDeck': return '自分の山札と墓地を入れ替えて切り直す。';
    case 'doubleEnemy': return '相手の場のクリーチャーすべてのコピーを、相手の場にもう1体ずつ出す。';
    case 'shuffleOwners': return 'お互いの場のクリーチャーすべて'+(x._cr?'（このクリーチャーを含む）':'')+'について、どちらの場にいるかをランダムに決め直す。';
    case 'shrinkAll': return 'お互いのクリーチャーすべて'+(x._cr?'（このクリーチャーを含む）':'')+'を1/1にする。';
    case 'healOpp': return '相手のライフを'+n+'回復する。';
    case 'drawOpp': return '相手はカードを'+n+'枚引く。';
    case 'grant': return '自分のクリーチャー1体'+(x._cr?'（このクリーチャーも選べる）':'')+'に'+KW[x.kw]+'を与える（永続）。';
    case 'grantAll': return '自分のクリーチャーすべて'+(x._cr?'（このクリーチャーを含む）':'')+'に'+KW[x.kw]+'を与える（永続）。';
    case 'addCard': { const sp=SPECIAL[x.card]; return (x.to==='opp'?'相手の':'自分の')+'手札に「'+sp.name+'」（'+spText(sp)+'）を'+(n||1)+'枚加える。'; }
    case 'deckAdd': { const sp=SPECIAL[x.card]; return '相手の山札に「'+sp.name+'」（'+spText(sp)+'）を'+(n||1)+'枚混ぜる。'; }
    case 'transformHand': return x.all ? '自分の手札のカードすべて（アノマリーを除く）を、それぞれ同じコストのランダムなカードに変える。' : '自分の手札からランダムに'+(n||1)+'枚（アノマリーを除く）を、それぞれ同じコストのランダムなカードに変える。';
    case 'evolve': return (x.all ? '自分のクリーチャーすべて'+(x._cr?'（このクリーチャーを含む）':'') : '自分のクリーチャー1体'+(x._cr?'（このクリーチャーも選べる）':''))+'を、元のコスト+'+n+'のランダムなクリーチャーに変える（強化・ダメージ・与えられた能力は引き継がない）。';
    case 'copyHand': return '相手の手札からランダムに1枚選び、そのコピーを自分の手札に加える（相手の手札は減らない）。';
    case 'graveCopy': return '相手の墓地からランダムに1枚選び、そのコピーを自分の手札に加える。';
    case 'stealHand': return '相手の手札からランダムに'+(n||1)+'枚奪う。';
    case 'shuffleHand': return '相手の手札をすべて山札に戻して切り直し、同じ枚数を引かせる。';
    case 'doubleSelf': return 'このクリーチャーの攻撃力と体力を2倍にする。';
    case 'swapStatsAll': return 'すべてのクリーチャーの攻撃力と体力を入れ替える。';
    case 'discountHand': return '自分の手札にあるカードすべてのコストを'+n+'下げる（0未満にはならない。あとから手札に来たカードは対象外）。';
    case 'tokens': { const t=TOKENS[x.tok||'none']; return (x.opp?'相手の場に':'自分の場に')+'「'+t.name+'」（'+t.power+'/'+t.hp+(t.kw.length?'・'+t.kw.map(k=>KW[k]).join('・'):'')+(t.effects.length?'・'+t.effects.map(e=>(TRIG[e.t]||'')+effectTextBase(Object.assign({},e,{n:e.n}))).join('').replace(/。$/,''):'')+'）を'+n+'体出す。'; }
    case 'discover': return '自分のメイン属性か無属性のカードからランダムに3枚を見て、1枚を選んで自分の手札に加える。';
    case 'scry': return '自分の山札の上から'+n+'枚を見て、1枚を自分の手札に加え'+(x.discount?(x.discount>=20?'（そのカードのコストを0にする）':'（そのカードのコスト-'+x.discount+'）'):'')+'、残りを自分の山札の下に置く。';
    case 'randomDmg': return '相手のクリーチャーか相手プレイヤーからランダムに選んで1ダメージ、を'+n+'回行う。';
    case 'randomCard': return '自分のメイン属性か無属性のカードからランダムに1枚を自分の手札に加える。';
    case 'tutor': return '自分の山札からランダムにクリーチャー1枚を自分の手札に加える。';
    case 'shuffleBack': return '相手のクリーチャー1体を相手の山札のランダムな位置に戻す（トークンは消える）。';
    case 'morph': return '相手のクリーチャー1体を、同じコストのランダムなクリーチャーに変える（元の能力・強化・ダメージは引き継がない）。';
    case 'token': return '自分の場に1/1の「骸」トークンを1体出す。';
  }
  return '';
}
function spText(sp){ if(sp.onDraw) return '引くとライフ-'+sp.onDraw.n+'、代わりに1枚引く'; const t=sp.effects.map(effectText).join(''); return 'コスト'+sp.cost+'・'+t; }
function cardText(d){
  const lines=[];
  if(d.onDraw) lines.push('山札から引いたとき：自分のライフを'+d.onDraw.n+'失う。このカードは消え、代わりにカードを1枚引く。');
  if(d.type==='relic') lines.push('置物：場に置く（各自3つまで）。置物自身は攻撃せず、攻撃の対象にもならない（あなたやクリーチャーは通常どおり攻撃される）。'+(d.countdown?'カウントダウン'+d.countdown+'（自分のターン開始時に1減り、0で消える）。':''));
  if(d.type==='trap') lines.push('罠：伏せて置く（各自2つまで）。相手には中身が見えない。条件を満たすと一度だけ発動して墓地へ。');
  if(d.sb==='cost') lines.push('詠唱：手札にある間、自分がスペルを唱えるたびコスト-1。');
  if(d.sb==='grow'||d.sb==='flag') lines.push('詠唱：手札にある間、自分がスペルを唱えるたび詠唱+1。');
  if(d.costFn==='allies') lines.push('自分の場のクリーチャー1体につきコスト-1。');
  if(d.costFn==='oppHand') lines.push('コストは相手の手札の枚数に等しい。');
  if(d.dyn==='hand') lines.push('攻撃力と体力は自分の手札の枚数に等しい。');
  if(d.kw && d.kw.length) lines.push(d.kw.map(k=>KW[k]).join('、'));
  if(d.type==='equip'){
    const parts=['装備したクリーチャーは+'+d.equip.power+'/+'+d.equip.power];
    if(d.equip.kw.length) parts.push(d.equip.kw.map(k=>KW[k]).join('、')+'を得る');
    lines.push(parts.join('、')+'。');
  }
  // group effects by trigger keeping order
  const seen={}; const order=[];
  d.effects.forEach(x=>{ if(!seen[x.t]){seen[x.t]=[];order.push(x.t);} seen[x.t].push(effectText(Object.assign({_cr:d.type==='creature', _relic:d.type==='relic'},x.per?{attrRef:d.attr[0]}:{},x)).replace(/^相手のクリーチャー1体(に|を)/, d.type==='trap'?'そのクリーチャー$1':'相手のクリーチャー1体$1')); });
  order.forEach(t=>lines.push((d.type==='relic'?TRIG[t].replace('自分の他のクリーチャー','自分のクリーチャー').replace('このカード以外の',''):TRIG[t])+seen[t].join('')));
  return lines;
}

// ---- pool generation ----
// main: attribute key. 87 cards = main attribute ~55 + neutral ~32
function drawPool(rng, n, main){
  const pick=(pred)=>{ const byR={C:[],U:[],R:[],L:[]}; CARDS.filter(pred).forEach(c=>byR[c.rarity].push(c)); const r=rng()*100; let k= r<60?'C': r<88?'U': r<98?'R':'L'; if(!byR[k].length) k='C'; return rng.pick(byR[k]); };
  const out=[];
  const three=rng.shuffle(ATTR_ORDER).slice(0,3);
  for(let i=0;i<n;i++){
    if(!main){ const r=rng(); out.push(r<0.86 ? pick(c=>c.attr.length===1 && c.attr[0]===three[Math.floor((r/0.86)*3)]) : pick(c=>c.attr.length===0)); continue; }
    const isMain = rng()<0.63;
    out.push(isMain ? pick(c=>c.attr.includes(main)) : pick(c=>c.attr.length===0));
  }
  return out;
}

// ---- anomaly generator ----
const ANOM_CREATURE_PARTS = [
  {pts:2, kw:'haste'},{pts:1, kw:'blocker'},{pts:3, kw:'unblockable'},{pts:2, kw:'breakthrough'},{pts:2, kw:'armor'},{pts:2, kw:'drain'},
  {pts:3, ef:ef('etb','draw',{n:2})},{pts:4, ef:ef('etb','destroy',{maxCost:4})},{pts:4, ef:ef('etb','dmgAllBoth',{n:3})},
  {pts:3, ef:ef('etb','damage',{n:4})},{pts:3, ef:ef('etb','ramp',{n:2})},{pts:3, ef:ef('etb','discard',{n:2})},
  {pts:4, ef:ef('etb','revive',{maxCost:4})},{pts:2, ef:ef('etb','freeze',{})},{pts:2, ef:ef('etb','bounce',{})},
  {pts:3, ef:ef('atk','draw',{n:1})},{pts:3, ef:ef('atk','damage',{n:2})},{pts:2, ef:ef('atk','pumpSelf',{n:1})},{pts:4, ef:ef('atk','dmg',{n:3})},
  {pts:2, ef:ef('death','draw',{n:2})},{pts:3, ef:ef('death','revive',{maxCost:3})},{pts:2, ef:ef('death','damage',{n:3})},
  {pts:3, ef:ef('static','aura',{n:1})},{pts:5, ef:ef('static','aura',{n:2})},{pts:3, ef:ef('static','spellTax',{})},
  {pts:3, ef:ef('turnstart','heal',{n:2})},{pts:5, ef:ef('turnstart','draw',{n:1})},{pts:4, ef:ef('turnstart','ramp',{n:1})},
];
const ANOM_SPELL_PARTS = [
  {pts:5, min:4, ef:ef('cast','dmgAllBoth',{n:5})},{pts:4, ef:ef('cast','destroy',{})},{pts:4, ef:ef('cast','draw',{n:3})},
  {pts:3, ef:ef('cast','heal',{n:6})},{pts:4, ef:ef('cast','ramp',{n:3})},{pts:4, ef:ef('cast','damage',{n:6})},
  {pts:4, ef:ef('cast','discard',{n:3})},{pts:5, ef:ef('cast','revive',{maxCost:8})},{pts:3, ef:ef('cast','buffAll',{n:3})},
  {pts:4, ef:ef('cast','tapAll',{})},{pts:5, ef:ef('cast','bounceAll',{})},
];
const ANOM_WILD_CREATURE = [
  {pts:6, min:5, ef:ef('etb','steal',{})},{pts:5, min:5, ef:ef('etb','swapBoards',{})},{pts:4, min:4, ef:ef('etb','swapLife',{})},
  {pts:4, min:3, ef:ef('etb','cloneSelf',{})},{pts:4, min:3, ef:ef('etb','polymorph',{})},{pts:4, min:4, ef:ef('etb','equalize',{n:3})},
  {pts:3, ef:ef('etb','mill',{n:6})},{pts:3, ef:ef('etb','handRefresh',{})},
  {pts:3, ef:ef('death','dmgAllBoth',{n:3})},{pts:5, ef:ef('oppturnstart','damage',{n:2})},{pts:4, ef:ef('death','toHand',{})},
  {pts:4, kw:'double'},{pts:4, ef:ef('turnstart','pumpSelf',{n:2})},{pts:3, ef:ef('atk','dmgAll',{n:1})},
  {pts:3, ef:ef('etb','sacrifice',{})},{pts:4, ef:ef('etb','copyEnemy',{})},
  {pts:4, min:3, ef:ef('etb','graveSteal',{})},{pts:4, min:4, ef:ef('etb','silenceAll',{})},
  {pts:3, ef:ef('etb','setLeader',{leader:'chaos'})},{pts:4, ef:ef('etb','setLeader',{leader:'meteor'})},{pts:3, ef:ef('etb','setLeader',{leader:'oracle'})},{pts:3, ef:ef('etb','setLeader',{leader:'summon'})},
  {pts:4, ef:ef('etb','grantAll',{kw:'haste'})},{pts:4, ef:ef('etb','grantAll',{kw:'blocker'})},{pts:5, min:4, ef:ef('etb','grantAll',{kw:'unblockable'})},
  {pts:3, ef:ef('etb','stealHand',{n:2})},{pts:3, ef:ef('etb','shuffleHand',{})},{pts:3, ef:ef('etb','transformHand',{all:true})},
  {pts:4, ef:ef('etb','doubleSelf',{})},{pts:4, ef:ef('etb','swapStatsAll',{})},{pts:4, ef:ef('etb','deckAdd',{card:'bomb',n:4})},
  {pts:4, ef:ef('etb','discountHand',{n:1})},{pts:4, ef:ef('atk','addCard',{card:'ember',n:1})},{pts:4, ef:ef('turnstart','addCard',{card:'drop',n:1})},
  {pts:5, min:4, ef:ef('etb','evolve',{n:1,all:true})},{pts:4, min:4, ef:ef('atk','cloneSelf',{})},
  {pts:3, ef:ef('atk','mill',{n:3})},
];
const ANOM_WILD_SPELL = [
  {pts:3, ef:ef('cast','setLeader',{leader:'chaos'})},{pts:4, ef:ef('cast','setLeader',{leader:'meteor'})},{pts:3, ef:ef('cast','setLeader',{leader:'oracle'})},
  {pts:6, min:5, ef:ef('cast','steal',{})},{pts:5, min:5, ef:ef('cast','swapBoards',{})},{pts:5, min:5, ef:ef('cast','swapLife',{})},
  {pts:4, min:3, ef:ef('cast','polymorph',{})},{pts:5, min:4, ef:ef('cast','equalize',{n:2})},{pts:4, min:3, ef:ef('cast','mill',{n:8})},
  {pts:3, ef:ef('cast','handRefresh',{})},{pts:6, min:5, ef:ef('cast','massRevive',{})},{pts:5, min:5, ef:ef('cast','dmgAllBoth',{n:4})},
  {pts:4, ef:ef('cast','copyEnemy',{})},{pts:5, ef:ef('cast','resetAll',{})},
  {pts:4, ef:ef('cast','graveSteal',{})},{pts:4, ef:ef('cast','silenceAll',{})},
];
const SYL = {
  flare:['ヴォル','イグ','ザル','ガ','ルグ','バーン','ネス','ラーヴァ'],
  tide:['ネル','ウン','ディ','ミラ','シー','ロス','テュ','アクア'],
  grow:['ガイ','エル','ドラ','ヴェル','ムン','ティア','ロン','シルヴ'],
  ray:['セラ','ルミ','アル','ティエ','オル','フィ','ハル','リオン'],
  void:['ザク','ノク','グラ','ヴァ','モル','ネク','ドゥ','シャ'],
};
const TITLES = {creature:['','','＝','・'], spell:['','']};
function anomalyName(rng, attrs, type){
  const syl = [].concat(...attrs.map(a=>SYL[a]));
  const a = rng.pick(syl), b = rng.pick(syl);
  let name = rng()<0.5 ? a+b : a+(rng()<0.5?'＝':'・')+b+rng.pick(['ス','ン','ル','ア','ム','ト']);
  if(type==='spell') name = name.replace(/[＝・]/,'')+rng.pick(['の呪','の裁き','の嵐','の門','の刻','の眼']);
  return name;
}
// ---- 伝説枠のアノマリー（v2.7）：DCGによくある名物レジェンドのような「型」から生成 ----
const LEGEND_TYPES = [
  { key:'jester', title:'狂乱の道化', icon:'mask', make:(rng,d)=>{ d.type='creature'; d.cost=8; d.power=5; d.hp=5; d.effects=[ef('etb','castRandom',{n:0,scale:'hands',k:1,max:10})]; } },
  { key:'seer',   title:'星詠みの賢者', icon:'star', make:(rng,d)=>{ d.type='creature'; d.cost=7; d.power=3; d.hp=7; d.effects=[ef('turnstart','scry',{n:3,discount:99})]; } },
  { key:'usurp',  title:'簒奪の魔王', icon:'darkcrown', make:(rng,d)=>{ d.type='spell'; d.cost=9; d.effects=[ef('cast','halveLife',{}),ef('cast','stealTop',{n:2}),ef('cast','setLeader',{leader:'fiend'})]; } },
  { key:'gear',   title:'からくり技師', icon:'helm', make:(rng,d)=>{ d.type='creature'; d.cost=6; d.power=4; d.hp=5; d.effects=[ef('etb','tokensRandom',{n:2,pool:['gearA','gearB','gearC']}),ef('endturn','tokensRandom',{n:1,pool:['gearA','gearB','gearC']})]; } },
  { key:'reckless',title:'無謀な英雄', icon:'runner', make:(rng,d)=>{ d.type='creature'; d.cost=5; d.power=4+rng.int(2); d.hp=2; d.kw=['haste','double']; d.effects=[ef('etb','drawOpp',{n:2})]; } },
  { key:'titan',  title:'終末の巨神', icon:'giant', make:(rng,d)=>{ d.type='creature'; d.cost=10; d.power=8; d.hp=8; d.effects=[ef('etb','wipeGrow',{}),ef('etb','discard',{n:2,self:true})]; } },
  { key:'sun',    title:'灼熱の太陽神', icon:'sun', make:(rng,d)=>{ d.type='creature'; d.cost=8; d.power=5; d.hp=8; d.kw=['noattack']; d.effects=[ef('turnstart','dmgAll',{n:3}),ef('turnstart','damage',{n:3})]; } },
  { key:'soul',   title:'英霊の王', icon:'phoenix', make:(rng,d)=>{ const sc=rng.pick(['fallen','spells','pray']); d.type='creature'; d.cost=6+rng.int(2); d.power=3; d.hp=3; d.kw=['breakthrough']; d.effects=[ef('etb','pumpSelf',{n:0,scale:sc,k:1,max:15})]; } },
  { key:'time',   title:'時の支配者', icon:'hourglass', make:(rng,d)=>{ d.type='creature'; d.cost=9; d.power=5; d.hp=5; d.effects=[ef('etb','extraTurn',{})]; } },
  { key:'queen',  title:'鏡の女王', icon:'mirror', make:(rng,d)=>{ d.type='creature'; d.cost=6; d.power=3; d.hp=6; d.effects=[ef('etb','copyOppHand',{})]; } },
  { key:'undead', title:'冥府の王', icon:'skull', make:(rng,d)=>{ d.type='creature'; d.cost=8; d.power=6; d.hp=6; d.effects=[ef('etb','reviveRandom',{n:3})]; } },
];
function makeLegend(rng, idx){
  const T=rng.pick(LEGEND_TYPES);
  const attrs=[rng.pick(ATTR_ORDER)];
  const nm=anomalyName(rng,attrs,'creature').replace(/[＝・]/g,'');
  const d={ id:'anom'+idx+'_'+Math.floor(rng()*1e9), name:T.title+nm, attr:attrs, type:'creature', cost:0, rarity:'A', anomaly:true, legend:true, legendType:T.key, kw:[], effects:[], power:0, hp:0, icon:T.icon };
  T.make(rng,d);
  return d;
}
function makeAnomaly(rng, idx, main){
  if(idx%3===2) return makeWeird(rng, idx);
  if(idx%3===0 && rng()<0.5) return makeLegend(rng, idx);
  const attrs = main ? (rng()<0.8 ? [main] : [main, rng.pick(ATTR_ORDER.filter(a=>a!==main))]) : (rng()<0.8 ? [rng.pick(ATTR_ORDER)] : (()=>{ const s=rng.shuffle(ATTR_ORDER); return [s[0],s[1]]; })());
  const type = rng()<0.7 ? 'creature' : 'spell';
  const wild = type==='creature' ? ANOM_WILD_CREATURE : ANOM_WILD_SPELL;
  const normal = type==='creature' ? ANOM_CREATURE_PARTS : ANOM_SPELL_PARTS;
  // always 1 wild part (sometimes 2), plus 0-1 normal part
  const chosen=[]; let pts=0; const used={};
  const add=(p)=>{ const key=p.kw?('kw'+p.kw):(p.ef.t+p.ef.e); if(used[key]) return false; used[key]=1; chosen.push(p); pts+=p.pts; return true; };
  add(rng.pick(wild));
  if(rng()<0.3) add(rng.pick(wild));
  if(type==='creature' ? rng()<0.7 : rng()<0.4) add(rng.pick(normal));
  const minC = chosen.reduce((m,p)=>Math.max(m,p.min||0),0);
  const cost = Math.max(2, minC, Math.min(8, Math.ceil(pts/2)));
  const d = { id:'anom'+idx+'_'+Math.floor(rng()*1e9), name:anomalyName(rng,attrs,type), attr:attrs, type, cost, rarity:'A', anomaly:true, kw:[], effects:[], power:0, hp:0, pts, icon:'anom'+(1+rng.int(6)) };
  chosen.forEach(p=>{ if(p.kw) d.kw.push(p.kw); else d.effects.push(p.ef); });
  if(type==='creature'){
    // same stat rule as normal cards: effects and keywords cost stats. wild effects cost 3, normal 2, keywords per table
    const KWP={haste:1,unblockable:2,breakthrough:1,blocker:-1,armor:2,drain:1,double:3};
    let total=2*cost+1+(rng()<0.35?1:0);
    chosen.forEach(p=>{ if(p.kw) total-=KWP[p.kw]||0; else total-= (wild.includes(p)?3:2); });
    total=Math.max(2,total);
    let r={flare:0.56,tide:0.52,grow:0.5,ray:0.45,void:0.52}[attrs[0]]; if(d.kw.includes('blocker')) r=0.4; d.power=Math.max(1,Math.round(total*r)); d.hp=Math.max(1,total-d.power); if(attrs[0]==='grow') d.hp++; if(attrs[0]==='tide') d.power++;
  }
  return d;
}
const SKULL = { id:'tok_skull', name:'骸', attr:['void'], type:'creature', cost:1, power:1, hp:1, rarity:'C', kw:[], effects:[], token:true };
const LEADER = {
  flare:{ name:'火花', cost:2, text:'相手のライフを1減らす。', ef:ef('leader','damage',{n:1}) },
  tide: { name:'潮読み', cost:2, text:'自分のライフを1失い、カードを1枚引く。', ef:[ef('leader','lifecost',{n:1}),ef('leader','draw',{n:1})] },
  grow: { name:'成長', cost:2, text:'自分のクリーチャー1体に+1/+1（永続）。', ef:ef('leader','pumpTarget',{n:1}) },
  ray:  { name:'聖光', cost:2, text:'自分のライフを2回復する。祈り5以上なら、さらに自分はカードを1枚引く。', ef:[ef('leader','heal',{n:2}),ef('leader','draw',{n:1,req:{pray:5}})] },
  void: { name:'屍術', cost:2, text:'自分の場に1/1の「骸」トークンを1体出す。', ef:ef('leader','token',{}) },
};
const TOKENS = {
  dream: { id:'tok_dream', name:'夢の竜', attr:['grow'], type:'creature', cost:5, power:5, hp:5, rarity:'C', kw:[], effects:[], token:true, i:'dragon' },
  bot:   { id:'tok_bot', name:'爆弾ロボ', attr:[], type:'creature', cost:1, power:1, hp:1, rarity:'C', kw:[], effects:[{t:'death',e:'boomDmg'}], token:true, i:'barrel' },
  fiend: { id:'tok_fiend', name:'業魔', attr:['void'], type:'creature', cost:2, power:3, hp:3, rarity:'C', kw:['haste'], effects:[], token:true, i:'imp' },
  gearA: { id:'tok_gearA', name:'からくり盾兵', attr:[], type:'creature', cost:2, power:1, hp:4, rarity:'C', kw:['blocker'], effects:[], token:true, i:'shield' },
  gearB: { id:'tok_gearB', name:'からくり槍兵', attr:[], type:'creature', cost:2, power:3, hp:1, rarity:'C', kw:['haste'], effects:[], token:true, i:'spear' },
  gearC: { id:'tok_gearC', name:'からくり爆弾', attr:[], type:'creature', cost:2, power:2, hp:2, rarity:'C', kw:[], effects:[{t:'death',e:'boomDmg'}], token:true, i:'barrel' },
  whelp: { id:'tok_whelp', name:'子竜', attr:[], type:'creature', cost:1, power:1, hp:1, rarity:'C', kw:[], effects:[], token:true, i:'dragon' },
  flare:{ id:'tok_flare', name:'火花', attr:['flare'], type:'creature', cost:1, power:1, hp:1, rarity:'C', kw:['haste'], effects:[], token:true },
  tide: { id:'tok_tide', name:'泡', attr:['tide'], type:'creature', cost:1, power:1, hp:1, rarity:'C', kw:[], effects:[], token:true },
  grow: { id:'tok_grow', name:'苗木', attr:['grow'], type:'creature', cost:1, power:1, hp:1, rarity:'C', kw:[], effects:[ef('turnstart','pumpSelf',{n:1})], token:true },
  ray:  { id:'tok_ray', name:'光の羽', attr:['ray'], type:'creature', cost:1, power:1, hp:1, rarity:'C', kw:['blocker'], effects:[], token:true },
  void: { id:'tok_skull', name:'骸', attr:['void'], type:'creature', cost:1, power:1, hp:1, rarity:'C', kw:[], effects:[], token:true },
  none: { id:'tok_none', name:'兵士', attr:[], type:'creature', cost:1, power:1, hp:1, rarity:'C', kw:[], effects:[], token:true },
};

// ---- 特殊カード（プールにはない。効果で手札や山札に加わる）----
const SPECIAL = {
  shard: { id:'sp_shard', name:'星のかけら', attr:[], type:'spell', cost:0, power:0, hp:0, rarity:'C', kw:[], effects:[{t:'cast',e:'energyNow',n:1}], special:true, i:'star', flavor:'後攻の最初に配られる' },
  dream_blade: { id:'sp_dream_blade', name:'夢の刃', attr:[], type:'spell', cost:1, power:0, hp:0, rarity:'C', kw:[], effects:[{t:'cast',e:'dmg',n:5}], special:true, i:'sword' },
  dream_wake:  { id:'sp_dream_wake', name:'夢の目覚め', attr:[], type:'spell', cost:0, power:0, hp:0, rarity:'C', kw:[], effects:[{t:'cast',e:'draw',n:2}], special:true, i:'eye' },
  dream_wing:  { id:'sp_dream_wing', name:'夢の翼', attr:[], type:'spell', cost:3, power:0, hp:0, rarity:'C', kw:[], effects:[{t:'cast',e:'tokens',n:1,tok:'dream'}], special:true, i:'wings' },
  dream_heal:  { id:'sp_dream_heal', name:'夢の癒し', attr:[], type:'spell', cost:1, power:0, hp:0, rarity:'C', kw:[], effects:[{t:'cast',e:'heal',n:6}], special:true, i:'heart' },
  dream_rise:  { id:'sp_dream_rise', name:'夢の高揚', attr:[], type:'spell', cost:3, power:0, hp:0, rarity:'C', kw:[], effects:[{t:'cast',e:'pumpAll',n:2}], special:true, i:'arrowup' },
  ember: { id:'sp_ember', name:'火種', attr:['flare'], type:'spell', cost:1, power:0, hp:0, rarity:'C', kw:[], effects:[ef('cast','dmg',{n:2})], special:true },
  drop:  { id:'sp_drop', name:'水滴', attr:['tide'], type:'spell', cost:0, power:0, hp:0, rarity:'C', kw:[], effects:[ef('cast','draw',{n:1})], special:true },
  seed:  { id:'sp_seed', name:'種', attr:['grow'], type:'spell', cost:1, power:0, hp:0, rarity:'C', kw:[], effects:[ef('cast','tokens',{n:1,tok:'grow'})], special:true },
  bless: { id:'sp_bless', name:'祝福', attr:['ray'], type:'spell', cost:1, power:0, hp:0, rarity:'C', kw:[], effects:[ef('cast','heal',{n:3})], special:true },
  curse: { id:'sp_curse', name:'呪い', attr:['void'], type:'spell', cost:1, power:0, hp:0, rarity:'C', kw:[], effects:[ef('cast','lifecost',{n:1})], special:true, flavor:'手札を圧迫する。プレイして捨てるにはライフ1' },
  bomb:  { id:'sp_bomb', name:'爆弾', attr:['flare'], type:'spell', cost:0, power:0, hp:0, rarity:'C', kw:[], effects:[], special:true, onDraw:{e:'damage',n:3}, flavor:'引いた瞬間に爆発する' },
  hex:   { id:'sp_hex', name:'呪いの頁', attr:['void'], type:'spell', cost:0, power:0, hp:0, rarity:'C', kw:[], effects:[], special:true, onDraw:{e:'damage',n:2}, flavor:'引いた瞬間に蝕む' },
  plan:  { id:'sp_plan', name:'作戦', attr:[], type:'spell', cost:1, power:0, hp:0, rarity:'C', kw:[], effects:[ef('cast','draw',{n:1}),ef('cast','buff',{n:1})], special:true },
};
// ---- 奇妙枠のアノマリー（役に立つかは度外視。各プレイヤー3枚中1枚）----
const WEIRD_CR = [
  {ef:ef('handturn','shiftSelf',{})}, {ef:ef('endturn','giveSelf',{})}, {ef:ef('turnstart','reroll',{})}, {ef:ef('etb','reroll',{})},
  {ef:ef('death','giftCopy',{})}, {dyn:'hand'}, {ef:ef('etb','swapHands',{})}, {ef:ef('etb','setLifeBoth',{n:13})},
  {ef:ef('etb','castRandom',{n:3})}, {ef:ef('etb','swapEnergy',{})}, {ef:ef('etb','deckTopBoth',{})},
  {ef:ef('etb','timeSkip',{n:5})}, {ef:ef('etb','anomalyHand',{})}, {ef:ef('etb','giftAnomaly',{})}, {ef:ef('etb','swapGraveDeck',{})},
  {ef:ef('etb','swapLeader',{})},
  {ef:ef('etb','doubleEnemy',{})}, {ef:ef('etb','shuffleOwners',{})}, {ef:ef('etb','shrinkAll',{})}, {costFn:'oppHand'},
  {ef:ef('atk','healOpp',{n:3})}, {ef:ef('atk','drawOpp',{n:1})}, {ef:ef('death','anomalyHand',{})},
];
const WEIRD_SP = [
  {ef:ef('cast','swapHands',{})}, {ef:ef('cast','setLifeBoth',{n:13})}, {ef:ef('cast','castRandom',{n:4})}, {ef:ef('cast','swapEnergy',{})},
  {ef:ef('cast','deckTopBoth',{})}, {ef:ef('cast','timeSkip',{n:6})}, {ef:ef('cast','anomalyHand',{})},
  {ef:ef('cast','giftAnomaly',{})}, {ef:ef('cast','swapGraveDeck',{})}, {ef:ef('cast','doubleEnemy',{})}, {ef:ef('cast','shuffleOwners',{})},
  {ef:ef('cast','shrinkAll',{})}, {ef:ef('cast','swapLeader',{})},
];
function makeWeird(rng, idx){
  const attrs=[rng.pick(ATTR_ORDER)];
  const type = rng()<0.6 ? 'creature' : 'spell';
  const part = rng.pick(type==='creature'?WEIRD_CR:WEIRD_SP);
  const cost = 1+rng.int(7);
  const d = { id:'anom'+idx+'_'+Math.floor(rng()*1e9), name:anomalyName(rng,attrs,type), attr:attrs, type, cost, rarity:'A', anomaly:true, weird:true, kw:[], effects:[], power:0, hp:0, icon:'anom'+(1+rng.int(6)) };
  if(part.ef) d.effects.push(part.ef);
  if(part.dyn) d.dyn=part.dyn; if(part.costFn) d.costFn=part.costFn;
  if(type==='creature'){ const total=2*cost+1; d.power=Math.max(1,Math.round(total*0.55)); d.hp=Math.max(1,total-d.power); }
  return d;
}
// ---- リーダー能力を書き換える効果用（v2.4）----
const LEADER_EX = {
  inferno: { name:'業火', cost:2, text:'相手プレイヤーか相手のクリーチャー1体に2ダメージ。', ef:ef('leader','ping',{n:2}) },
  deeptide:{ name:'深潮読み', cost:2, text:'自分はカードを1枚引く（ライフは失わない）。', ef:ef('leader','draw',{n:1}) },
  bloom:   { name:'大成長', cost:2, text:'自分のクリーチャー1体に+2/+2（永続）。', ef:ef('leader','pumpTarget',{n:2}) },
  sanctus: { name:'大聖光', cost:2, text:'自分のライフを4回復する。', ef:ef('leader','heal',{n:4}) },
  hex:     { name:'呪詛', cost:2, text:'相手のクリーチャー1体に-1/-1（永続）。', ef:ef('leader','weaken',{n:1}) },
  command: { name:'号令', cost:1, text:'自分のクリーチャーすべてに、ターン終了時まで+1/+1。', ef:ef('leader','buffAll',{n:1}) },
  chaos:   { name:'混沌', cost:2, text:'全カードの中からランダムなスペルを1つ、自分が唱えたものとして使う（対象もランダム）。', ef:ef('leader','castRandom',{n:1}) },
  meteor:  { name:'星降らし', cost:3, text:'相手のクリーチャーか相手プレイヤーからランダムに選んで1ダメージ、を3回行う。', ef:ef('leader','randomDmg',{n:3}) },
  oracle:  { name:'託宣', cost:2, text:'自分の山札の上から2枚を見て、1枚を手札に加え、残りを山札の下に置く。', ef:ef('leader','scry',{n:2}) },
  fiend:   { name:'業魔召喚', cost:2, text:'自分の場に「業魔」（3/3・速攻）を1体出す。', ef:ef('leader','tokens',{n:1,tok:'fiend'}) },
  boss_tide:{ name:'潮の導き', cost:2, text:'自分はカードを1枚引き、自分の手札にある詠唱カードすべての詠唱+1。', ef:[ef('leader','draw',{n:1}),ef('leader','boostHand',{n:1})] },
  boss_ray: { name:'裁きの光', cost:2, text:'自分のライフを4回復し、自分の場に「光の羽」（1/1・守護）を1体出す。', ef:[ef('leader','heal',{n:4}),ef('leader','tokens',{n:1,tok:'ray'})] },
  boss_void:{ name:'冥王の呪', cost:3, text:'相手のクリーチャーすべてに-1/-1（永続）。', ef:ef('leader','weakenAll',{n:1}) },
  devour:  { name:'万象喰らい', cost:4, text:'相手のクリーチャー1体を破壊し、自分のライフを3回復する。', ef:[ef('leader','destroy',{}),ef('leader','heal',{n:3})] },
  judge:   { name:'双冠の裁き', cost:4, text:'相手のクリーチャー1体を破壊し、自分の場にそのコピーを出す。', ef:[ef('leader','copyEnemy',{}),ef('leader','destroy',{})] },
  summon:  { name:'召集', cost:2, text:'自分の場に「兵士」（1/1）を1体出す。', ef:ef('leader','tokens',{n:1,tok:'none'}) },
};
const FROG = { id:'tok_frog', name:'カエル', attr:['grow'], type:'creature', cost:1, power:1, hp:1, rarity:'C', kw:[], effects:[], token:true };

// value estimate for AI
function cardValue(d){
  let v = d.cost*1.0 + (d.type==='creature'? (d.power+d.hp)*0.3 : 1.5);
  v += d.kw.length*0.8 + d.effects.length*0.9;
  if(d.type==='equip') v = d.cost*0.8 + d.equip.power*0.5 + d.equip.kw.length*0.8;
  if(d.anomaly) v += 1.5;
  return v;
}

// ---- ボス（v2.12）----
const BOSSES = [
  { key:'b1', name:'炎獄の番人', attr:'flare', tier:1, life:25, leader:null, energy:0, legends:0, anomalies:1, desc:'ライフ25。リーダー能力は通常の「火花」。コモン・アンコモンだけの炎デッキ（入門）。' },
  { key:'b2', name:'渦潮の魔導師', attr:'tide', tier:2, life:38, leader:'boss_tide', energy:0, legends:1, anomalies:2, desc:'ライフ38。リーダー能力「潮の導き」（1ドロー＋詠唱）。レアまでの水デッキ＋伝説のアノマリー1枚。' },
  { key:'b3', name:'大森林の王', attr:'grow', tier:2, life:42, leader:'bloom', energy:0, legends:1, anomalies:2, desc:'ライフ42。リーダー能力「大成長」（+2/+2）。レアまでの森デッキ＋伝説1枚。' },
  { key:'b4', name:'天光の審判者', attr:'ray', tier:3, life:35, leader:'boss_ray', energy:1, legends:1, anomalies:3, desc:'ライフ35。最大エナジー+1で開始。リーダー能力「裁きの光」（4回復＋守護トークン）。レジェンド入りの光デッキ＋伝説1枚。' },
  { key:'b5', name:'冥府の支配者', attr:'void', tier:3, life:45, leader:'boss_void', energy:1, legends:2, anomalies:3, desc:'ライフ45。最大エナジー+1で開始。リーダー能力「冥王の呪」（相手全体-1/-1）。レジェンド入りの闇デッキ＋伝説2枚。' },
  { key:'b6', name:'特異点アノマリア', attr:null, special:'anomaly', tier:3, life:45, leader:null, energy:2, legends:3, anomalies:12, desc:'ライフ45。最大エナジー+2で開始。デッキの大半がアノマリー（伝説3枚）。自分のターン開始時、リーダー能力がランダムに変わり、手札の1枚が新しいアノマリーに変わる。' },
];
Object.assign(AN, { TREASURES, BOSSES, LEGEND_TYPES, makeLegend, LEADER_EX, FROG, SKULL, TOKENS, SPECIAL, makeWeird, reqText, LEADER, ATTR_ALL, makeRng, hashStr, ATTRS, ATTR_ORDER, RARITY, KW, KW_HELP, BASE_POWER, CARDS, CARD_BY_ID, cardText, effectText, drawPool, makeAnomaly, cardValue });
if(typeof module!=='undefined') module.exports = AN;
})();
