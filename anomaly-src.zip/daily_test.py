# v3.22 デイリーチャレンジの通し確認（Firebase は読み込ませず、同一ブラウザ用の通信で確認）
import asyncio, sys
from playwright.async_api import async_playwright
RULE=sys.argv[1] if len(sys.argv)>1 else None
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':780}, device_scale_factor=2)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.route('**/gstatic.com/**', lambda r: r.abort())
        await pg.goto('file:///home/claude/anomaly/index.html'); await pg.evaluate('localStorage.clear()'); await pg.reload(); await pg.wait_for_timeout(400)
        await pg.screenshot(path='d0.png')
        await pg.click('#btnDaily'); await pg.wait_for_timeout(600); await pg.screenshot(path='d1.png')
        print(await pg.evaluate("document.querySelector('.dcard').innerText"))
        await pg.click('#dquick'); await pg.wait_for_timeout(800)
        # マリガンは閉じる
        mg=await pg.query_selector('#mgo')
        if mg: await mg.click(); await pg.wait_for_timeout(600)
        await pg.screenshot(path='d2.png')
        for i in range(600):
            if await pg.evaluate("!window.__g()||__g().winner!=null"): break
            mg=await pg.query_selector('#mgo')
            if mg: await mg.click(); await pg.wait_for_timeout(300); continue
            if await pg.evaluate("!!__g().pending && __g().pendingInfo.p===0"):
                await pg.evaluate("()=>{ const g=__g(); const q=g.pendingInfo; const c=(q.cands||q.options||[])[0]; g.provideChoice(c&&c.v!=null?c.v:c); __rb(); if(g.active===1) window.__act({t:'noop'}); }")
            elif await pg.evaluate("__g().active===0 && !__g().pending && __g().phase!=='mulligan'"):
                await pg.evaluate("()=>{ const g=__g(); AN.AI.step(g,3); __rb(); if(g.active===1) window.__act({t:'noop'}); }")
            await pg.wait_for_timeout(150)
        await pg.evaluate("document.querySelectorAll('.reveal').forEach(e=>e.click())")
        await pg.wait_for_timeout(3000)
        await pg.screenshot(path='d3.png')
        print('screen', await pg.evaluate("document.querySelector('.screen').id"))
        await pg.fill('#dname','テスト'); await pg.click('#dsend'); await pg.wait_for_timeout(1200)
        await pg.screenshot(path='d4.png', full_page=True)
        print(await pg.evaluate("document.querySelector('.scroll').innerText"))
        print(await pg.evaluate("localStorage.getItem('anomaly_daily_v1')"), await pg.evaluate("localStorage.getItem('anom_rooms_v2')"))
        # 練習
        await pg.click('#dprac'); await pg.wait_for_timeout(600); print('prac screen', await pg.evaluate("document.querySelector('.screen').id"))
        await pg.click('#back'); await pg.wait_for_timeout(400); print('back ->', await pg.evaluate("document.querySelector('.screen').id"))
        await pg.click('#back'); await pg.wait_for_timeout(400); await pg.screenshot(path='d5.png')
        print('series save', await pg.evaluate("localStorage.getItem('anomaly_series_v2')"))
        print('errors', errs)
        await b.close()
asyncio.run(main())
