// ================= デイリーチャレンジ（v3.22）=================
// 日付（日本時間）から、全員に同じ90枚・同じ相手・同じ「今日のルール」を配る1本勝負。
// 最初に最後まで戦った1回が今日の記録。以降は練習（記録されない）。
// ランキングは Firebase の rooms/<Z+3文字> に保存（既存ルール「rooms/<4文字>のみ読み書き可」の範囲内。通常の部屋コードは Z で始まらない）
const LSD='anomaly_daily_v1', LSN='anomaly_name_v1', LSP='anomaly_pid_v1';
const DAY_MS=86400000, JST=9*3600000;
function dayNum(t){ return Math.floor(((t||Date.now())+JST)/DAY_MS); }
function dayStr(n){ const d=new Date(n*DAY_MS); return d.getUTCFullYear()+'-'+String(d.getUTCMonth()+1).padStart(2,'0')+'-'+String(d.getUTCDate()).padStart(2,'0'); }
function dayLabel(n){ const d=new Date(n*DAY_MS); return (d.getUTCMonth()+1)+'月'+d.getUTCDate()+'日（'+'日月火水木金土'[d.getUTCDay()]+'）'; }
function dailyCode(n){ const C='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let s=''; let x=n; for(let i=0;i<3;i++){ s=C[x%32]+s; x=Math.floor(x/32); } return 'Z'+s; }
function dLoad(){ try{ return JSON.parse(localStorage.getItem(LSD))||{}; }catch(e){ return {}; } }
function dSave(o){ try{ localStorage.setItem(LSD, JSON.stringify(o)); }catch(e){} }
function myName(){ try{ return localStorage.getItem(LSN)||''; }catch(e){ return ''; } }
function setMyName(n){ try{ localStorage.setItem(LSN,n); }catch(e){} }
function myPid(){ let p=null; try{ p=localStorage.getItem(LSP); }catch(e){} if(!p){ p='p'+Math.floor(Math.random()*36**8).toString(36); try{ localStorage.setItem(LSP,p); }catch(e){} } return p; }
// 今日のルール（日付で決まる）
const DAILY_RULES=[
  {k:'none',  n:'通常ルール',   t:'特別なルールはありません。純粋にデッキ構築の腕試し。'},
  {k:'wind',  n:'追い風',       t:'{A}属性のクリーチャーは、攻撃力+1（あなたも相手も）。'},
  {k:'rush',  n:'早駆け',       t:'両者とも、最大エナジー1の状態から始まる（1ターン目からエナジー2）。'},
  {k:'short', n:'短期決戦',     t:'両者ともライフ15で始まる。'},
  {k:'chaos', n:'混沌',         t:'両者とも、自分のターンの始めにリーダー能力が別のものに変わり、手札の1枚が新しいアノマリーに変わる。'},
];
function dailySetup(n){
  const seed='daily:'+dayStr(n);
  const rng=AN.makeRng('pool:'+seed);
  const pools=[0,1].map(i=>{ const p=AN.drawPool(rng,87,null); const an=[0,1,2].map(k=>AN.makeAnomaly(rng,i*3+k,null)); return an.concat(p); });
  const rr=AN.makeRng('rule:'+seed);
  const rule=DAILY_RULES[rr.int(DAILY_RULES.length)];
  const attrs=AN.ATTR_ORDER.filter(a=>pools[0].some(d=>!d.anomaly&&d.attr.includes(a)));
  const attr=attrs[rr.int(attrs.length)];
  const oppMain=AN.AI.bestMain(pools[1]);
  const oppDeck=AN.AI.autoDeck(pools[1], AN.makeRng('opp:'+seed), oppMain);
  return {n, seed, pools, rule, attr, oppMain, oppDeck};
}
function ruleText(D){ return D.rule.t.replace('{A}','<span style="color:'+AN.ATTRS[D.attr].c+'">'+AN.ATTRS[D.attr].n+'</span>'); }
function dailyGameOpts(dl){
  const r=dl.rule;
  if(r==='wind') return {fieldBuff:{attr:dl.attr,n:1}};
  if(r==='rush') return {energyBonus:[1,1]};
  if(r==='short') return {lifes:[15,15]};
  if(r==='chaos') return {bossRules:[{chaos:true},{chaos:true}]};
  return {};
}
function dailyStreak(){
  const h=dLoad(); let n=dayNum(); if(!h[n]) n--; let k=0; while(h[n] && h[n].rec){ k++; n--; } return k;
}
function dailyStart(quick, practice){
  ui.dailyLast=null;
  const D=dailySetup(dayNum());
  series={ daily:{n:D.n, rule:D.rule.k, attr:D.attr, practice:!!practice}, seed:D.seed, format:1, level:3, wins:[0,0], gameNo:1, pools:D.pools, decks:[[],[]], nextFirst:null, mains:[null, D.oppMain], boss:null };
  series.decks[1]=indicesFor(D.pools[1], D.oppDeck);
  ui.me=0; ui.filter='all';
  if(quick){ const m=AN.AI.bestMain(D.pools[0]); series.mains[0]=m; series.decks[0]=indicesFor(D.pools[0], AN.AI.autoDeck(D.pools[0], AN.makeRng('quick:'+D.seed), m)); startGame(); return; }
  show('draft');
}
// 戦い終わり：最初の1回だけ記録（開始時に「挑戦中」を記録しておくので、途中でやめても1回と数える）
function dailyMarkStart(){
  const dl=series&&series.daily; if(!dl || dl.practice) return;
  const h=dLoad(); if(h[dl.n] && h[dl.n].rec) { dl.practice=true; return; }
  h[dl.n]=Object.assign(h[dl.n]||{}, {started:Date.now()}); dSave(h);
}
function dailyFinish(w){
  const dl=series.daily; const me=game.players[0], op=game.players[1];
  const oppStart=dl.rule==='short'?15:AN.CONST.LIFE;
  const rec={w:w===0?1:0, t:Math.ceil(game.turn/2), l:Math.max(0,me.life), d:Math.max(0,oppStart-Math.max(0,op.life)), m:series.mains[0]||''};
  ui.dailyLast={rec, practice:dl.practice};
  if(!dl.practice){
    const h=dLoad(); if(!(h[dl.n]&&h[dl.n].rec)){ h[dl.n]=Object.assign(h[dl.n]||{}, {rec, sent:false}); dSave(h); dailySubmit(dl.n); }
  }
  series=null; game=null; show('daily');
}
async function dailySubmit(n){
  const h=dLoad(); const e=h[n]; if(!e||!e.rec||e.sent) return;
  const name=myName(); if(!name) return; // 名前が決まってから送る
  try{
    const net=getNet(); const code=dailyCode(n); const pid=myPid();
    const r=await net.getRoom(code);
    if(!r || !r.created) await net.set(code,'created',Date.now());
    if(r && r.scores && r.scores[pid]){ e.sent=true; dSave(h); return; } // 送信済み（別の端末など）
    await net.set(code,'scores/'+pid, Object.assign({n:name, at:Date.now()}, e.rec));
    const h2=dLoad(); if(h2[n]){ h2[n].sent=true; dSave(h2); }
    if(ui.screen==='daily') renderDaily();
  }catch(err){ console.warn('daily submit failed', err); }
}
function rankSort(a,b){
  if(a.w!==b.w) return b.w-a.w;
  if(a.w) return a.t-b.t || b.l-a.l || a.at-b.at;
  return b.d-a.d || b.t-a.t || a.at-b.at;
}
function recText(r){ return r.w ? (r.t+'ターンで勝利・残りライフ'+r.l) : ('敗北・'+r.d+'ダメージ'); }
let dailyBoard={n:null, list:null, err:null, loading:false};
async function loadBoard(n){
  dailyBoard={n, list:dailyBoard.n===n?dailyBoard.list:null, err:null, loading:true};
  try{
    const net=getNet(); const r=await net.getRoom(dailyCode(n));
    const sc=(r&&r.scores)||{};
    dailyBoard.list=Object.keys(sc).map(k=>Object.assign({pid:k},sc[k])).filter(x=>x&&typeof x.n==='string').sort(rankSort);
    dailyBoard.local=net.kind!=='firebase';
  }catch(e){ dailyBoard.err='ランキングを読み込めませんでした'; }
  dailyBoard.loading=false;
  if(ui.screen==='daily') renderDaily(true);
}
function renderDaily(fromLoad){
  const s=screenEl('daily'); const n=dayNum(); const D=dailySetup(n); const h=dLoad(); const e=h[n]||{}; const rec=e.rec;
  const L=ui.dailyLast; // 画面を離れるときに消す
  if(!fromLoad && (dailyBoard.n!==n || !dailyBoard.loading)) loadBoard(n);
  if(rec && !e.sent && myName()) dailySubmit(n);
  const oa=AN.ATTRS[D.oppMain];
  const attrs=AN.ATTR_ORDER.filter(a=>D.pools[0].some(d=>!d.anomaly&&d.attr.includes(a)));
  let html='<div class="topbar"><button class="ghost" id="back">←</button><div class="t">デイリーチャレンジ <span class="sub">'+dayLabel(n)+'</span></div></div><div class="scroll wrap">';
  if(L){ html+='<div class="dres '+(L.rec.w?'win':'lose')+'"><div class="big">'+(L.rec.w?'WIN':'LOSE')+'</div><div>'+recText(L.rec)+'</div>'+(L.practice?'<div class="sub">練習なので記録されません</div>':'<div class="sub">今日の記録になりました</div>')+'</div>'; }
  html+='<div class="dcard"><div class="dh">今日のルール「'+esc(D.rule.n)+'」</div><div class="sub" style="line-height:1.7">'+ruleText(D)+'</div>'
    +'<div class="sub" style="margin-top:8px;line-height:1.7">相手：CPU（強）・<span style="color:'+oa.c+'">'+oa.n+'（'+oa.k+'）</span>デッキ<br>あなたの90枚：'+attrs.map(a=>'<span style="color:'+AN.ATTRS[a].c+'">'+AN.ATTRS[a].n+'</span>').join('・')+'＋無属性＋アノマリー3枚<br>全員が同じ90枚・同じ相手と戦う1本勝負。<b>最初の1回</b>が今日の記録です。</div></div>';
  if(rec){
    html+='<div class="dcard"><div class="dh">あなたの今日の記録</div><div style="font-size:18px;margin:4px 0;color:'+(rec.w?'#7be0b0':'#f28f8f')+'">'+recText(rec)+'</div>'
      +'<div class="sub">連続参加 '+dailyStreak()+'日'+(e.sent?'':(myName()?'・送信中…':''))+'</div>'
      +(myName()?'':'<div class="field-label">ランキングに載せる名前</div><div class="row"><input type="text" id="dname" maxlength="12" placeholder="例: ショウ"><button class="primary" id="dsend" style="flex:0 0 auto;white-space:nowrap">登録</button></div>')
      +'</div><div class="menu"><button id="dprac">同じ条件で練習する（記録されません）</button></div>';
  } else if(e.started){
    html+='<div class="dcard"><div class="sub" style="line-height:1.7">今日の挑戦は途中で終わっています（記録は「未完了」）。練習はできます。</div></div><div class="menu"><button id="dprac">同じ条件で練習する（記録されません）</button></div>';
  } else {
    html+='<div class="menu"><button class="primary" id="dgo">90枚を受け取ってデッキを組む</button><button id="dquick">おまかせデッキで挑戦</button></div>'
      +'<div class="sub" style="margin-top:6px;font-size:12px;line-height:1.6">対戦が始まった時点で今日の1回としてカウントされます（途中でやめると記録なし）。</div>';
  }
  // ランキング
  html+='<div class="dh" style="margin-top:22px">今日のランキング</div>';
  const B=dailyBoard;
  if(B.err) html+='<div class="sub">'+esc(B.err)+'</div>';
  else if(!B.list) html+='<div class="sub">読み込み中…</div>';
  else if(!B.list.length) html+='<div class="sub">まだ誰も記録していません。一番乗りのチャンス！</div>';
  else { const pid=myPid(); html+='<div class="drank">'+B.list.slice(0,50).map((r,i)=>'<div class="dr'+(r.pid===pid?' me':'')+'"><span class="rk">'+(i+1)+'</span><span class="nm">'+esc(r.n)+'</span>'+(r.m&&AN.ATTRS[r.m]?'<span class="at" style="color:'+AN.ATTRS[r.m].c+'">'+AN.ATTRS[r.m].n+'</span>':'')+'<span class="rs '+(r.w?'w':'l')+'">'+(r.w?r.t+'T勝・残'+r.l:'負・'+r.d+'ダメ')+'</span></div>').join('')+'</div>'; }
  if(B.local) html+='<div class="sub" style="font-size:11px;margin-top:6px">（オンライン未設定のため、この端末の記録だけが表示されます）</div>';
  html+='<div class="sub" style="font-size:11px;margin-top:10px;line-height:1.6">順位：勝ち→少ないターン→多い残りライフ。負けは与えたダメージ順。日本時間の0時に新しいチャレンジに切り替わります。</div></div>';
  s.innerHTML=html;
  s.querySelector('#back').onclick=()=>{ ui.dailyLast=null; show('title'); };
  const q=id=>s.querySelector('#'+id);
  if(q('dgo')) q('dgo').onclick=()=>dailyStart(false,false);
  if(q('dquick')) q('dquick').onclick=()=>dailyStart(true,false);
  if(q('dprac')) q('dprac').onclick=()=>dailyStart(false,true);
  if(q('dsend')) q('dsend').onclick=()=>{ const v=q('dname').value.trim().slice(0,12); if(!v){ toast('名前を入れてください'); return; } setMyName(v); dailySubmit(n); renderDaily(); };
}
function dailyDoneToday(){ const e=dLoad()[dayNum()]; return !!(e && (e.rec||e.started)); }
