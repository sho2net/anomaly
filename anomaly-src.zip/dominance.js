const AN=require('./cards.js');
const cards=AN.CARDS.filter(d=>!d.token);
function norm(x){ const t=(x.t==='etb'||x.t==='cast')?'now':x.t; const o=Object.assign({},x); delete o.t; delete o.n; return t+'|'+JSON.stringify(Object.keys(o).sort().reduce((a,k)=>(a[k]=o[k],a),{})); }
function covers(A,B){ // does A's effect set cover B's (each B effect matched by A effect with n>=)
  const used=new Set();
  for(const y of B.effects){ let ok=false; for(let i=0;i<A.effects.length;i++){ if(used.has(i)) continue; const x=A.effects[i]; if(norm(x)===norm(y) && (x.n||0)>=(y.n||0)){ used.add(i); ok=true; break; } } if(!ok) return false; }
  return true;
}
const out=[];
for(const A of cards) for(const B of cards){
  if(A===B) continue;
  if(!['creature','spell'].includes(A.type)||!['creature','spell'].includes(B.type)) continue;
  const sameColor = A.attr.join()===B.attr.join() || A.attr.length===0 || B.attr.length===0;
  if(!sameColor) continue;
  if(A.cost>B.cost) continue;
  if(!B.kw.every(k=>A.kw.includes(k))) continue;
  if(!covers(A,B)) continue;
  if(A.effects.some(x=>x.e==='lifecost'||x.e==='sac'||x.e==='selfDestroy')) continue;
  if(B.effects.length===0 && B.type==='spell') continue;
  let better=false, eq=true;
  if(A.type==='creature' && B.type==='creature'){ if(A.power<B.power||A.hp<B.hp) continue; if(A.power>B.power||A.hp>B.hp) better=true; }
  else if(A.type==='creature' && B.type==='spell'){ better=true; } // same effect plus a body
  else if(A.type==='spell' && B.type==='creature'){ continue; }
  if(A.cost<B.cost) better=true;
  if(A.effects.length>B.effects.length || A.kw.length>B.kw.length) better=true;
  if(A.effects.some((x,i)=>B.effects[i] && (x.n||0)>(B.effects[i].n||0))) better=true;
  if(!better) continue;
  if(B.sb||A.sb||B.costFn||A.costFn) continue;
  out.push([A,B]);
}
const fmt=d=>d.id+' '+d.name+' '+d.cost+'c'+(d.type==='creature'?' '+d.power+'/'+d.hp:' spell')+(d.kw.length?' ['+d.kw.map(k=>AN.KW[k]).join('')+']':'')+' '+AN.cardText(d).filter(l=>!AN.KW[l]).join(' ').slice(0,60);
out.forEach(([A,B])=>console.log(fmt(A)+'\n   ≧ '+fmt(B)));
console.log('pairs', out.length);
