// ===== ANOMALY engine.js =====
var AN = (typeof AN !== 'undefined') ? AN : (typeof require!=='undefined' ? require('./cards.js') : {});
(function(){
const HAND_MAX = 8, FIELD_MAX = 7, LIFE = 25, HAND_START = 4, ENERGY_MAX = 10, DECK_SIZE = 30;

class Game {
  // opts: {seed, decks:[[def],[def]], names:[..], first:0|1, choosers:[fn,fn]}
  constructor(opts){
    this.rng = AN.makeRng(opts.seed);
    this.uid = 0;
    this.names = opts.names || ['P1','P2'];
    this.mains = opts.mains || [null,null];
    this.choosers = opts.choosers || [null,null];
    this.players = [0,1].map(i=>({
      i, name:this.names[i], life:LIFE, hand:[], energy:0, energyMax:0, field:[], grave:[], abilityUsed:false, relics:[], traps:[], main:(opts.mains||[])[i]||null, plays:0, spellsCast:0, pray:0, souls:0, bonusNext:0,
      deck: this.rng.shuffle(opts.decks[i].map(d=>this.inst(d))),
    }));
    this.turn = 0; this.active = opts.first==null ? this.rng.int(2) : opts.first;
    this.first = this.active;
    if(opts.lifes) this.players.forEach((p,i)=>{ if(opts.lifes[i]) p.life=opts.lifes[i]; });
    if(opts.leaders) this.players.forEach((p,i)=>{ if(opts.leaders[i]) p.leaderOverride=AN.LEADER_EX[opts.leaders[i]]; });
    if(opts.energyBonus) this.players.forEach((p,i)=>{ p.energyMax=opts.energyBonus[i]||0; });
    if(opts.bossRules) this.players.forEach((p,i)=>{ p.bossRules=opts.bossRules[i]||null; });
    this.fieldBuff=opts.fieldBuff||null;
    this.sideBuff=opts.sideBuff||null; // v3.13 冒険ハード：片方のプレイヤーのクリーチャーだけ強化 [null,{atk,hp}]
    this.phase = 'main'; this.queue=[]; this.pending=null; this.winner=null; this.log=[]; this.events=[];
    this.attackCtx=null;
    for(const p of this.players) this.draw(p, HAND_START + (p.i===this.first?0:1), true);
    { const sec=this.players[1-this.first]; sec.hand.push(this.inst(AN.SPECIAL.shard)); }
    // v2.9: マリガン。両者が選び終えたら1ターン目開始
    this.phase='mulligan'; this.mullDone=[false,false];
    if(opts.noMulligan){ this.mullDone=[true,true]; this.phase='main'; this.beginTurn(true); }
  }
  // 手札から戻すカードを選んで山札に混ぜ、同じ枚数を引き直す（星のかけらは戻せない）
  mulligan(p, uids){
    if(this.phase!=='mulligan' || this.mullDone[p.i]) return false;
    const back=p.hand.filter(c=>uids.includes(c.uid) && c.d.id!=='sp_shard');
    back.forEach(c=>{ p.hand.splice(p.hand.indexOf(c),1); });
    p.deck=this.rng.shuffle(p.deck.concat(back));
    for(let i=0;i<back.length;i++){ if(p.deck.length) p.hand.push(p.deck.pop()); }
    this.mullDone[p.i]=true;
    this.say(p.name+'はマリガンで'+back.length+'枚を引き直した','draw');
    if(this.mullDone[0]&&this.mullDone[1]){ this.phase='main'; this.beginTurn(true); }
    return true;
  }
  inst(d){ return {uid:++this.uid, d}; }
  opp(p){ return this.players[1-p.i]; }
  say(s, kind){ this.log.push({t:this.turn, s, kind:kind||''}); if(this.log.length>200) this.log.shift(); }
  ev(type, data){ this.events.push(Object.assign({type},data)); }

  // ---- power ----
  // attack
  power(cr){ return this._stat(cr,'power'); }
  // max health
  maxHealth(cr){ return this._stat(cr,'hp'); }
  _stat(cr, key){
    const owner = this.owner(cr);
    if(cr.swapped) key = key==='power' ? 'hp' : 'power';
    let base = cr.c.d[key];
    if(cr.roll) base = key==='power'? cr.roll[0] : cr.roll[1];
    if(cr.c.d.dyn==='hand' && owner) base = owner.hand.length;
    let p = (cr.fixed!=null ? cr.fixed : base + cr.pump) * (cr.mult||1) + cr.tmp;
    if(this.fieldBuff && cr.c.d.attr.includes(this.fieldBuff.attr)) p+=this.fieldBuff.n;
    if(this.sideBuff && owner && this.sideBuff[owner.i]) p+= (key===(cr.swapped?'hp':'power')) ? (this.sideBuff[owner.i].atk||0) : (this.sideBuff[owner.i].hp||0);
    cr.equips.forEach(e=>p+=e.d.equip.power);
    if(owner) owner.field.forEach(o=>{ if(o!==cr) this.effs(o).forEach(x=>{ if(x.t==='static'&&x.e==='aura'&&(!x.attr||cr.c.d.attr.includes(x.attr))&&(!x.kwf||this.hasKw(cr,x.kwf))) p+=x.n; }); });
    if(owner) owner.relics.forEach(r=>r.c.d.effects.forEach(x=>{ if(x.t==='static'&&x.e==='aura'&&(!x.attr||cr.c.d.attr.includes(x.attr))&&(!x.kwf||this.hasKw(cr,x.kwf))) p+=x.n; }));
    return Math.max(0,p);
  }
  health(cr){ return this.maxHealth(cr)-cr.dmg; }
  effs(cr){ return cr.silenced ? [] : cr.c.d.effects; }
  hasKw(cr, k){ if(cr.silenced) return false; return cr.c.d.kw.includes(k) || (cr.grants||[]).includes(k) || cr.equips.some(e=>e.d.equip.kw.includes(k)); }
  mkCr(card, opts){ return Object.assign({c:card, tapped:false, sick:!card.d.kw.includes('haste'), pump:0, tmp:0, dmg:0, equips:[], armorUsed:false, frozen:false, silenced:false, fixed:null, doubled:false, stun:false, grants:[], mult:1, swapped:false}, opts||{}); }
  owner(cr){ return this.players.find(p=>p.field.includes(cr)); }
  findCr(uid){ for(const p of this.players){ const c=p.field.find(x=>x.c.uid===uid); if(c) return c; } return null; }

  // ---- draw / life ----
  draw(p, n, silent){
    for(let i=0;i<n;i++){
      if(p.deck.length===0){ this.loseLife(p,1,'山札切れ'); continue; }
      const c=p.deck.pop();
      if(c.d.onDraw){ this.say(p.name+'は「'+c.d.name+'」を引いた！（代わりにもう1枚引く）','life'); this.loseLife(p,c.d.onDraw.n,'「'+c.d.name+'」'); i--; continue; }
      p.hand.push(c);
      if(this.phase!=='mulligan') this.trigger(p,'draw',null);
    }
    if(!silent) this.say(p.name+'はカードを'+n+'枚引いた', 'draw');
  }
  loseLife(p, n, why){
    if(n<=0) return; p.life -= n; this.ev('life',{p:p.i,n:-n});
    if(p.bossRules && p.bossRules.phase && !p.phase2 && p.life>0 && p.life<=p.bossRules.phase){ p.phase2=true; p.life+=6; p.leaderOverride=AN.LEADER_EX[p.bossRules.phaseLeader||'devour']; p.abilityUsed=false; p.field.forEach(c=>c.pump+=1); this.ev('bossphase',{p:p.i}); this.say(p.name+'は真の姿を現した！（ライフ+6、リーダー能力「'+p.leaderOverride.name+'」、自分のクリーチャーすべてに+1/+1）','win'); }
    this.say(p.name+'のライフ -'+n+(why?'（'+why+'）':''), 'life');
    this.checkWin();
  }
  gainLife(p,n){ if(n<=0)return; p.life=Math.min(99,p.life+n); p.pray++; this.ev('life',{p:p.i,n}); this.say(p.name+'のライフ +'+n+'（祈り'+p.pray+'）', 'heal');
    this.trigger(p,'heal',null); }
  // fire a trigger for creatures on p's field (except 'except' creature card)
  trigger(p, t, exceptCard){ p.field.slice().forEach(c=>{ if(exceptCard && c.c===exceptCard) return; this.effs(c).forEach(x=>{ if(x.t===t) this.queue.push({type:'effect',p:p.i,src:c.c,eff:x}); }); }); p.relics.slice().forEach(r=>{ if(exceptCard && r.c===exceptCard) return; r.c.d.effects.forEach(x=>{ if(x.t===t) this.queue.push({type:'effect',p:p.i,src:r.c,eff:x}); }); }); }
  fireTraps(owner, kind, targetUid){ const fired=owner.traps.filter(c=>c.d.effects.some(x=>x.t===kind)); if(fired.length) this.queue.push({type:'trapPause'}); fired.forEach(c=>{ owner.traps.splice(owner.traps.indexOf(c),1); owner.grave.push(c); c.d.revealed=true; this.say(owner.name+'の罠「'+c.d.name+'」が発動した！','play'); this.ev('trap',{p:owner.i,d:c.d}); c.d.effects.forEach(x=>{ if(x.t===kind) this.queue.push({type:'effect',p:owner.i,src:c,eff:x,choice:targetUid===undefined?undefined:targetUid}); }); }); return fired; }
  reqOk(p, req, t, consume){
    if(!req) return true;
    if(req.combo!=null){ const c = t&&t.snap ? t.snap.combo : p.plays; if(c<req.combo) return false; }
    if(req.awaken && p.energyMax<7) return false;
    if(req.pray!=null && p.pray<req.pray) return false;
    if(req.allies!=null && p.field.length<req.allies) return false;
    if(req.boost!=null && !((t&&t.src&&t.src.boost||0)>=req.boost)) return false;
    if(req.souls!=null){ if(p.souls<req.souls) return false; if(consume){ p.souls-=req.souls; this.say(p.name+'は供物を'+req.souls+'消費した（残り'+p.souls+'）'); } }
    return true;
  }
  scaleCount(p, x, t){
    switch(x.scale){
      case 'combo': return t&&t.snap ? t.snap.combo : p.plays;
      case 'boost': return (t&&t.src&&t.src.boost)||0;
      case 'pray': return p.pray;
      case 'souls': return p.souls;
      case 'spells': return p.spellsCast;
      case 'hand': return p.hand.length;
      case 'hands': return p.hand.length+this.opp(p).hand.length;
      case 'fallen': return p.fallen||0;
      case 'allies': return p.field.filter(c=>!t||c.c!==t.src).length;
      case 'field': return p.field.length;
    }
    return 0;
  }
  checkWin(){
    if(this.winner!=null) return;
    const dead = this.players.filter(p=>p.life<=0);
    if(dead.length===2) this.winner = 1-this.active; // both dead: active loses
    else if(dead.length===1) this.winner = 1-dead[0].i;
    if(this.winner!=null){ this.say(this.players[this.winner].name+'の勝利！','win'); this.queue=[]; this.pending=null; }
  }

  // ---- turn ----
  beginTurn(firstTurn){
    this.turn++; const p=this.players[this.active]; this.phase='main'; p.abilityUsed=false;
    p.field.forEach(c=>{ if(c.frozen){ c.frozen=false; } else { c.tapped=false; c.stun=false; } c.sick=false; c.tmp=0; c.doubled=false; c.attacked=false; });
    p.energyMax=Math.min(ENERGY_MAX,p.energyMax+1); p.energy=p.energyMax; p.plays=0;
    // v3.14 ハードの最終ボス：数ターンごとに、相手の場で最も攻撃力の高いクリーチャーの写し身を自分の場に生み出す（乱数は使わない）
    if(p.bossRules && p.bossRules.mirror && (p.mirrorTick=(p.mirrorTick||0)+1)%p.bossRules.mirror===0){ const o2=this.opp(p);
      if(o2.field.length && p.field.length<FIELD_MAX){ const src=o2.field.slice().sort((x,y)=>(this.power(y)-this.power(x))||(this.health(y)-this.health(x)))[0]; const nc=this.mkCr(this.inst(src.c.d)); p.field.push(nc); this.say(p.name+'は「'+src.c.d.name+'」の写し身を生み出した','play'); this.ev('mirror',{p:p.i,uid:nc.c.uid}); } }
    if(p.bossRules && p.bossRules.devour && (p.devourTick=(p.devourTick||0)+1)%2===0){ const o2=this.opp(p); const cs=o2.grave.filter(c=>!c.d.token&&!c.d.special); if(cs.length && p.hand.length<HAND_MAX){ const c=cs[this.rng.int(cs.length)]; p.hand.push(this.inst(c.d)); this.say(p.name+'は倒れたものの記憶を喰らった','draw'); } }
    if(p.bossRules && p.bossRules.chaos){
      const keys=Object.keys(AN.LEADER_EX).filter(k=>!k.startsWith('boss_')&&k!=='judge');
      const pool=keys.map(k=>AN.LEADER_EX[k]).concat(AN.ATTR_ORDER.map(a=>AN.LEADER[a]));
      p.leaderOverride=pool[this.rng.int(pool.length)]; p.abilityUsed=false;
      this.say(p.name+'のリーダー能力が「'+p.leaderOverride.name+'」に変異した','play');
      const idx=p.hand.map((c,i)=>i).filter(i=>!p.hand[i].d.anomaly);
      if(idx.length){ const i=idx[this.rng.int(idx.length)]; const old=p.hand[i]; p.hand[i]=this.inst(AN.makeAnomaly(this.rng, 20000+this.uid*3+1, null)); this.say(p.name+'の手札の1枚が新たなアノマリーに変異した','draw'); }
    }
    if(p.bonusNext){ p.energy+=p.bonusNext; this.say(p.name+'のエナジー+'+p.bonusNext,'charge'); p.bonusNext=0; }
    this.say('― '+p.name+'のターン'+this.turn+' ―','turn'); this.ev('turn',{p:p.i});
    if(!(firstTurn)) this.draw(p,1);
    p.field.slice().forEach(c=>this.effs(c).forEach(x=>{ if(x.t==='turnstart') this.queue.push({type:'effect',p:p.i,src:c.c,eff:x}); }));
    const o=this.opp(p); o.field.slice().forEach(c=>this.effs(c).forEach(x=>{ if(x.t==='oppturnstart') this.queue.push({type:'effect',p:o.i,src:c.c,eff:x}); }));
    p.hand.slice().forEach(c=>c.d.effects.forEach(x=>{ if(x.t==='handturn') this.queue.push({type:'effect',p:p.i,src:c,eff:x}); }));
    p.relics.slice().forEach(r=>{ r.c.d.effects.forEach(x=>{ if(x.t==='turnstart') this.queue.push({type:'effect',p:p.i,src:r.c,eff:x}); }); if(r.cd!=null){ r.cd--; if(r.cd<=0){ p.relics.splice(p.relics.indexOf(r),1); p.grave.push(r.c); this.say('置物「'+r.c.d.name+'」のカウントダウンが0になり消えた'); r.c.d.effects.forEach(x=>{ if(x.t==='expire') this.queue.push({type:'effect',p:p.i,src:r.c,eff:x}); }); } } });
    this.run();
  }
  endTurn(){
    if(this.winner!=null) return false;
    const p=this.players[this.active];
    if(this.pending) return false;
    p.field.forEach(c=>this.effs(c).forEach(x=>{ if(x.t==='endturn') this.queue.push({type:'effect',p:p.i,src:c.c,eff:x}); }));
    p.relics.forEach(r=>r.c.d.effects.forEach(x=>{ if(x.t==='endturn') this.queue.push({type:'effect',p:p.i,src:r.c,eff:x}); }));
    this.queue.push({type:'endturn'});
    this.run(); return true;
  }
  doEndTurn(){
    const p=this.players[this.active];
    while(p.hand.length>HAND_MAX){ const c=p.hand.pop(); p.grave.push(c); this.say(p.name+'は手札上限で「'+c.d.name+'」を捨てた'); }
    p.field.forEach(c=>c.tmp=0); this.checkDeaths();
    if(p.extraTurn){ p.extraTurn=false; this.say('― '+p.name+'の追加ターン ―','turn'); } else this.active = 1-this.active;
    this.beginTurn(false);
  }

  // ---- cost ----
  costOf(p, d, card){ let c=Math.max(0,d.cost-((card&&card.cm)||0)-(d.sb==='cost'&&card?(card.boost||0):0)); if(d.type==='spell') this.opp(p).relics.forEach(r=>r.c.d.effects.forEach(x=>{ if(x.t==='static'&&x.e==='spellTax') c++; })); if(d.costFn==='allies') c=Math.max(0,c-p.field.length); if(d.costFn==='oppHand') c=this.opp(p).hand.length; if(d.type==='spell'){ this.opp(p).field.forEach(o=>this.effs(o).forEach(x=>{ if(x.t==='static'&&x.e==='spellTax') c++; })); } return c; }
  canAfford(p, d, card){ return this.costOf(p,d,card)<=p.energy; }
  canPlay(p, card){
    if(this.winner!=null||this.pending||this.players[this.active]!==p) return false;
    if(!p.hand.includes(card)) return false;
    const d=card.d;
    if(d.type==='creature' && p.field.length>=FIELD_MAX) return false;
    if(d.type==='equip' && p.field.length===0) return false;
    if(d.type==='relic' && p.relics.length>=3) return false;
    if(d.type==='trap' && (p.traps.length>=2 || p.traps.some(c=>c.d.id===d.id))) return false;
    if(d.type==='spell' && !this.spellHasUse(p,d)) return false;
    return this.canAfford(p,d,card);
  }
  spellHasUse(p,d){
    // a targeted-only spell with no candidate can't be cast
    const needs=d.effects.filter(x=>this.needsTarget(x));
    if(needs.length===0) return true;
    return needs.some(x=>this.candidates(p,x).length>0) || d.effects.some(x=>!this.needsTarget(x));
  }
  play(p, card){
    if(!this.canPlay(p,card)) return false;
    const d=card.d; const paid=this.costOf(p,d,card); p.energy-=paid;
    p.hand.splice(p.hand.indexOf(card),1);
    if(d.anomaly) d.revealed=true;
    const snap={combo:p.plays}; p.plays++;
    { const q=this.opp(p); if(q.bossRules && q.bossRules.devour && d.anomaly && q.hand.length<HAND_MAX){ q.hand.push(this.inst(d)); this.say(q.name+'は「'+d.name+'」を喰らい、写し取った','play'); } }
    if(d.type==='creature'){
      const cr=this.mkCr(card);
      p.field.push(cr); this.say(p.name+'は「'+d.name+'」を召喚（エナジー'+paid+'）','play'); this.ev('play',{p:p.i,uid:card.uid,d:card.d});
      this.fireTraps(this.opp(p),'enemySummon',card.uid);
      d.effects.forEach(x=>{ if(x.t==='etb') this.queue.push({type:'effect',p:p.i,src:card,eff:x,snap}); });
      this.trigger(p,'summon',card);
    } else if(d.type==='spell'){
      this.say(p.name+'は「'+d.name+'」を唱えた（エナジー'+paid+'）','play'); this.ev('play',{p:p.i,uid:card.uid,d:card.d});
      const countered=this.fireTraps(this.opp(p),'enemySpell').some(c=>c.d.effects.some(x=>x.e==='counter'));
      if(countered) this.say('「'+d.name+'」は打ち消された','destroy');
      else d.effects.forEach(x=>{ if(x.t==='cast') this.queue.push({type:'effect',p:p.i,src:card,eff:x,snap}); });
      this.queue.push({type:'toGrave',p:p.i,card});
      p.spellsCast++; this.boostHand(p,1); this.trigger(p,'spell',null);
    } else if(d.type==='relic'){
      p.relics.push({c:card, cd:d.countdown||null}); this.say(p.name+'は置物「'+d.name+'」を置いた（エナジー'+paid+'）','play'); this.ev('play',{p:p.i,uid:card.uid,d});
    } else if(d.type==='trap'){
      p.traps.push(card); this.say(p.name+'は罠を仕掛けた（エナジー'+paid+'）','play');
    } else if(d.type==='equip'){
      this.say(p.name+'は「'+d.name+'」を装備（エナジー'+paid+'）','play'); this.ev('play',{p:p.i,uid:card.uid,d:card.d});
      this.queue.push({type:'equip',p:p.i,card});
    }
    this.trigger(p,'play',card);
    this.run(); return true;
  }
  boostHand(p,n){ p.hand.forEach(c=>{ if(c.d.sb) c.boost=(c.boost||0)+n; }); 
  }
  // ---- leader ability ----
  leaderDef(p){ return p.leaderOverride || (p.main ? AN.LEADER[p.main] : null); }
  canUseAbility(p){
    const L=this.leaderDef(p); if(!L) return false;
    if(this.winner!=null||this.pending||this.players[this.active]!==p||p.abilityUsed) return false;
    if(p.energy<L.cost) return false;
    const efs=[].concat(L.ef);
    for(const x of efs){ if(this.needsTarget(x) && this.candidates(p,x).length===0) return false; }
    if([].concat(L.ef).some(x=>x.e==='token'||x.e==='tokens') && p.field.length>=FIELD_MAX) return false;
    return true;
  }
  useAbility(p){
    if(!this.canUseAbility(p)) return false;
    const L=this.leaderDef(p); p.energy-=L.cost; p.abilityUsed=true;
    const src={uid:-1, d:{name:'リーダー能力「'+L.name+'」', attr:[p.main], kw:[], effects:[]}};
    this.say(p.name+'はリーダー能力「'+L.name+'」を使った（エナジー'+L.cost+'）','play');
    [].concat(L.ef).forEach(x=>this.queue.push({type:'effect',p:p.i,src,eff:x}));
    p.plays++; if(p.main==='tide') this.boostHand(p,1);
    this.trigger(p,'ability',null);
    this.run(); return true;
  }
  // ---- attack ----
  canAttackWith(p, cr){
    if(this.winner!=null||this.pending||this.players[this.active]!==p) return false;
    if(!p.field.includes(cr)||cr.tapped) return false;
    if(this.hasKw(cr,'noattack')) return false;
    if(cr.attacked && !(this.hasKw(cr,'double') && !cr.doubled)) return false;
    if(cr.sick && !this.hasKw(cr,'haste')) return false;
    return true;
  }
  attackTargets(p, cr){
    const o=this.opp(p);
    const guards=o.field.filter(c=>!c.tapped && this.hasKw(c,'blocker'));
    if(guards.length && !this.hasKw(cr,'unblockable')) return guards.map(c=>c.c.uid);
    const t=['player']; o.field.forEach(c=>t.push(c.c.uid)); return t;
  }
  attack(p, cr, target){
    if(!this.canAttackWith(p,cr)) return false;
    if(!this.attackTargets(p,cr).includes(target)) return false;
    this.phase='attack';
    if(cr.attacked && this.hasKw(cr,'double')) cr.doubled=true;
    cr.attacked=true;
    const tgtName = target==='player' ? this.opp(p).name : '「'+this.findCr(target).c.d.name+'」';
    this.say(p.name+'の「'+cr.c.d.name+'」が'+tgtName+'に攻撃','attack'); this.ev('attack',{p:p.i,uid:cr.c.uid,target});
    this.attackCtx={attacker:cr, target, p:p.i, blocker:null};
    this.fireTraps(this.opp(p),'enemyAttack',cr.c.uid);
    this.effs(cr).forEach(x=>{ if(x.t==='atk') this.queue.push({type:'effect',p:p.i,src:cr.c,eff:x}); });
    this.queue.push({type:'block'}); this.queue.push({type:'combat'});
    this.run(); return true;
  }
  blockCandidates(){ return []; } // v1.2: 守護方式（挑発）。ブロック宣言は廃止
  resolveCombat(){
    const ctx=this.attackCtx; this.attackCtx=null; if(!ctx) return;
    const atk=ctx.attacker, p=this.players[ctx.p], def=this.opp(p);
    if(!p.field.includes(atk)) return; // attacker left
    let target = ctx.blocker; let retaliate=true;
    if(target){ target.tapped=true; this.say(def.name+'の「'+target.c.d.name+'」がブロック','block'); }
    else if(ctx.target!=='player'){ target=this.findCr(ctx.target); if(!target) return; retaliate=!target.stun; }
    if(!target){
      const dmg=this.power(atk);
      this.ev('hit',{p:def.i,uid:atk.c.uid});
      this.loseLife(def,dmg,'「'+atk.c.d.name+'」の攻撃');
      if(this.hasKw(atk,'drain')) this.gainLife(p,dmg);
      return;
    }
    const pa=this.power(atk), pb=this.power(target);
    if(target && this.hasKw(atk,'breakthrough')){
      // v2.5: 突破はクリーチャーへの攻撃すべてで有効。相手の残り体力（猛毒なら1）を超えた分が相手プレイヤーに通る。装甲で止められたら通らない
      const need = (this.hasKw(target,'armor')&&!target.armorUsed) ? Infinity : (this.hasKw(atk,'deathtouch') ? 1 : Math.max(0,this.health(target)));
      const over = pa - need;
      if(over>0){ this.loseLife(def, over, '突破'); if(this.hasKw(atk,'drain')) this.gainLife(p,over); }
    }
    this.battle(atk,target,0,retaliate);
  }
  battle(atk, target, bonus, retaliate){
    const pa=this.power(atk)+(bonus||0), pb=this.power(target);
    this.ev('battle',{a:atk.c.uid,b:target.c.uid});
    this.say('「'+atk.c.d.name+'」('+pa+') と「'+target.c.d.name+'」('+pb+') が戦闘'+(retaliate===false?'（気絶中のため反撃なし）':''),'battle');
    this.dealDamage(target, pa, false, atk);
    if(retaliate!==false) this.dealDamage(atk, pb, false, target);
    this.checkDeaths();
  }
  // damage a creature. armor absorbs the first damage/destroy event entirely
  dealDamage(cr, n, check, src){
    if(n<=0) return;
    if(this.hasKw(cr,'armor') && !cr.armorUsed){ cr.armorUsed=true; this.say('「'+cr.c.d.name+'」の装甲が'+n+'ダメージを防いだ'); this.ev('armor',{uid:cr.c.uid}); return; }
    cr.dmg+=n;
    if(this.health(cr)>0 && !(src && this.hasKw(src,'deathtouch'))){ const q=this.owner(cr); if(q) this.effs(cr).forEach(x=>{ if(x.t==='damaged') this.queue.push({type:'effect',p:q.i,src:cr.c,eff:x}); }); }
    if(src && this.hasKw(src,'deathtouch') && this.health(cr)>0){ cr.dmg=this.maxHealth(cr); this.say('「'+cr.c.d.name+'」に猛毒がまわった','battle'); } this.ev('dmg',{uid:cr.c.uid,n});
    this.say('「'+cr.c.d.name+'」に'+n+'ダメージ（体力 '+Math.max(0,this.health(cr))+'/'+this.maxHealth(cr)+'）','battle');
    if(check!==false) this.checkDeaths();
  }
  checkDeaths(){
    for(const p of this.players){ p.field.slice().forEach(cr=>{ if(p.field.includes(cr) && this.health(cr)<=0) this.kill(cr); }); }
  }
  kill(cr){
    const p=this.owner(cr); if(!p) return;
    p.fallen=(p.fallen||0)+1;
    p.field.splice(p.field.indexOf(cr),1);
    cr.equips.forEach(e=>p.grave.push(e)); if(!cr.c.d.token) p.grave.push(cr.c);
    p.souls++;
    this.say('「'+cr.c.d.name+'」は破壊された','destroy'); this.ev('destroy',{p:p.i,uid:cr.c.uid});
    this.trigger(p,'allyDeath',cr.c);
    this.trigger(this.opp(p),'enemyDeath',null);
    this.effs(cr).forEach(x=>{ if(x.t==='death') this.queue.push({type:'effect',p:p.i,src:cr.c,eff:x}); });
  }
  destroy(cr){
    const p=this.owner(cr); if(!p) return;
    if(this.hasKw(cr,'armor') && !cr.armorUsed){ cr.armorUsed=true; this.say('「'+cr.c.d.name+'」の装甲が破壊を防いだ'); this.ev('armor',{uid:cr.c.uid}); return; }
    this.kill(cr);
  }
  bounce(cr){
    const p=this.owner(cr); if(!p) return;
    p.field.splice(p.field.indexOf(cr),1); cr.equips.forEach(e=>p.grave.push(e)); if(!cr.c.d.token) p.hand.push(cr.c);
    this.say('「'+cr.c.d.name+'」は手札に戻った','bounce'); this.ev('bounce',{p:p.i,uid:cr.c.uid});
  }

  // ---- effects ----
  needsTarget(x){ return ['weaken','destroy','dmg','bounce','freeze','tap','revive','buff','fight','pumpTarget','steal','polymorph','copyEnemy','ping','shuffleBack','morph','grant','evolve','sac'].includes(x.e) && !x.all; }
  needsPick(x){ return ['discover','scry'].includes(x.e); }
  candidates(p, x, src){
    const o=this.opp(p);
    switch(x.e){
      case 'weaken': case 'destroy': case 'dmg': case 'bounce': case 'freeze': case 'tap': case 'steal': case 'polymorph': case 'copyEnemy': case 'shuffleBack': case 'morph':
        return o.field.filter(c=>{
          if(x.tapped && !c.tapped) return false;
          if(x.damaged && !(c.dmg>0) && !(x.anyIf && this.reqOk(p, x.anyIf, null, false))) return false;
          if(x.minPower!=null && this.power(c)<x.minPower) return false;
          if(x.maxPower!=null && this.power(c)>x.maxPower) return false;
          if(x.maxCost!=null && c.c.d.cost>x.maxCost) return false;
          if(x.e==='tap' && c.stun) return false;
          return true;
        }).map(c=>c.c.uid);
      case 'ping': return ['player'].concat(o.field.map(c=>c.c.uid));
      case 'sac': return p.field.filter(c=>!src||c.c!==src).map(c=>c.c.uid);
      case 'revive': return p.grave.filter(c=>c.d.type==='creature'&&!c.d.token&&c!==src&&c.d.cost<=x.maxCost).map(c=>c.uid);
      case 'buff': case 'pumpTarget': case 'evolve': return p.field.map(c=>c.c.uid);
      case 'grant': return p.field.filter(c=>!this.hasKw(c,x.kw)).map(c=>c.c.uid);
      case 'fight': return p.field.length? o.field.map(c=>c.c.uid) : [];
    }
    return [];
  }
  // v2.6: コピー・進化・蘇生などで場に出たクリーチャーも登場時効果を発動する。
  // ただし、そうして発動した登場時効果の中の「クリーチャーを場に出す効果」は発動しない（無限連鎖の防止）。
  applyEffect(t){
    const ENTRY=Game.ENTRY;
    if(!ENTRY.has(t.eff.e)) return this.applyEffectCore(t);
    const before=new Set([...this.players[0].field,...this.players[1].field]);
    this.applyEffectCore(t);
    const depth=(t.depth||0)+1;
    this.players.forEach(q=>q.field.forEach(cr=>{
      if(before.has(cr) || cr.c.d.token) return;
      this.effs(cr).forEach(y=>{ if(y.t==='etb') this.queue.push({type:'effect',p:q.i,src:cr.c,eff:y,depth,snap:{combo:0}}); });
    }));
  }
  applyEffectCore(t){
    const p=this.players[t.p], o=this.opp(p), x=t.eff; let n=x.n;
    if(x.req && !this.reqOk(p, x.req, t, true)) return;
    if(x.bonus && this.reqOk(p, x.bonus.req, t, true)) n=(n||0)+x.bonus.n;
    if(x.scale){ n=(x.n||0)+this.scaleCount(p,x,t)*(x.k||1); if(x.max) n=Math.min(n,x.max); if(x.scale!=='boost' && !x.n && n<=0) return; }
    if(x.per==='attr'){ const a=t.src.d.attr[0]; n = x.n * p.field.filter(c=>c.c.d.attr.includes(a)).length; if(n<=0) return; }
    switch(x.e){
      case 'draw': this.draw(p,n); break;
      case 'damage': this.loseLife(o,n,'「'+t.src.d.name+'」'); break;
      case 'heal': this.gainLife(p,n); break;
      case 'lifecost': this.loseLife(p,n,'「'+t.src.d.name+'」'); break;
      case 'ramp': { const b=p.energyMax; p.energyMax=Math.min(ENERGY_MAX,p.energyMax+n); this.say(p.name+'の最大エナジー '+b+'→'+p.energyMax,'charge'); break; }
      case 'energyNow': p.energy=Math.min(ENERGY_MAX,p.energy+n); this.say(p.name+'のエナジー+'+n+'（このターン）','charge'); break;
      case 'discard': { const q=x.self?p:o; for(let i=0;i<n;i++){ if(q.hand.length===0) break; const k=this.rng.int(q.hand.length); const c=q.hand.splice(k,1)[0]; q.grave.push(c); q.souls++; this.say(q.name+'は「'+c.d.name+'」を捨てた','discard'); } break; }
      case 'buffAll': p.field.forEach(c=>{ if(!x.attr||c.c.d.attr.includes(x.attr)) c.tmp+=n; }); this.say(p.name+'のクリーチャーに、ターン終了時まで+'+n+'/+'+n); break;
      case 'pumpSelf': { const cr=this.findCr(t.src.uid); if(cr){ cr.pump+=n; this.say('「'+cr.c.d.name+'」に+'+n+'/+'+n); } break; }
      case 'destroyAll': o.field.slice().forEach(c=>{ if(x.tapped&&!c.tapped) return; if(x.damaged&&!(c.dmg>0)) return; if(x.maxPower!=null&&this.power(c)>x.maxPower) return; this.destroy(c); }); break;
      case 'bounceAll': o.field.slice().forEach(c=>this.bounce(c)); break;
      case 'tapAll': o.field.forEach(c=>{ c.tapped=true; c.stun=true; }); this.say(o.name+'のクリーチャーはすべてレストして気絶'); break;
      case 'destroy': { const c=this.findCr(t.choice); if(c) this.destroy(c); break; }
      case 'dmg': { const c=this.findCr(t.choice); if(c) this.dealDamage(c,n); break; }
      case 'dmgAll': o.field.slice().forEach(c=>this.dealDamage(c,n,false)); this.checkDeaths(); break;
      case 'bounce': { const c=this.findCr(t.choice); if(c) this.bounce(c); break; }
      case 'freeze': { const c=this.findCr(t.choice); if(c){ c.tapped=true; c.frozen=true; c.stun=true; this.say('「'+c.c.d.name+'」は凍結した'); } break; }
      case 'tap': { const c=this.findCr(t.choice); if(c){ c.tapped=true; c.stun=true; this.say('「'+c.c.d.name+'」はレストして気絶した'); } break; }
      case 'buff': { const c=this.findCr(t.choice); if(c){ c.tmp+=n; this.say('「'+c.c.d.name+'」に、ターン終了時まで+'+n+'/+'+n); } break; }
      case 'pumpTarget': { const c=this.findCr(t.choice); if(c){ c.pump+=n; this.say('「'+c.c.d.name+'」に+'+n+'/+'+n+'（永続）'); } break; }
      case 'fight': { const c=this.findCr(t.choice); const mine=p.field.slice().sort((a,b)=>this.power(b)-this.power(a))[0]; if(c&&mine){ this.say('「'+mine.c.d.name+'」が「'+c.c.d.name+'」と戦闘'); this.battle(mine,c,n||0); } break; }
      case 'freezeAll': o.field.forEach(c=>{ c.tapped=true; c.frozen=true; c.stun=true; }); this.say(o.name+'のクリーチャーはすべて凍結'); break;
      case 'selfDestroy': { const cr=this.findCr(t.src.uid); if(cr) this.destroy(cr); break; }
      case 'steal': { const c=this.findCr(t.choice); if(c && p.field.length<FIELD_MAX){ o.field.splice(o.field.indexOf(c),1); c.sick=true; c.tapped=false; c.attacked=false; p.field.push(c); this.say(p.name+'は「'+c.c.d.name+'」のコントロールを奪った','play'); } break; }
      case 'swapBoards': { const a=p.field, b=o.field; p.field=b; o.field=a; [...p.field,...o.field].forEach(c=>{ c.sick=true; }); this.say('場のクリーチャーがすべて入れ替わった！','play'); break; }
      case 'swapLife': { const a=p.life; p.life=o.life; o.life=a; this.say('ライフが入れ替わった！ '+p.name+' '+p.life+' / '+o.name+' '+o.life,'life'); this.checkWin(); break; }
      case 'cloneSelf': { const cr=this.findCr(t.src.uid); if(cr && p.field.length<FIELD_MAX){ const nc=this.mkCr(this.inst(cr.c.d)); nc.pump=cr.pump; p.field.push(nc); this.say('「'+cr.c.d.name+'」のコピーが現れた','play'); } break; }
      case 'polymorph': { const c=this.findCr(t.choice); if(c){ const i=o.field.indexOf(c); const nc=this.mkCr(this.inst(AN.FROG)); nc.sick=c.sick; nc.tapped=c.tapped; o.field[i]=nc; this.say('「'+c.c.d.name+'」はカエルになった','play'); } break; }
      case 'equalize': { [...p.field,...o.field].forEach(c=>{ c.fixed=n; c.pump=0; c.dmg=0; }); this.say('すべてのクリーチャーが'+n+'/'+n+'になった','play'); break; }
      case 'mill': { let k=0; for(let i=0;i<n;i++){ if(!o.deck.length) break; o.grave.push(o.deck.pop()); k++; } this.say(o.name+'の山札から'+k+'枚が墓地へ','discard'); break; }
      case 'handRefresh': { [p,o].forEach(q=>{ const k=q.hand.length; q.hand.forEach(c=>q.grave.push(c)); q.hand=[]; this.draw(q,k,true); this.say(q.name+'は手札'+k+'枚を引き直した','draw'); }); break; }
      case 'massRevive': { [p,o].forEach(q=>{ const cs=q.grave.filter(c=>c.d.type==='creature'&&!c.d.token&&c!==t.src).sort((a,b)=>b.d.cost-a.d.cost); let k=0; for(const c of cs){ if(q.field.length>=FIELD_MAX) break; q.grave.splice(q.grave.indexOf(c),1); q.field.push(this.mkCr(c)); k++; } this.say(q.name+'の墓地から'+k+'体が蘇った','play'); }); break; }
      case 'dmgAllBoth': { [...p.field,...o.field].forEach(c=>this.dealDamage(c,n,false)); this.checkDeaths(); break; }
      case 'toHand': { const c=t.src; if(p.grave.includes(c)){ p.grave.splice(p.grave.indexOf(c),1); p.hand.push(c); this.say('「'+c.d.name+'」は手札に戻った','bounce'); } break; }
      case 'sacrifice': { const cr=this.findCr(t.src.uid); if(cr){ const others=p.field.filter(c=>c!==cr); others.forEach(c=>this.kill(c)); cr.pump+=others.length*3; this.say('「'+cr.c.d.name+'」は'+others.length+'体を生贄にして+'+(others.length*3)+'/+'+(others.length*3),'play'); } break; }
      case 'coin': { if(this.rng()<0.5){ this.say('コインは表！','play'); o.field.slice().forEach(c=>this.dealDamage(c,5,false)); this.checkDeaths(); } else { this.say('コインは裏…','play'); this.loseLife(p,5,'コイン'); } break; }
      case 'copyEnemy': { const c=this.findCr(t.choice); if(c && p.field.length<FIELD_MAX){ p.field.push(this.mkCr(this.inst(c.c.d))); this.say(p.name+'は「'+c.c.d.name+'」のコピーを出した','play'); } break; }
      case 'resetAll': { [p,o].forEach(q=>q.field.slice().forEach(c=>this.bounce(c))); break; }
      case 'graveSteal': { const cs=o.grave.filter(c=>c.d.type==='creature'&&!c.d.token).sort((a,b)=>b.d.cost-a.d.cost); if(cs.length && p.field.length<FIELD_MAX){ const c=cs[0]; o.grave.splice(o.grave.indexOf(c),1); p.field.push(this.mkCr(c)); this.say(p.name+'は相手の墓地から「'+c.d.name+'」を奪った','play'); } break; }
      case 'silenceAll': { o.field.forEach(c=>{ c.silenced=true; c.grants=[]; }); this.say(o.name+'のクリーチャーは能力を失った','play'); break; }
      case 'tokens': { const tok=AN.TOKENS[x.tok||'none']; const q=x.opp?o:p; let k=0; for(let i=0;i<n;i++){ if(q.field.length>=FIELD_MAX) break; q.field.push(this.mkCr(this.inst(tok))); k++; } this.say(q.name+'の場に「'+tok.name+'」が'+k+'体出た','play'); for(let i=0;i<k;i++) this.trigger(q,'summon',null); break; }
      case 'discover': { const o2=t.opts[t.choice]; if(o2){ p.hand.push(this.inst(o2.d)); this.say(p.name+'は「'+o2.d.name+'」を発見した','draw'); } break; }
      case 'scry': { const o2=t.opts[t.choice]; if(o2){ const i=p.deck.indexOf(o2.card); if(i>=0) p.deck.splice(i,1); if(x.discount) o2.card.cm=(o2.card.cm||0)+x.discount; p.hand.push(o2.card); t.opts.forEach(z=>{ if(z!==o2){ const j=p.deck.indexOf(z.card); if(j>=0){ p.deck.splice(j,1); p.deck.unshift(z.card); } } }); this.say(p.name+'は山札から「'+o2.d.name+'」を手札に加え、残りを下に置いた','draw'); } break; }
      case 'randomDmg': { for(let i=0;i<n;i++){ const tg=['player'].concat(o.field.filter(c=>this.health(c)>0)); const pick=tg[this.rng.int(tg.length)]; if(pick==='player') this.loseLife(o,1,t.src.d.name); else this.dealDamage(pick,1); if(this.winner!=null) break; } break; }
      case 'randomCard': { const pool=this.poolFor(p); const d=pool[this.rng.int(pool.length)]; p.hand.push(this.inst(d)); this.say(p.name+'は「'+d.name+'」を手札に加えた','draw'); break; }
      case 'tutor': { const cs=p.deck.filter(c=>c.d.type==='creature'); if(cs.length){ const c=cs[this.rng.int(cs.length)]; p.deck.splice(p.deck.indexOf(c),1); p.hand.push(c); this.say(p.name+'は山札から「'+c.d.name+'」を手札に加えた','draw'); } break; }
      case 'shuffleBack': { const c=this.findCr(t.choice); if(c){ o.field.splice(o.field.indexOf(c),1); c.equips.forEach(e=>o.grave.push(e)); if(!c.c.d.token){ o.deck.splice(this.rng.int(o.deck.length+1),0,c.c); } this.say('「'+c.c.d.name+'」は山札に戻された','bounce'); } break; }
      case 'morph': { const c=this.findCr(t.choice); if(c){ const cs=AN.CARDS.filter(d=>d.type==='creature'&&d.cost===c.c.d.cost&&d.id!==c.c.d.id); if(cs.length){ const d=cs[this.rng.int(cs.length)]; const i=o.field.indexOf(c); const nc=this.mkCr(this.inst(d)); nc.sick=c.sick; nc.tapped=c.tapped; o.field[i]=nc; this.say('「'+c.c.d.name+'」は「'+d.name+'」に変身した','play'); } } break; }
      case 'weaken': { const c=this.findCr(t.choice); if(c && AN.RULES.armorWeaken && this.hasKw(c,'armor') && !c.armorUsed){ c.armorUsed=true; this.say('「'+c.c.d.name+'」の装甲が弱体化を防いだ'); break; } if(c){ c.pump-=n; this.say('「'+c.c.d.name+'」に-'+n+'/-'+n,'battle'); this.checkDeaths(); } break; }
      case 'weakenAll': { o.field.forEach(c=>{ if(AN.RULES.armorWeaken && this.hasKw(c,'armor') && !c.armorUsed){ c.armorUsed=true; return; } c.pump-=n; }); this.say(o.name+'のクリーチャーすべてに-'+n+'/-'+n,'battle'); this.checkDeaths(); break; }
      case 'stealTop': { const cs=o.field.slice().sort((a,b)=>this.power(b)-this.power(a)).slice(0,n); cs.forEach(c=>{ if(p.field.length>=FIELD_MAX) return; o.field.splice(o.field.indexOf(c),1); c.sick=true; c.tapped=false; c.attacked=false; p.field.push(c); this.say(p.name+'は「'+c.c.d.name+'」を支配した','play'); }); break; }
      case 'wipeGrow': { const me=this.findCr(t.src.uid); let k=0; [p,o].forEach(q=>q.field.slice().forEach(c=>{ if(c!==me){ const before=q.field.length; this.destroy(c); if(q.field.length<before) k++; } })); if(me){ me.pump+=k; } this.say('世界が終わった（'+k+'体が破壊され、+'+k+'/+'+k+'）','destroy'); break; }
      case 'extraTurn': { p.extraTurn=true; this.say(p.name+'は時を支配した。このターンの後、もう一度ターンを得る','play'); break; }
      case 'copyOppHand': { let k=0; o.hand.forEach(c=>{ if(p.hand.length>=HAND_MAX) return; p.hand.push(this.inst(c.d)); k++; }); this.say(p.name+'は相手の手札'+k+'枚を写し取った','draw'); break; }
      case 'reviveRandom': { const cs=this.rng.shuffle(p.grave.filter(c=>c.d.type==='creature'&&!c.d.token&&c!==t.src)).slice(0,n); cs.forEach(c=>{ if(p.field.length>=FIELD_MAX) return; p.grave.splice(p.grave.indexOf(c),1); p.field.push(this.mkCr(c)); this.say('「'+c.d.name+'」が冥府から戻った','play'); }); break; }
      case 'halveLife': { p.life=Math.ceil(p.life/2); this.say(p.name+'のライフは'+p.life+'になった','life'); break; }
      case 'tokensRandom': { let k=0; for(let i=0;i<n;i++){ if(p.field.length>=FIELD_MAX) break; const tok=AN.TOKENS[x.pool[this.rng.int(x.pool.length)]]; p.field.push(this.mkCr(this.inst(tok))); this.say(p.name+'の場に「'+tok.name+'」が出た','play'); k++; } break; }
      case 'dmgOthers': { const me=this.findCr(t.src.uid); [...p.field,...o.field].forEach(c=>{ if(c!==me) this.dealDamage(c,n,false); }); this.checkDeaths(); break; }
      case 'addDream': { if(p.hand.length<HAND_MAX){ const keys=['dream_blade','dream_wake','dream_wing','dream_heal','dream_rise']; const sp=AN.SPECIAL[keys[this.rng.int(keys.length)]]; p.hand.push(this.inst(sp)); this.say(p.name+'の手札に夢カード「'+sp.name+'」が加わった','draw'); } break; }
      case 'becomeLord': { p.life=n; p.leaderOverride=AN.LEADER_EX[x.leader]; p.abilityUsed=false; this.say(p.name+'は魔王となった！ライフ'+n+'・リーダー能力「'+p.leaderOverride.name+'」','play'); this.checkWin(); break; }
      case 'boomDmg': { const tg=['player'].concat(o.field.filter(c=>this.health(c)>0)); const pick=tg[this.rng.int(tg.length)]; const d=1+this.rng.int(4); if(pick==='player') this.loseLife(o,d,t.src.d.name); else this.dealDamage(pick,d); break; }
      case 'wipeOthers': { const me=this.findCr(t.src.uid); [p,o].forEach(q=>q.field.slice().forEach(c=>{ if(c!==me) this.destroy(c); })); this.say('場が焼き払われた','destroy'); break; }
      case 'discardSelfAll': { const k=p.hand.length; p.hand.forEach(c=>{ p.grave.push(c); p.souls++; }); p.hand=[]; this.say(p.name+'は手札'+k+'枚を捨てた','discard'); break; }
      case 'bigRandom': { const tg=['player'].concat(o.field.filter(c=>this.health(c)>0)); const pick=tg[this.rng.int(tg.length)]; if(pick==='player') this.loseLife(o,n,t.src.d.name); else this.dealDamage(pick,n); break; }
      case 'setLeader': { p.leaderOverride=AN.LEADER_EX[x.leader]; p.abilityUsed=false; this.say(p.name+'のリーダー能力が「'+p.leaderOverride.name+'」になった','play'); break; }
      case 'swapLeader': { const a=this.leaderDef(p), b=this.leaderDef(o); p.leaderOverride=b; o.leaderOverride=a; this.say('リーダー能力が入れ替わった！（'+p.name+'：'+(b?b.name:'なし')+'／'+o.name+'：'+(a?a.name:'なし')+'）','play'); break; }
      case 'pumpRandomAlly': { if(p.field.length){ const c=p.field[this.rng.int(p.field.length)]; c.pump+=n; this.say('「'+c.c.d.name+'」に+'+n+'/+'+n); } break; }
      case 'weakenRandom': { if(o.field.length){ const c=o.field[this.rng.int(o.field.length)]; c.pump-=n; this.say('「'+c.c.d.name+'」に-'+n+'/-'+n,'battle'); this.checkDeaths(); } break; }
      case 'counter': break;
      case 'randomDmgCr': { const cs=o.field.filter(c=>this.health(c)>0); if(cs.length) this.dealDamage(cs[this.rng.int(cs.length)], n); break; }
      case 'pumpAll': { p.field.forEach(c=>c.pump+=n); this.say(p.name+'のクリーチャーすべてに+'+n+'/+'+n,'play'); break; }
      case 'boostHand': { this.boostHand(p,n); this.say(p.name+'の手札の詠唱+'+n); break; }
      case 'sac': { const c=this.findCr(t.choice); if(c) this.kill(c); break; }
      case 'gainSouls': { p.souls+=n; break; }
      case 'recallSpell': { const cs=p.grave.filter(c=>c.d.type==='spell'&&!c.d.special); if(cs.length&&p.hand.length<HAND_MAX){ const c=cs[this.rng.int(cs.length)]; p.hand.push(this.inst(c.d)); this.say(p.name+'は「'+c.d.name+'」のコピーを手札に加えた','draw'); } break; }
      case 'devour': { const cr=this.findCr(t.src.uid); const k=p.souls; if(cr&&k>0){ p.souls=0; cr.pump+=k; this.say('「'+cr.c.d.name+'」は供物'+k+'を喰らい+'+k+'/+'+k,'play'); } break; }
      case 'reviveAllSelf': { const cs=p.grave.filter(c=>c.d.type==='creature'&&!c.d.token&&c!==t.src).sort((a,b)=>b.d.cost-a.d.cost); let k=0; for(const c of cs){ if(p.field.length>=FIELD_MAX) break; p.grave.splice(p.grave.indexOf(c),1); p.field.push(this.mkCr(c)); k++; } this.say(p.name+'の墓地から'+k+'体が蘇った','play'); break; }
      // ---- weird ----
      case 'swapHands': { const a=p.hand; p.hand=o.hand; o.hand=a; this.say('お互いの手札が入れ替わった！','play'); break; }
      case 'shiftSelf': { const i=p.hand.indexOf(t.src); if(i>=0){ const cs=AN.CARDS.filter(d=>d.cost===t.src.d.cost); if(cs.length){ const d=cs[this.rng.int(cs.length)]; p.hand[i]=this.inst(d); this.say(p.name+'の手札の「'+t.src.d.name+'」が「'+d.name+'」に変わった','draw'); } } break; }
      case 'giveSelf': { const cr=this.findCr(t.src.uid); if(cr && p.field.includes(cr) && o.field.length<FIELD_MAX){ p.field.splice(p.field.indexOf(cr),1); cr.sick=true; o.field.push(cr); this.say('「'+cr.c.d.name+'」は'+o.name+'のもとへ去った','play'); } break; }
      case 'setLifeBoth': { p.life=n; o.life=n; this.say('お互いのライフが'+n+'になった！','life'); break; }
      case 'castRandom': { const sp=AN.CARDS.filter(d=>d.type==='spell'); for(let i=0;i<n;i++){ const d=sp[this.rng.int(sp.length)]; const c=this.inst(d); this.say('ランダムに「'+d.name+'」が唱えられた','play'); d.effects.forEach(y=>{ if(y.t==='cast') this.queue.push({type:'effect',p:p.i,src:c,eff:y,rand:true,snap:{combo:0}}); }); } break; }
      case 'swapEnergy': { const a=p.energyMax; p.energyMax=o.energyMax; o.energyMax=a; p.energy=Math.min(p.energy,p.energyMax); this.say('最大エナジーが入れ替わった（'+p.energyMax+'／'+o.energyMax+'）','charge'); break; }
      case 'reroll': { const cr=this.findCr(t.src.uid); if(cr){ cr.roll=[1+this.rng.int(10),1+this.rng.int(10)]; cr.dmg=0; this.say('「'+cr.c.d.name+'」は'+this.power(cr)+'/'+this.maxHealth(cr)+'になった','play'); } break; }
      case 'coins': { let h=0; for(let i=0;i<n;i++) if(this.rng()<0.5) h++; this.say('コイン'+n+'回：表'+h+'・裏'+(n-h),'play'); this.draw(p,h); this.loseLife(p,n-h,'コイン'); break; }
      case 'deckTopBoth': { [p,o].forEach(q=>{ if(!q.deck.length) return; const c=q.deck[q.deck.length-1]; this.say(q.name+'の山札の一番上は「'+c.d.name+'」'); if(c.d.type==='creature'&&q.field.length<FIELD_MAX){ q.deck.pop(); q.field.push(this.mkCr(c)); } }); break; }
      case 'giftCopy': { if(o.field.length<FIELD_MAX){ o.field.push(this.mkCr(this.inst(t.src.d))); this.say(o.name+'の場に「'+t.src.d.name+'」のコピーが現れた','play'); } break; }
      case 'timeSkip': { p.bonusNext+=n; this.say(p.name+'は時を飛ばした','play'); this.queue=this.queue.filter(z=>z.type!=='endturn'); this.queue.push({type:'endturn'}); break; }
      case 'anomalyHand': { p.hand=p.hand.map(c=>this.inst(AN.makeAnomaly(this.rng, 1000+this.uid*3, null))); p.hand.forEach(c=>c.d.revealed=true); this.say(p.name+'の手札'+p.hand.length+'枚がアノマリーに変わった！','play'); break; }
      case 'giftAnomaly': { if(o.hand.length<HAND_MAX){ const c=this.inst(AN.makeAnomaly(this.rng, 1000+this.uid*3, null)); c.d.revealed=true; o.hand.push(c); this.say(o.name+'の手札にアノマリー「'+c.d.name+'」が加わった','play'); } break; }
      case 'swapGraveDeck': { const d=p.deck; p.deck=this.rng.shuffle(p.grave.filter(c=>!c.d.token)); p.grave=d; this.say(p.name+'の山札と墓地が入れ替わった（山札'+p.deck.length+'枚）','play'); break; }
      case 'doubleEnemy': { o.field.slice().forEach(c=>{ if(o.field.length<FIELD_MAX) o.field.push(this.mkCr(this.inst(c.c.d))); }); this.say(o.name+'のクリーチャーが増えた…','play'); break; }
      case 'shuffleOwners': { const all=[...p.field,...o.field]; p.field=[]; o.field=[]; all.forEach(c=>{ const q = this.rng()<0.5 ? p : o; const r = q.field.length<FIELD_MAX ? q : (q===p?o:p); c.sick=true; r.field.push(c); }); this.say('クリーチャーの持ち主がシャッフルされた！','play'); break; }
      case 'shrinkAll': { [...p.field,...o.field].forEach(c=>{ c.fixed=1; c.pump=0; c.dmg=0; c.roll=null; }); this.say('すべてのクリーチャーが1/1になった','play'); break; }
      case 'healOpp': this.gainLife(o,n); break;
      case 'drawOpp': this.draw(o,n); break;
      case 'grant': { const c=this.findCr(t.choice); if(c){ c.grants.push(x.kw); this.say('「'+c.c.d.name+'」は'+AN.KW[x.kw]+'を得た','play'); } break; }
      case 'grantAll': { p.field.forEach(c=>{ if(!c.grants.includes(x.kw)) c.grants.push(x.kw); }); this.say(p.name+'のクリーチャーはすべて'+AN.KW[x.kw]+'を得た','play'); break; }
      case 'addCard': { const q=x.to==='opp'?o:p; const sp=AN.SPECIAL[x.card]; let k=0; for(let i=0;i<(n||1);i++){ if(q.hand.length>=HAND_MAX) break; q.hand.push(this.inst(sp)); k++; } this.say(q.name+'の手札に「'+sp.name+'」が'+k+'枚加わった','draw'); break; }
      case 'deckAdd': { const sp=AN.SPECIAL[x.card]; for(let i=0;i<(n||1);i++){ o.deck.splice(this.rng.int(o.deck.length+1),0,this.inst(sp)); } this.say(o.name+'の山札に「'+sp.name+'」が'+(n||1)+'枚混ざった','discard'); break; }
      case 'transformHand': { const idxs=x.all ? p.hand.map((c,i)=>i) : this.rng.shuffle(p.hand.map((c,i)=>i)).slice(0,n||1); let k=0; idxs.forEach(i=>{ const c=p.hand[i]; if(!c||c.d.anomaly) return; let cs=this.poolFor(p).filter(d=>d.cost===c.d.cost&&d.id!==c.d.id); if(!cs.length) cs=AN.CARDS.filter(d=>d.cost===c.d.cost&&d.id!==c.d.id); if(cs.length){ p.hand[i]=this.inst(cs[this.rng.int(cs.length)]); k++; } }); this.say(p.name+'の手札'+k+'枚が変化した','draw'); break; }
      case 'evolve': { const list = x.all ? p.field.slice() : [this.findCr(t.choice)].filter(Boolean); list.forEach(c=>{ const cost=Math.min(8,c.c.d.cost+(n||1)); let cs=AN.CARDS.filter(d=>d.type==='creature'&&d.cost===cost); if(!cs.length) cs=AN.CARDS.filter(d=>d.type==='creature'&&d.cost>=cost); if(!cs.length) return; const d=cs[this.rng.int(cs.length)]; const i=p.field.indexOf(c); const nc=this.mkCr(this.inst(d)); nc.sick=c.sick; nc.attacked=c.attacked; nc.tapped=c.tapped; p.field[i]=nc; this.say('「'+c.c.d.name+'」は「'+d.name+'」に進化した','play'); }); break; }
      case 'copyHand': { if(o.hand.length && p.hand.length<HAND_MAX){ const c=o.hand[this.rng.int(o.hand.length)]; p.hand.push(this.inst(c.d)); this.say(p.name+'は相手の手札から「'+c.d.name+'」のコピーを得た','draw'); } break; }
      case 'graveCopy': { const cs=o.grave.filter(c=>!c.d.token&&!c.d.special); if(cs.length && p.hand.length<HAND_MAX){ const c=cs[this.rng.int(cs.length)]; p.hand.push(this.inst(c.d)); this.say(p.name+'は相手の墓地から「'+c.d.name+'」のコピーを得た','draw'); } break; }
      case 'stealHand': { let k=0; for(let i=0;i<(n||1);i++){ if(!o.hand.length||p.hand.length>=HAND_MAX) break; const c=o.hand.splice(this.rng.int(o.hand.length),1)[0]; p.hand.push(c); k++; } this.say(p.name+'は相手の手札から'+k+'枚奪った','discard'); break; }
      case 'shuffleHand': { const k=o.hand.length; o.hand.forEach(c=>o.deck.push(c)); o.hand=[]; o.deck=this.rng.shuffle(o.deck); this.draw(o,k,true); this.say(o.name+'の手札'+k+'枚が山札に戻され、引き直した','draw'); break; }
      case 'doubleSelf': { const cr=this.findCr(t.src.uid); if(cr){ cr.mult=(cr.mult||1)*2; this.say('「'+cr.c.d.name+'」は'+this.power(cr)+'/'+this.maxHealth(cr)+'になった','play'); } break; }
      case 'swapStatsAll': { [...p.field,...o.field].forEach(c=>{ c.swapped=!c.swapped; }); this.say('すべてのクリーチャーの攻撃力と体力が入れ替わった','play'); this.checkDeaths(); break; }
      case 'discountHand': { p.hand.forEach(c=>{ c.cm=(c.cm||0)+n; }); this.say(p.name+'の手札のコストが'+n+'下がった','play'); break; }
      case 'ping': { if(t.choice==='player'){ this.loseLife(o,n,t.src.d.name); } else { const c=this.findCr(t.choice); if(c) this.dealDamage(c,n); } break; }
      case 'token': { if(p.field.length<FIELD_MAX){ p.field.push(this.mkCr(this.inst(AN.SKULL))); this.say(p.name+'は「骸」を出した','play'); } break; }
      case 'revive': { const c=p.grave.find(g=>g.uid===t.choice); if(c&&p.field.length<FIELD_MAX){ p.grave.splice(p.grave.indexOf(c),1); const cr=this.mkCr(c); p.field.push(cr); this.say('「'+c.d.name+'」が墓地から場に出た（コスト不要）','play'); this.ev('play',{p:p.i,uid:c.uid}); } break; }
    }
    this.checkWin();
  }
  poolFor(p){ const a=p.main; return AN.CARDS.filter(c=>c.attr.length===0 || (a && c.attr.includes(a))); }
  pickOptions(p, x){
    if(x.e==='discover'){ const pool=this.rng.shuffle(this.poolFor(p)); return pool.slice(0,3).map(d=>({d})); }
    if(x.e==='scry'){ const n=Math.min(x.n, p.deck.length); return p.deck.slice(p.deck.length-n).reverse().map(c=>({d:c.d, card:c})); }
    return [];
  }
  exec(t){
    switch(t.type){
      case 'effect': {
        if((t.depth||0)>=1 && Game.ENTRY.has(t.eff.e)){ this.say('「'+t.src.d.name+'」の「'+AN.effectText(t.eff).replace(/。$/,'')+'」は連鎖防止のため発動しない'); return; }
        if(t.eff.req && !this.reqOk(this.players[t.p], t.eff.req, t, false)) return;
        if(t.rand && this.needsPick(t.eff) && t.choice===undefined){ t.opts=this.pickOptions(this.players[t.p], t.eff); if(!t.opts.length) return; t.choice=this.rng.int(t.opts.length); }
        if(t.rand && this.needsTarget(t.eff) && t.choice===undefined){ const cs=this.candidates(this.players[t.p], t.eff, t.src); if(!cs.length) return; t.choice=cs[this.rng.int(cs.length)]; }
        if(this.needsPick(t.eff) && t.choice===undefined){
          if(!t.opts) t.opts=this.pickOptions(this.players[t.p], t.eff);
          if(t.opts.length===0) return;
          if(t.opts.length===1) t.choice=0;
          else { const c=this.ask(t.p,{type:'pick',opts:t.opts,eff:t.eff,src:t.src,p:t.p}); if(c===undefined) return 'wait'; t.choice=c; }
        }
        if(this.needsTarget(t.eff) && t.choice===undefined){
          const cands=this.candidates(this.players[t.p], t.eff, t.src);
          if(cands.length===0) return;
          if(cands.length===1) t.choice=cands[0];
          else { const c=this.ask(t.p,{type:'target',cands,eff:t.eff,src:t.src,p:t.p}); if(c===undefined) return 'wait'; t.choice=c; }
        }
        if(t.eff.e==='revive' && this.players[t.p].field.length>=FIELD_MAX) return;
        this.applyEffect(t); return;
      }
      case 'toGrave': this.players[t.p].grave.push(t.card); this.players[t.p].souls++; return;
      case 'equip': {
        const p=this.players[t.p];
        if(t.choice===undefined){
          const cands=p.field.map(c=>c.c.uid); if(cands.length===0){ p.grave.push(t.card); return; }
          if(cands.length===1) t.choice=cands[0];
          else { const c=this.ask(t.p,{type:'equip',cands,src:t.card,p:t.p}); if(c===undefined) return 'wait'; t.choice=c; }
        }
        const cr=this.findCr(t.choice); if(!cr){ p.grave.push(t.card); return; }
        cr.equips.push(t.card); this.say('「'+cr.c.d.name+'」に「'+t.card.d.name+'」を装備'); return;
      }
      case 'block': {
        const ctx=this.attackCtx; if(!ctx) return;
        if(!this.players[ctx.p].field.includes(ctx.attacker)) return;
        const cands=this.blockCandidates().map(c=>c.c.uid);
        if(cands.length===0) return;
        if(t.choice===undefined){
          const c=this.ask(1-ctx.p,{type:'block',cands,attacker:ctx.attacker.c.uid,target:ctx.target,p:1-ctx.p});
          if(c===undefined) return 'wait'; t.choice=c;
        }
        if(t.choice){ const b=this.findCr(t.choice); if(b && cands.includes(t.choice)) ctx.blocker=b; }
        return;
      }
      case 'combat': this.resolveCombat(); return;
      case 'endturn': this.doEndTurn(); return;
    }
  }
  run(){
    if(this.halt) return;
    let guard=0;
    while(this.winner==null && this.queue.length && guard++<500){
      const t=this.queue.shift();
      if(t.type==='trapPause'){ if(this.uiPause){ this.halt=true; return; } continue; }
      const r=this.exec(t);
      if(r==='wait'){ this.pending=t; this.pendingInfo=this._lastAsk; return; }
    }
  }
  // v3.7.2: 罠の発動時に一時停止（画面で罠の公開を見せてから効果と戦闘を解決するため）
  resume(){ if(!this.halt) return; this.halt=false; this.run(); }
  ask(pi, pending){ this._lastAsk=pending; const f=this.choosers[pi]; if(!f) return undefined; return f(this,pending); }
  provideChoice(choice){
    if(!this.pending) return false;
    const t=this.pending; this.pending=null; t.choice=choice; this.queue.unshift(t); this.run(); return true;
  }
  // full visible-state snapshot helpers for UI
  activePlayer(){ return this.players[this.active]; }
}
AN.RULES=AN.RULES||{armorWeaken:false};
Game.ENTRY=new Set(['reviveRandom','cloneSelf','copyEnemy','evolve','revive','reviveAllSelf','massRevive','graveSteal','deckTopBoth','giftCopy','doubleEnemy']);
AN.Game = Game; AN.CONST={HAND_MAX,FIELD_MAX,LIFE,HAND_START,ENERGY_MAX,DECK_SIZE};
if(typeof module!=='undefined') module.exports = AN;
})();
