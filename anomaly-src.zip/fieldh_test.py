# 場が空でもカードがあっても、場の高さが変わらないことを確認する（画面の高さ3通り）
import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        for w,h in [(390,844),(390,700),(360,640)]:
            pg=await b.new_page(viewport={'width':w,'height':h})
            await pg.goto('file:///home/claude/anomaly/index.html'); await pg.wait_for_timeout(300)
            await pg.click('#btnNew'); await pg.fill('#seed','fh'); await pg.click('#go'); await pg.wait_for_timeout(300)
            await pg.click('#auto'); await pg.wait_for_timeout(200); await pg.click('#go'); await pg.wait_for_timeout(800)
            if await pg.query_selector('#mgo'): await pg.click('#mgo'); await pg.wait_for_timeout(500)
            r=await pg.evaluate("""()=>{ const g=__g(); const hs=()=>[...document.querySelectorAll('#battle .field')].map(f=>Math.round(f.getBoundingClientRect().height));
              const out={}; const saved=g.players.map(p=>p.field); out.empty=(g.players.forEach(p=>p.field=[]),__rb(),hs());
              const cr=g.mkCr(g.inst(AN.CARDS[0])); g.players.forEach(p=>p.field=[cr]); __rb(); out.one=hs(); g.players.forEach(p=>p.field=Array.from({length:7},()=>g.mkCr(g.inst(AN.CARDS[3])))); __rb(); out.seven=hs();
              g.players.forEach((p,i)=>p.field=saved[i]); __rb(); return out; }""")
            print(w,h,r); await pg.close()
        await b.close()
asyncio.run(main())
