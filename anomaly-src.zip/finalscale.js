// プレイヤー役：強CPU＋冒険終盤を想定した2色デッキ（コモン〜レア＋秘宝1〜2枚）。最終ボス：現行の構成でライフ・エナジーを変える
const AN=require('./ai.js'); const D=AN.CARD_BY_ID;
function playerDeck(rng, extra){
  const [a,b]=rng.shuffle(AN.ATTR_ORDER);
  const rars = extra>=9 ? ['C','U','R','L'] : ['C','U','R'];
  let pool=[]; AN.CARDS.forEach(d=>{ if((d.attr.includes(a)||d.attr.includes(b)||!d.attr.length) && rars.includes(d.rarity)) pool.push(d); });
  pool=rng.shuffle(pool).slice(0, extra>=9?999:40+extra*8);
  if(extra>=9){ pool.push(AN.makeLegend(rng,3000),AN.makeLegend(rng,3003),AN.makeLegend(rng,3006)); }
  const tr=rng.shuffle(AN.TREASURES.slice()).slice(0, extra>=9?5:2+Math.min(extra,2));
  const deck=AN.AI.autoDeck(pool.concat(tr), rng, a).slice(0,30-tr.length).concat(tr);
  return {deck, main:a};
}
function bossDeck(rng, seals, xl, nb){
  const A1=nb?'ray':'flare';
  let pool=[]; AN.CARDS.forEach(d=>{ if(d.attr.includes('void')||d.attr.includes(A1)||d.attr.length===0){ const k=d.rarity==='L'?1:2; for(let i=0;i<k;i++) pool.push(d); } });
  const vals=d=>AN.cardValue(d)/Math.max(1,d.cost)*(d.cost<=4?1.15:1)+rng()*0.4; pool.sort((x,y)=>vals(y)-vals(x));
  const an=[AN.makeLegend(rng,1500),AN.makeAnomaly(rng,1504,null),AN.makeAnomaly(rng,1505,null)].slice(0, Math.max(0,3-seals)); for(let k=0;k<(xl||0);k++) an.push(AN.makeLegend(rng,1600+k*3));
  const commons=AN.CARDS.filter(d=>(d.attr.includes('void')||d.attr.includes(A1))&&d.rarity==='C');
  const rest=pool.slice(12, 12+(30-an.length)-seals*3).concat(Array.from({length:seals*3},()=>rng.pick(commons)));
  return an.concat(rest);
}
const cfgs=JSON.parse(process.env.CFG);
for(const c of cfgs){ let w=0,N=250;
  for(let i=0;i<N;i++){ const rng=AN.makeRng('fsc'+i); const P=playerDeck(rng,c.extra); const B=bossDeck(rng, c.seals||0, c.xl||0, c.nb);
    const g=new AN.Game({seed:'f'+i,decks:[P.deck,B],names:['P','Z'],mains:[P.main,c.nb?'ray':'void'],choosers:[AN.AI.chooser(3),AN.AI.chooser(3)],lifes:[0,c.life],energyBonus:[0,c.energy],sideBuff:[null,c.buff||null],bossRules:[null, c.nb ? Object.assign({mirror:c.m||0}, c.ph?{phase:15,phaseLeader:'judge'}:{}) : ((c.seals||0)>=6?null:((c.seals||0)>=4?{devour:true}:{devour:true,phase:15}))]});
    let s=0; while(g.winner==null&&s++<5000) AN.AI.step(g,3); if(g.winner===0) w++; }
  console.log(c.label.padEnd(26,'　'), 'プレイヤー役の勝率', Math.round(w/N*100)+'%'); }
