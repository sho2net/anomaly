# 効果音・エフェクトの確認：対戦を進めながら、鳴った音の種類とエフェクト要素の出現を数え、攻撃直後の画面を撮る
import asyncio, collections
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
        pg=await b.new_page(viewport={'width':390,'height':780}, device_scale_factor=2)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/anomaly/index.html'); await pg.wait_for_timeout(400)
        await pg.evaluate("""()=>{ window.__sfxlog=[]; window.__fx=collections={};
          new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(n=>{ if(n.className&&typeof n.className==='string'){ const k=n.className.split(' ')[0]; window.__fx[k]=(window.__fx[k]||0)+1; } }))).observe(document.body,{childList:true,subtree:true}); }""")
        await pg.click('#btnNew'); await pg.fill('#seed','fx1'); await pg.click('#go'); await pg.wait_for_timeout(300)
        await pg.click('#auto'); await pg.wait_for_timeout(200); await pg.click('#go'); await pg.wait_for_timeout(1200)
        mg=await pg.query_selector('#mgo')
        if mg: await mg.click(); await pg.wait_for_timeout(600)
        shot=0
        for turn in range(40):
            if await pg.query_selector('#result'): break
            picks=await pg.query_selector_all('.overlay #picks .card')
            if picks: await picks[0].click(); await pg.wait_for_timeout(300); continue
            if not await pg.evaluate("()=>{const b=document.querySelector('#endTurn');return !!b&&!b.disabled}"): await pg.wait_for_timeout(700); continue
            for _ in range(6):
                played=False
                for c in await pg.query_selector_all('.hand .card:not(.dim)'):
                    await c.click(); await pg.wait_for_timeout(120)
                    pb=await pg.query_selector('#bigbtns button.primary:not(:disabled)')
                    if pb: await pb.click(); played=True; await pg.wait_for_timeout(350); break
                    await pg.click('#bigbtns button.ghost'); await pg.wait_for_timeout(80)
                picks=await pg.query_selector_all('.overlay #picks .card')
                if picks: await picks[0].click(); await pg.wait_for_timeout(300)
                while await pg.query_selector('.reveal'): await pg.click('.reveal'); await pg.wait_for_timeout(350)
                if not played: break
            for _ in range(6):
                r=await pg.query_selector('#battle .field .card.ready')
                if not r: break
                await r.click(); await pg.wait_for_timeout(120)
                tg=await pg.query_selector('#battle .card.target') or await pg.query_selector('.life.target')
                if not tg: break
                await tg.click()
                if shot<4:
                    await pg.wait_for_timeout(230); await pg.screenshot(path=f'fx_atk{shot}.png'); shot+=1
                await pg.wait_for_timeout(700)
                while await pg.query_selector('.reveal'): await pg.click('.reveal'); await pg.wait_for_timeout(350)
            await pg.evaluate("()=>{const b=document.querySelector('#endTurn');if(b&&!b.disabled)b.click()}")
            await pg.wait_for_timeout(1500)
            while await pg.query_selector('.reveal'): await pg.click('.reveal'); await pg.wait_for_timeout(350)
        log=await pg.evaluate('window.__sfxlog'); fx=await pg.evaluate('window.__fx')
        print('sounds', dict(collections.Counter(log)))
        print('fx', {k:v for k,v in fx.items() if k.startswith('fx')})
        print('result' if await pg.query_selector('#result') else 'not finished', 'turns', turn)
        print('errors', errs[:5] if errs else 'no errors')
        await b.close()
asyncio.run(main())
