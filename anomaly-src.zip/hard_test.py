# 冒険ハードの通し確認：難易度の選択、敵の強化、最終ボスの周回による強化、制覇の記録
import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={'width':390,'height':800})
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/anomaly/index.html'); await pg.wait_for_timeout(300)
        await pg.evaluate("localStorage.clear()")
        await pg.reload(); await pg.wait_for_timeout(300)
        for loop in [1,2,3]:
            await pg.click('#btnAdv'); await pg.wait_for_timeout(200)
            await pg.click('#segD button[data-v="1"]'); await pg.wait_for_timeout(100)
            if loop==1: await pg.screenshot(path='hard_start.png')
            await pg.click('.advcolors button[data-c="flare"]'); await pg.wait_for_timeout(200)
            if await pg.query_selector('#cfYes'): await pg.click('#cfYes'); await pg.wait_for_timeout(200)
            r=await pg.evaluate("__adv.run().hard"); print('loop start', loop, '→ advRun.hard', r)
            # 戦闘ノードへ
            await pg.click('.advnodes button:has-text("戦闘")'); await pg.wait_for_timeout(200)
            if loop==1: await pg.screenshot(path='hard_ante.png')
            await pg.click('#fight'); await pg.wait_for_timeout(600)
            g=await pg.evaluate("(()=>{const g=__g(); return {life:g.players[1].life, lv:null, buff:g.sideBuff, en:g.players[1].energyMax}})()")
            print('  area1 battle', g)
            # 最終ボスへ飛ぶ
            await pg.evaluate("(()=>{ const r=__adv.run(); r.areaIdx=r.areas.length; r.floor=0; r.choices=['final','continue']; r.bossWins=3+6; r.pending=null; r.stage='map'; __adv.save(); __adv.show('advMap'); })()")
            await pg.wait_for_timeout(200)
            await pg.click('.advnodes button:has-text("歪みの果て")'); await pg.wait_for_timeout(200)
            await pg.click('#fight'); await pg.wait_for_timeout(600)
            g=await pg.evaluate("(()=>{const g=__g(); return {name:g.players[1].name, life:g.players[1].life, buff:g.sideBuff, energyBonusMax:g.players[1].energyMax, deck:g.players[1].deck.length+g.players[1].hand.length, rules:g.players[1].bossRules}})()")
            print('  final (seals 6)', g)
            await pg.evaluate("(()=>{ const g=__g(); g.phase='main'; g.winner=0; __rb(); })()"); await pg.wait_for_timeout(1500)
            txt=await pg.evaluate("document.querySelector('#advEnd')?document.querySelector('#advEnd').innerText.replace(/\\n/g,' | '):'no end'")
            print('  end:', txt[:140])
            await pg.click('#home'); await pg.wait_for_timeout(200)
        print('record', await pg.evaluate("localStorage.getItem('anomaly_adv_record_v1')"))
        print('errors', errs or 'none')
        await b.close()
asyncio.run(main())
