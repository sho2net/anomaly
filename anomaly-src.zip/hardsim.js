// 冒険ハードの難しさの確認。強CPUをプレイヤー役にして、ノーマルとハードで勝率を比べる
// 使い方：node hardsim.js [試合数]   （HARD=周回数 を変えて最終ボスの強さも見る）
const AN=require('./ai.js');
const N=+process.argv[2]||200;
function starter(rng,color){ const pc=AN.CARDS.filter(d=>d.attr.includes(color)&&d.rarity==='C'), pu=AN.CARDS.filter(d=>d.attr.includes(color)&&d.rarity==='U'), nc=AN.CARDS.filter(d=>!d.attr.length&&d.rarity==='C');
  const col=[]; for(let k=0;k<18;k++) col.push(rng.pick(pc)); for(let k=0;k<4;k++) col.push(rng.pick(pu)); for(let k=0;k<10;k++) col.push(rng.pick(nc)); col.push(AN.makeAnomaly(rng,1,null),AN.makeAnomaly(rng,2,null)); return AN.AI.autoDeck(col,rng,color); }
// adv_ui.js の advHardMods と同じ規則
const V=process.env.V||'b';
function mods(hard, kind, areaIdx, floor){
  if(!hard) return {buff:null, energy:0, life:0, level:null};
  const big = kind!=='battle';
  if(V==='b') return { buff: big?{atk:0,hp:1}:null, energy:0, life:2, level:3 };
  if(V==='c') return { buff: big?{atk:0,hp:1}:null, energy: big?1:0, life:2, level:3 };
  if(V==='d') return { buff: {atk:0,hp:1}, energy:0, life:2, level:3 };
  return { buff: big?{atk:1,hp:1}:{atk:0,hp:1}, energy: (big||areaIdx>0)?1:0, life:3, level: 3 };
}
function area1(rng,a,kind,floor){
  const cc=AN.CARDS.filter(d=>d.attr.includes(a)&&d.rarity==='C'), cu=AN.CARDS.filter(d=>d.attr.includes(a)&&d.rarity==='U'), nc=AN.CARDS.filter(d=>!d.attr.length&&d.rarity==='C');
  const nu = kind==='elite'?4:(kind==='boss'?3:Math.round(2*Math.min(1,floor/5)));
  const col=[]; for(let k=0;k<30-nu-8;k++) col.push(rng.pick(cc)); for(let k=0;k<nu;k++) col.push(rng.pick(cu)); for(let k=0;k<8;k++) col.push(rng.pick(nc));
  if(kind==='elite') col[0]=AN.makeAnomaly(rng,701,null);
  return {deck:col, life: kind==='battle'?16+Math.floor(floor/2):20, level: kind==='battle'?(floor<=2?1:2):(kind==='boss'?3:2)};
}
const AREA={flare:'inferno',tide:'boss_tide',grow:'bloom',ray:'boss_ray',void:'boss_void'};
function fightArea1(hard,kind,floor){
  let w=0;
  for(let i=0;i<N;i++){
    const rng=AN.makeRng('h'+kind+floor+'_'+i); const [me,a]=rng.shuffle(AN.ATTR_ORDER);
    const my=starter(rng,me), en=area1(rng,a,kind,floor), m=mods(hard,kind,0,floor);
    const lv=m.level||en.level;
    const g=new AN.Game({seed:'e'+i,decks:[my,en.deck],names:['P','E'],mains:[me,a],choosers:[AN.AI.chooser(3),AN.AI.chooser(lv)],lifes:[0,en.life+m.life],leaders:[null,kind==='boss'?AREA[a]:null],energyBonus:[0,m.energy],sideBuff:[null,m.buff]});
    let s=0; while(g.winner==null&&s++<5000) AN.AI.step(g,[3,lv][g.active]); if(g.winner===0) w++;
  }
  return Math.round(w/N*100);
}
for(const [kind,floor] of [['battle',0],['battle',2],['battle',4],['elite',2],['boss',5]]){
  console.log('地域1', kind, (floor+1)+'階', 'ノーマル', fightArea1(0,kind,floor)+'%', 'ハード', fightArea1(1,kind,floor)+'%');
}
