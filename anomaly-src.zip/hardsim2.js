// 冒険ハード：2〜3地域目の敵と最終ボス。プレイヤー役＝強CPU＋旅の途中を想定した2色デッキ
const AN=require('./ai.js');
const N=+process.argv[2]||150;
function playerDeck(rng, stage){ // stage 1=2地域目, 2=3地域目, 3=最終前
  const [a,b]=rng.shuffle(AN.ATTR_ORDER); const rars= stage>=2?['C','U','R']:['C','U'];
  let pool=[]; AN.CARDS.forEach(d=>{ if((d.attr.includes(a)||d.attr.includes(b)||!d.attr.length)&&rars.includes(d.rarity)) pool.push(d); });
  pool=rng.shuffle(pool).slice(0,36+stage*6);
  const tr=rng.shuffle(AN.TREASURES.slice()).slice(0,stage);
  if(stage>=2) pool.push(AN.makeLegend(rng,3000));
  return {deck:AN.AI.autoDeck(pool.concat(tr),rng,a).slice(0,30-tr.length).concat(tr), main:a};
}
const AREA={flare:'inferno',tide:'boss_tide',grow:'bloom',ray:'boss_ray',void:'boss_void'};
function enemy(rng,a,kind,ai){
  const tiers={battle:[['C'],['C','U'],['C','U','R']], elite:[['C','U'],['C','U','R'],['C','U','R','L']], boss:[['C'],['C','U'],['C','U','R']]}[kind][ai];
  let pool=[]; AN.CARDS.forEach(d=>{ if((d.attr.includes(a)||!d.attr.length)&&tiers.includes(d.rarity)) pool.push(d); });
  pool=rng.shuffle(pool.concat(pool)).slice(0,50);
  const nAn=kind==='elite'?1:(ai>=1?1:0); for(let i=0;i<nAn;i++) pool.unshift(AN.makeAnomaly(rng,701+i*3,null));
  const deck=AN.AI.autoDeck(pool,rng,a); while(deck.length<30) deck.push(rng.pick(pool));
  return {deck, life:(kind==='elite'?25+ai*3:20+ai*3), level: kind==='battle'&&ai===0?2:3};
}
const HV=process.env.HV||'x';
function mods(hard,kind){ if(!hard) return {buff:null,energy:0,life:0};
  const big=kind!=='battle';
  if(HV==='x') return {buff: big?{atk:1,hp:1}:{atk:0,hp:1}, energy:0, life:3};
  if(HV==='y') return {buff: {atk:0,hp:1}, energy: big?1:0, life:3};
  return {buff: big?{atk:0,hp:1}:null, energy:0, life:3};
}
function run(hard,kind,ai){ let w=0; for(let i=0;i<N;i++){ const rng=AN.makeRng('m'+kind+ai+'_'+i); const [a]=rng.shuffle(AN.ATTR_ORDER);
  const P=playerDeck(rng,ai), en=enemy(rng,a,kind,(hard&&process.env.TIER)?Math.min(2,ai+1):ai), m=mods(hard,kind);
  const g=new AN.Game({seed:'m'+i,decks:[P.deck,en.deck],names:['P','E'],mains:[P.main,a],choosers:[AN.AI.chooser(3),AN.AI.chooser(3)],lifes:[0,en.life+m.life],leaders:[null,kind==='boss'?AREA[a]:null],energyBonus:[0,m.energy],sideBuff:[null,m.buff],fieldBuff:kind==='elite'?{attr:a,n:1}:null});
  let s=0; while(g.winner==null&&s++<5000) AN.AI.step(g,3); if(g.winner===0) w++; } return Math.round(w/N*100); }
for(const ai of [1,2]) for(const kind of ['battle','elite','boss']) console.log('地域'+(ai+1), kind, 'ノーマル', run(0,kind,ai)+'%', 'ハード', run(1,kind,ai)+'%');
