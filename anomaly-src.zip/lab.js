// ===== ANOMALY lab.js ===== 効果音・エフェクトの試聴ページ（build.py が lab.html を作る。ゲーム本体には入らない）
(function(){
const app=document.getElementById('app');
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const pick=id=>AN.CARD_BY_ID[id];
let uid=100;
const state={ op:[pick('F16'),pick('R09'),pick('V05')], me:[pick('G06'),pick('T11'),pick('R19')], hand:[pick('F08'),pick('G29'),pick('V23'),pick('T31')], life:[25,25] };
state.op=state.op.map(d=>({d,u:++uid})); state.me=state.me.map(d=>({d,u:++uid})); state.hand=state.hand.map(d=>({d,u:++uid}));
function cardEl(d, zone, u){
  const el=document.createElement('div'); const a=d.attr.length?d.attr[0]:'none';
  el.className='card '+(d.anomaly?'anom':'a-'+a);
  el.innerHTML='<div class="art">'+AN.iconSvg(d)+'</div><div class="cost">'+d.cost+'</div><div class="rar">'+d.rarity+'</div><div class="name">'+esc(d.name)+'</div>'+(d.type==='creature'?'<div class="atk">'+d.power+'</div><div class="power">'+d.hp+'</div>':'<div class="type">スペル</div>');
  el.dataset.uid=u; el.dataset.zone=zone; el.dataset.attr=d.anomaly?'anom':a; return el;
}
function render(){
  app.innerHTML='';
  const s=document.createElement('div'); s.className='screen on'; s.id='battle'; s.style.cssText='height:auto;flex:0 0 auto;overflow:visible';
  const pbar=i=>'<div class="pbar"><div class="life" id="life'+i+'">'+state.life[i]+'</div><div class="nm">'+(i?'相手':'あなた')+'</div></div>';
  s.innerHTML=pbar(1);
  const f=(list,mine)=>{ const x=document.createElement('div'); x.className='field'; list.forEach(c=>x.appendChild(cardEl(c.d,'field',c.u))); return x; };
  s.appendChild(f(state.op,false));
  const mid=document.createElement('div'); mid.className='mid'; mid.innerHTML='<div class="logline">試聴ページ：下のボタンで音と演出を個別に確認できます</div><button class="ghost helpbtn" id="snd"></button>'; s.appendChild(mid);
  s.appendChild(f(state.me,true));
  s.insertAdjacentHTML('beforeend', pbar(0));
  const h=document.createElement('div'); h.className='hand fan'; h.style.height='112px';
  const n=state.hand.length; state.hand.forEach((c,i)=>{ const el=cardEl(c.d,'hand',c.u); const k=i-(n-1)/2; el.style.left='calc(50% - 37px + '+(k*62)+'px)'; el.style.bottom=(8-k*k)+'px'; el.style.transform='rotate('+(k*5)+'deg)'; h.appendChild(el); });
  s.appendChild(h);
  app.appendChild(s);
  const ctl=document.createElement('div'); ctl.className='scroll wrap'; ctl.innerHTML=CTL; app.appendChild(ctl);
  const sb=s.querySelector('#snd'); const upd=()=>{ sb.textContent=AN.SFX.isMuted()?'音：オフ':'音：オン'; }; upd(); sb.onclick=()=>{ AN.SFX.setMuted(!AN.SFX.isMuted()); upd(); };
  ctl.querySelectorAll('button[data-a]').forEach(b=>b.onclick=()=>ACT[b.dataset.a](b.dataset.v));
}
const G={winner:null};
function fire(evs, mutate){
  const root=document.getElementById('battle'); const prev=AN.FX.snapshot(root);
  if(mutate){ mutate(); render(); }
  AN.FX.run(prev, document.getElementById('battle'), evs, G, 0);
}
const ATTRS=['flare','tide','grow','ray','void','none'];
const SAMPLE={flare:'F27',tide:'T29',grow:'G28',ray:'R27',void:'V26',none:'N15'};
const SPELL={flare:'F08',tide:'T13',grow:'G19',ray:'R26',void:'V23',none:'N10'};
const at=(list,i)=>list[Math.min(i,list.length-1)];
const ACT={
  atkCr(){ fire([{type:'attack',p:0,uid:at(state.me,0).u,target:at(state.op,1).u},{type:'battle'},{type:'dmg',uid:at(state.op,1).u,n:3},{type:'dmg',uid:at(state.me,0).u,n:2}]); },
  atkFace(v){ const n=+v; fire([{type:'attack',p:0,uid:at(state.me,2).u,target:'player'},{type:'hit'},{type:'life',p:1,n:-n}]); },
  hurtMe(v){ const n=+v; fire([{type:'attack',p:1,uid:at(state.op,0).u,target:'player'},{type:'life',p:0,n:-n}]); },
  kill(){ if(state.op.length<2) return; const c=at(state.op,2); fire([{type:'attack',p:0,uid:at(state.me,1).u,target:c.u},{type:'dmg',uid:c.u,n:4},{type:'destroy',p:1,uid:c.u}], ()=>{ state.op.splice(state.op.indexOf(c),1); });
    setTimeout(()=>{ state.op.push({d:pick('V05'),u:++uid}); render(); }, 2200); },
  killSpell(){ if(state.op.length<2) return; const c=state.op[0]; fire([{type:'play',p:0,uid:++uid,d:pick('V23')},{type:'destroy',p:1,uid:c.u}], ()=>{ state.op.splice(0,1); });
    setTimeout(()=>{ state.op.unshift({d:pick('F16'),u:++uid}); render(); }, 2400); },
  summon(a){ const d=pick(SAMPLE[a]); const c={d,u:++uid}; state.hand.push(c); render(); setTimeout(()=>{ fire([{type:'play',p:0,uid:c.u,d}], ()=>{ state.hand.pop(); if(state.me.length>=4) state.me.pop(); state.me.push(c); }); },60); },
  summonOp(a){ const d=pick(SAMPLE[a]); const c={d,u:++uid}; fire([{type:'play',p:1,uid:c.u,d}], ()=>{ if(state.op.length>=4) state.op.pop(); state.op.push(c); }); },
  spell(a){ fire([{type:'play',p:0,uid:++uid,d:pick(SPELL[a])}]); },
  relic(){ fire([{type:'play',p:0,uid:++uid,d:pick('R53')}]); },
  heal(){ fire([{type:'life',p:0,n:4}]); },
  armor(){ fire([{type:'attack',p:1,uid:at(state.op,0).u,target:at(state.me,2).u},{type:'armor',uid:at(state.me,2).u}]); },
  bounce(){ if(state.op.length<2) return; const c=state.op[1]; fire([{type:'play',p:0,uid:++uid,d:pick('T06')},{type:'bounce',p:1,uid:c.u}], ()=>{ state.op.splice(state.op.indexOf(c),1); }); setTimeout(()=>{ state.op.splice(1,0,{d:pick('R09'),u:++uid}); render(); },2000); },
  turn(v){ fire([{type:'turn',p:v==='me'?0:1}]); },
  trap(){ fire([{type:'trap',p:1,d:pick('F53')}]); },
  anom(v){ AN.SFX.play('anomaly', v==='legend'); },
  boss(){ fire([{type:'bossphase',p:1}]); },
  snd(n){ AN.SFX.play(n, n==='play'||n==='spell'?'flare':(n==='hit'||n==='face'?4:null), 0); },
  win(){ AN.SFX.play('win'); }, lose(){ AN.SFX.play('lose'); },
};
const btn=(a,v,l,cls)=>'<button class="'+(cls||'')+'" data-a="'+a+'"'+(v!=null?' data-v="'+v+'"':'')+'>'+l+'</button>';
const row=(h,b)=>'<div class="field-label">'+h+'</div><div class="labrow">'+b+'</div>';
const CTL='<div class="sub" style="line-height:1.7">最初にどれかのボタンを押すと音が出るようになります。スマホはマナーモードを解除してください。</div>'
 +row('攻撃', btn('atkCr',null,'クリーチャーに攻撃','primary')+btn('atkFace',2,'相手に2ダメージ')+btn('atkFace',7,'相手に7ダメージ')+btn('hurtMe',3,'自分が3ダメージ')+btn('hurtMe',8,'自分が8ダメージ'))
 +row('破壊・除去', btn('kill',null,'戦闘で破壊','primary')+btn('killSpell',null,'スペルで破壊')+btn('bounce',null,'手札に戻す')+btn('armor',null,'装甲で防ぐ'))
 +row('召喚（自分）', ATTRS.map(a=>btn('summon',a,AN.ATTRS[a].n)).join(''))
 +row('召喚（相手）', ATTRS.map(a=>btn('summonOp',a,AN.ATTRS[a].n)).join(''))
 +row('スペル', ATTRS.map(a=>btn('spell',a,AN.ATTRS[a].n)).join('')+btn('relic',null,'置物'))
 +row('そのほか', btn('heal',null,'回復')+btn('turn','me','自分のターン')+btn('turn','op','相手のターン')+btn('trap',null,'罠発動')+btn('anom','n','アノマリー')+btn('anom','legend','伝説のアノマリー')+btn('boss',null,'ボス覚醒')+btn('snd','mirror','写し身')+btn('win',null,'勝利')+btn('lose',null,'敗北'));
const st=document.createElement('style'); st.textContent='.labrow{display:flex;flex-wrap:wrap;gap:6px}.labrow button{padding:8px 12px;font-size:13px}#app{overflow-y:auto}';
document.head.appendChild(st);
render();
})();
