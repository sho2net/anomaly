import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
        pg=await b.new_page(viewport={'width':390,'height':800}, device_scale_factor=2)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: m.type=='error' and errs.append(m.text))
        await pg.goto('file:///home/claude/anomaly/lab.html'); await pg.wait_for_timeout(400)
        await pg.evaluate("window.__sfxlog=[]")
        shots=[('atkCr',None,[250,330,480]),('atkFace','7',[300,420]),('kill',None,[330,520,700]),('summon','ray',[120,330,520]),('spell','void',[250,500]),('hurtMe','8',[300,400]),('turn','me',[250])]
        for a,v,ts in shots:
            sel='button[data-a="%s"]'%a+('[data-v="%s"]'%v if v else '')
            await pg.click(sel); t0=0
            for t in ts:
                await pg.wait_for_timeout(t-t0); t0=t
                await pg.screenshot(path='lab_%s_%s_%d.png'%(a,v,t))
            await pg.wait_for_timeout(2500)
        n=len(await pg.query_selector_all('button[data-a]'))
        for i in range(n):
            await pg.evaluate("i=>document.querySelectorAll('button[data-a]')[i].click()", i); await pg.wait_for_timeout(700)
        await pg.wait_for_timeout(2500)
        print('sounds', sorted(set(await pg.evaluate('window.__sfxlog'))))
        print('errors', errs or 'no errors')
        await b.close()
asyncio.run(main())
