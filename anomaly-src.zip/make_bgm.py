# 曲の差し替え・追加：python3 make_bgm.py <key> <Sunoのmp3>
#  - 末尾の無音（150ms以内）を落とし、前後に「曲の終わり1秒」「曲の始まり1秒」をつなぎ足して bgm/<key>.mp3（128kbps）を作る
#  - 曲の長さと、音量を -18 LUFS にそろえる倍率を bgm/tracks.json に書く（build.py が fx.js に埋め込む）
#  - key は title/map/battle/boss/final/judge/tavern（新しい key を足したら ui.js の bgmKeyFor にも場面を足す）
import sys, json, subprocess, wave, os, re, numpy as np
key, src = sys.argv[1], sys.argv[2]
os.makedirs('bgm', exist_ok=True); tmp='/tmp/_bgm_'+key
subprocess.run(['ffmpeg','-v','error','-y','-i',src,'-ac','2','-ar','48000','-c:a','pcm_s16le',tmp+'.wav'],check=True)
w=wave.open(tmp+'.wav'); sr=w.getframerate(); x=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).reshape(-1,2)
a=np.abs(x.astype(int)).max(1); t=len(x)-(len(x)-np.argmax(a[::-1]>100))
if 0<t<=int(0.15*sr): x=x[:len(x)-t]
p=sr; y=np.concatenate([x[-p:],x,x[:p]])
o=wave.open(tmp+'_pad.wav','wb'); o.setnchannels(2); o.setsampwidth(2); o.setframerate(sr); o.writeframes(y.tobytes()); o.close()
subprocess.run(['ffmpeg','-v','error','-y','-i',tmp+'_pad.wav','-c:a','libmp3lame','-b:a','128k','bgm/'+key+'.mp3'],check=True)
r=subprocess.run(['ffmpeg','-nostats','-i',tmp+'.wav','-af','ebur128','-f','null','-'],capture_output=True,text=True).stderr
lufs=float(re.findall(r'I:\s+(-?[\d.]+) LUFS',r)[-1])
T=json.load(open('bgm/tracks.json')) if os.path.exists('bgm/tracks.json') else {}
T[key]={'len':round(len(x)/sr,5),'gain':round(10**((-18-lufs)/20),3)}
json.dump(T,open('bgm/tracks.json','w'),ensure_ascii=False,indent=1)
print(key, T[key], 'LUFS', lufs)
