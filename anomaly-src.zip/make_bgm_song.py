# 長い曲（Suno の Song）をループ用に加工する：python3 make_bgm_song.py <key> <mp3> [--group battle] [--a 秒 --b 秒]
#  - ループ点 a→b を自動で探す（拍の頭で、前後8拍の和音・音色・音量が最も似ている所。a は曲の前半3割、b は8割以降かつフェードアウト前）
#  - 0〜b の手前0.5秒まではそのまま、b直前の0.5秒は「bへ向かう音」と「aへ向かう音」を等パワーで重ね、b以降に a からの続き0.5秒を付ける
#    → 再生は 0 から始め、[a, b] をループ。ブラウザが mp3 の頭に無音を足してずれても、継ぎ目の前後は実際の音でつながっている
#  - 音量は -18 LUFS にそろえる倍率を gain に。bgm/tracks.json に {start, loopStart, loopEnd, flen, gain, group} を書く
import sys, json, subprocess, wave, os, re, numpy as np
args=sys.argv[1:]; key, src = args[0], args[1]
opt=dict(zip(args[2::2],args[3::2])); group=opt.get('--group',key)
tmp='/tmp/_song_'+key
subprocess.run(['ffmpeg','-v','error','-y','-i',src,'-ac','2','-ar','48000','-c:a','pcm_s16le',tmp+'.wav'],check=True)
if '--a' in opt: a,b=float(opt['--a']),float(opt['--b'])
else:
    out=subprocess.run(['python3',os.path.join(os.path.dirname(os.path.abspath(__file__)),'tools_loopfind.py'),tmp+'.wav','0.3','0.8'],capture_output=True,text=True).stdout
    m=re.search(r'score=([\d.]+)\s+([\d.]+)s -> ([\d.]+)s',out); a,b=float(m.group(2)),float(m.group(3)); print(out.strip().splitlines()[1])
w=wave.open(tmp+'.wav'); sr=w.getframerate(); x=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).reshape(-1,2).astype(np.float32)
A,B=int(a*sr),int(b*sr); C=int(0.5*sr); P=int(0.5*sr)
t=np.linspace(0,np.pi/2,C)[:,None]
blend=x[B-C:B]*np.cos(t)+x[A-C:A]*np.sin(t)
y=np.concatenate([x[:B-C],blend,x[A:A+P]]).clip(-32768,32767).astype(np.int16)
o=wave.open(tmp+'_loop.wav','wb'); o.setnchannels(2); o.setsampwidth(2); o.setframerate(sr); o.writeframes(y.tobytes()); o.close()
os.makedirs('bgm',exist_ok=True)
subprocess.run(['ffmpeg','-v','error','-y','-i',tmp+'_loop.wav','-c:a','libmp3lame','-b:a','128k','bgm/'+key+'.mp3'],check=True)
r=subprocess.run(['ffmpeg','-nostats','-i',tmp+'.wav','-af','ebur128','-f','null','-'],capture_output=True,text=True).stderr
lufs=float(re.findall(r'I:\s+(-?[\d.]+) LUFS',r)[-1])
T=json.load(open('bgm/tracks.json')) if os.path.exists('bgm/tracks.json') else {}
T[key]={'start':0,'loopStart':round(a,4),'loopEnd':round(b,4),'flen':round(len(y)/sr,4),'gain':round(10**((-18-lufs)/20),3),'group':group}
json.dump(T,open('bgm/tracks.json','w'),ensure_ascii=False,indent=1)
print(key, T[key], 'LUFS', lufs)
