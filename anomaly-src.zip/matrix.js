const AN=require('./ai.js');
if(process.env.ABIL){ const o=AN.Game.prototype.endTurn; AN.Game.prototype.endTurn=function(){ const p=this.players[this.active]; while(this.canUseAbility(p)) { if(!this.useAbility(p)) break; if(this.pending) break; } return o.call(this); }; }
const A=AN.ATTR_ORDER, M={}, T={}; let N=parseInt(process.env.N||'1200'), turns={};
for(let i=0;i<N;i++){
  const rng=AN.makeRng('pool'+i);
  const pools=[0,1].map(k=>{ const p=AN.drawPool(rng,87,null); for(let j=0;j<3;j++) p.unshift(AN.makeAnomaly(rng,k*3+j,null)); return p; });
  const mains=pools.map(p=>AN.AI.bestMain(p)); if(mains[0]===mains[1]) continue;
  const decks=pools.map((p,k)=>AN.AI.autoDeck(p,rng,mains[k]));
  const g=new AN.Game({seed:'g'+i,decks,names:['A','B'],mains,choosers:[AN.AI.chooser(3),AN.AI.chooser(3)]});
  let s=0; while(g.winner==null&&s++<4000) AN.AI.step(g,3);
  if(g.winner==null) continue;
  const w=mains[g.winner], l=mains[1-g.winner];
  M[w+'>'+l]=(M[w+'>'+l]||0)+1;
  mains.forEach(m=>{ turns[m]=turns[m]||[0,0]; turns[m][0]+=g.turn; turns[m][1]++; });
}
const nm={flare:'炎',tide:'水',grow:'森',ray:'光',void:'闇'};
console.log((process.env.ABIL?'[能力を毎ターン使う] ':'[通常] ')+'行=自分 列=相手 の勝率');
console.log('   '+A.map(a=>nm[a]).join('   '));
A.forEach(a=>{ console.log(nm[a]+' '+A.map(b=>{ if(a===b) return ' -- '; const w=M[a+'>'+b]||0, l=M[b+'>'+a]||0; return (w+l? String(Math.round(w/(w+l)*100)).padStart(3)+'%':'  ? '); }).join(' ')); });
console.log('平均手番: '+A.map(a=>nm[a]+(turns[a][0]/turns[a][1]).toFixed(1)).join(' '));
