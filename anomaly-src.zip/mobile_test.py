import asyncio, sys
from playwright.async_api import async_playwright
async def run(pg, w, h, tag):
    await pg.set_viewport_size({'width':w,'height':h})
    await pg.goto('file:///home/claude/anomaly/index.html'); await pg.wait_for_timeout(300)
    await pg.evaluate("localStorage.clear()"); await pg.reload(); await pg.wait_for_timeout(300)
    await pg.click('#btnAdv'); await pg.click('.advcolors button[data-c="void"]'); await pg.wait_for_timeout(300)
    await pg.evaluate("()=>{ const r=JSON.parse(localStorage.getItem('anomaly_adv_v1')); r.areaIdx=3; r.floor=0; r.choices=null; localStorage.setItem('anomaly_adv_v1',JSON.stringify(r)); }")
    await pg.click('#back'); await pg.click('#btnAdv'); await pg.click('#cont'); await pg.wait_for_timeout(300)
    await pg.click('.advnodes button'); await pg.wait_for_timeout(300); await pg.click('#fight'); await pg.wait_for_timeout(900)
    mg=await pg.query_selector('#mgo')
    if mg: await mg.click()
    await pg.wait_for_timeout(300)
    # give both sides relics/traps + creatures for worst case
    await pg.evaluate("()=>{ const g=window.__g(); [0,1].forEach(i=>{ const p=g.players[i]; ['N50','F52','G53'].forEach(id=>p.relics.push({c:g.inst(AN.CARD_BY_ID[id]),cd:3})); p.traps.push(g.inst(AN.CARD_BY_ID['F53'])); for(let k=0;k<5;k++){ const c=g.mkCr(g.inst(AN.CARD_BY_ID['N03'])); p.field.push(c);} p.energyMax=10; p.energy=10; while(p.hand.length<8) p.hand.push(g.inst(AN.CARD_BY_ID['N01'])); }); window.__rb(); }")
    await pg.wait_for_timeout(300)
    await pg.screenshot(path=f'mob_{tag}.png')
    bb=await pg.evaluate("()=>{ const e=document.querySelector('#endTurn'); const r=e.getBoundingClientRect(); const top=document.elementFromPoint(r.x+r.width/2, r.y+r.height/2); return {bottom:Math.round(r.bottom), vh:window.innerHeight, hit: top===e || e.contains(top), over: top? (top.className||top.tagName)+'/'+(top.parentElement?top.parentElement.className:''):null}; }")
    nm=await pg.evaluate("()=>[...document.querySelectorAll('.pbar')].map(p=>Math.round(p.getBoundingClientRect().height))")
    print(tag, w,'x',h, 'endTurn', bb, 'pbar heights', nm)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(device_scale_factor=2)
        for (w,h,t) in [(360,640,'s'),(390,700,'m'),(414,780,'l')]:
            await run(pg,w,h,t)
        await b.close()
asyncio.run(main())
