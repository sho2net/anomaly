// ===== ANOMALY net.js ===== room/action transport. LocalNet = same browser (tabs) via localStorage+BroadcastChannel. FirebaseNet = Realtime Database.
(function(){
const CODE_CHARS='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function makeCode(){ let s=''; for(let i=0;i<4;i++) s+=CODE_CHARS[Math.floor(Math.random()*CODE_CHARS.length)]; return s; }
function setPath(obj, path, value){ const ks=path.split('/'); let o=obj; for(let i=0;i<ks.length-1;i++){ if(o[ks[i]]==null||typeof o[ks[i]]!=='object') o[ks[i]]={}; o=o[ks[i]]; } o[ks[ks.length-1]]=value; }

// ---------- LocalNet ----------
class LocalNet {
  constructor(){ this.kind='local'; this.key='anom_rooms_v2'; this.bc=('BroadcastChannel' in window)? new BroadcastChannel('anomaly_net') : null; this.watchers=[];
    const onMsg=()=>this.watchers.forEach(w=>w());
    if(this.bc) this.bc.onmessage=onMsg;
    window.addEventListener('storage',e=>{ if(e.key===this.key) onMsg(); });
  }
  _all(){ try{ return JSON.parse(localStorage.getItem(this.key))||{}; }catch(e){ return {}; } }
  _save(all){ localStorage.setItem(this.key, JSON.stringify(all)); if(this.bc) this.bc.postMessage('x'); this.watchers.forEach(w=>w()); }
  async createRoom(data){ const all=this._all(); let code=makeCode(); while(all[code]) code=makeCode(); all[code]=Object.assign({code, games:{}},data); this._save(all); return code; }
  async getRoom(code){ const r=this._all()[code]; return r? JSON.parse(JSON.stringify(r)) : null; }
  async set(code, path, value){ const all=this._all(); if(!all[code]) return; setPath(all[code], path, value); this._save(all); }
  watchRoom(code, cb){ const f=()=>{ const r=this._all()[code]; if(r) cb(JSON.parse(JSON.stringify(r))); }; this.watchers.push(f); f(); return ()=>{ this.watchers=this.watchers.filter(x=>x!==f); }; }
  async pushAction(code, gameNo, a){ const all=this._all(); const r=all[code]; if(!r) return; r.games=r.games||{}; r.games[gameNo]=r.games[gameNo]||{}; r.games[gameNo].actions=r.games[gameNo].actions||[]; r.games[gameNo].actions.push(a); this._save(all); }
  watchActions(code, gameNo, cb){ let seen=0; const f=()=>{ const r=this._all()[code]; const list=(r&&r.games&&r.games[gameNo]&&r.games[gameNo].actions)||[]; while(seen<list.length){ cb(list[seen], seen); seen++; } }; this.watchers.push(f); f(); return ()=>{ this.watchers=this.watchers.filter(x=>x!==f); }; }
}

// ---------- FirebaseNet (compat SDK loaded from gstatic; only works on a normal web host) ----------
class FirebaseNet {
  constructor(cfg){ this.kind='firebase'; if(!firebase.apps.length) firebase.initializeApp(cfg); this.db=firebase.database(); }
  ref(p){ return this.db.ref('rooms/'+p); }
  async createRoom(data){ let code=makeCode(); for(let i=0;i<5;i++){ const snap=await this.ref(code).get(); if(!snap.exists()) break; code=makeCode(); } await this.ref(code).set(Object.assign({code},data)); return code; }
  async getRoom(code){ const snap=await this.ref(code).get(); return snap.exists()? snap.val() : null; }
  async set(code, path, value){ await this.ref(code+'/'+path).set(value); }
  watchRoom(code, cb){ const r=this.ref(code); const h=r.on('value',s=>{ if(s.exists()) cb(s.val()); }); return ()=>r.off('value',h); }
  async pushAction(code, gameNo, a){ await this.ref(code+'/games/'+gameNo+'/actions').push(a); }
  watchActions(code, gameNo, cb){ const r=this.ref(code+'/games/'+gameNo+'/actions'); let i=0; const h=r.on('child_added',s=>{ cb(s.val(), i++); }); return ()=>r.off('child_added',h); }
}

function createNet(cfg){
  if(cfg && cfg.apiKey && typeof firebase!=='undefined' && firebase.database){ try{ return new FirebaseNet(cfg); }catch(e){ console.warn('firebase init failed',e); } }
  return new LocalNet();
}
window.AN_NET={createNet, LocalNet, FirebaseNet, makeCode};
})();
