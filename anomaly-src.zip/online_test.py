import asyncio
from playwright.async_api import async_playwright
async def safe(el):
    try: await el.click(force=True, timeout=1500); return True
    except Exception: return False
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); ctx=await b.new_context(viewport={'width':390,'height':780})
        errs=[]
        A=await ctx.new_page(); B=await ctx.new_page()
        for pg in (A,B): pg.on('pageerror', lambda e: errs.append(str(e)))
        await A.goto('file:///home/claude/anomaly/index.html'); await A.wait_for_timeout(300)
        await A.evaluate('localStorage.clear()'); await A.reload(); await A.wait_for_timeout(300)
        await B.goto('file:///home/claude/anomaly/index.html'); await B.wait_for_timeout(300)
        await A.click('#btnOnline'); await A.fill('#nm','Sho'); await A.click('#create'); await A.wait_for_timeout(400)
        code=(await A.inner_text('.disp')).strip()
        await B.click('#btnOnline'); await B.fill('#nm','Friend'); await B.fill('#code',code); await B.click('#join'); await B.wait_for_timeout(600)
        for pg in (A,B):
            await pg.click('#auto'); await pg.wait_for_timeout(200); await pg.click('#go'); await pg.wait_for_timeout(600)
        await A.wait_for_timeout(1000)
        for pg in (A,B):
            mg=await pg.query_selector('#mgo')
            if mg: await safe(mg); await pg.wait_for_timeout(800)
        for t in range(200):
            if await A.query_selector('#result') and await B.query_selector('#result'): break
            for pg in (A,B):
                btn=await pg.query_selector('#endTurn:not(:disabled)')
                if not btn: continue
                for _ in range(3):
                    cards=await pg.query_selector_all('.hand .card:not(.dim)')
                    if not cards: break
                    await safe(cards[0]); await pg.wait_for_timeout(100)
                    pb=await pg.query_selector('#bigbtns button.primary:not(:disabled)')
                    if pb: await safe(pb)
                    else:
                        gh=await pg.query_selector('#bigbtns button.ghost')
                        if gh: await safe(gh)
                        break
                    await pg.wait_for_timeout(250)
                    for _ in range(3):
                        picks=await pg.query_selector_all('.overlay #picks .card')
                        if picks: await safe(picks[0]); await pg.wait_for_timeout(250)
                        pp=await pg.query_selector('#pickPlayer')
                        if pp: await safe(pp); await pg.wait_for_timeout(250)
                for _ in range(7):
                    r=await pg.query_selector('.field .card.ready')
                    if not r: break
                    await safe(r); await pg.wait_for_timeout(100)
                    ol=await pg.query_selector('.pbar .life.target'); tg=await pg.query_selector('.field .card.target')
                    if ol: await safe(ol)
                    elif tg: await safe(tg)
                    else: break
                    await pg.wait_for_timeout(250)
                btn=await pg.query_selector('#endTurn:not(:disabled)')
                if btn: await safe(btn)
                await pg.wait_for_timeout(400)
        await A.wait_for_timeout(1500)
        for nm,pg in (('A',A),('B',B)):
            print(nm, await pg.evaluate('document.querySelector(".score")?.textContent'))
        # next game
        for pg in (A,B):
            nx=await pg.query_selector('#next')
            if nx: await safe(nx); await pg.wait_for_timeout(500)
        for pg in (A,B):
            print('after next', await pg.evaluate('document.querySelector(".screen").id'), await pg.evaluate('document.querySelector(".topbar .t")?.textContent'))
            au=await pg.query_selector('#auto')
            if au: await safe(au); await pg.wait_for_timeout(200)
            go=await pg.query_selector('#go:not(:disabled)')
            if go: await safe(go); await pg.wait_for_timeout(600)
        await A.wait_for_timeout(1000)
        for pg in (A,B):
            mg=await pg.query_selector('#mgo')
            if mg: await safe(mg); await pg.wait_for_timeout(800)
        for nm,pg in (('A',A),('B',B)):
            print(nm, await pg.evaluate('document.querySelector(".screen").id'), await pg.evaluate('document.querySelector(".score")?.textContent'), await pg.evaluate('document.querySelector(".result .big")?.textContent'))
        await A.screenshot(path='o1.png'); await B.screenshot(path='o2.png')
        print(sorted(set(errs)) or 'no errors'); await b.close()
asyncio.run(main())
