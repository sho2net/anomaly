// 真の姿の後に「万象喰らい」を使うか：最終ボスを弱らせた状態から数ターン回す
const AN=require('./ai.js'); const D=AN.CARD_BY_ID;
let games=0, awakened=0, used=0;
for(let i=0;i<200;i++){
  const rng=AN.makeRng('ph'+i);
  const pool=AN.drawPool(rng,87,null); const main=AN.AI.bestMain(pool); const deck=AN.AI.autoDeck(pool,rng,main);
  let bp=[]; AN.CARDS.forEach(d=>{ if(d.attr.includes('void')||d.attr.includes('flare')||!d.attr.length) bp.push(d); }); bp=rng.shuffle(bp).slice(0,30);
  const g=new AN.Game({seed:'p'+i,decks:[deck,bp],names:['P','Z'],mains:[main,'void'],choosers:[AN.AI.chooser(3),AN.AI.chooser(3)],lifes:[0,30],bossRules:[null,{devour:true,phase:15}]});
  let s=0; while(g.winner==null&&s++<5000) AN.AI.step(g,3);
  games++; if(g.players[1].phase2) awakened++;
  if(g.log.some(l=>/リーダー能力「万象喰らい」を使った/.test(l.s))) used++;
}
console.log('games',games,'真の姿になった',awakened,'その後に万象喰らいを使った試合',used);
