const AN=require('./ai.js'); const D=AN.CARD_BY_ID;
function G(){ return new AN.Game({seed:'sf',decks:[Array(30).fill(D.N01),Array(30).fill(D.N01)],names:['私','敵'],mains:['ray','flare'],first:0,noMulligan:true,choosers:[AN.AI.chooser(3),AN.AI.chooser(3)]}); }
function withGrail(){ const g=G(), me=g.players[0]; me.energy=20; me.hand.push(g.inst(D.X04)); g.play(me, me.hand[me.hand.length-1]); me.life=10; return g; }
const cases=[
 ['見習い僧（登場時2回復）', g=>{ const me=g.players[0]; me.hand.push(g.inst(D.R02)); g.play(me,me.hand[me.hand.length-1]); }],
 ['祈り（スペル3回復）', g=>{ const me=g.players[0]; me.hand.push(g.inst(D.R04)); g.play(me,me.hand[me.hand.length-1]); }],
 ['聖域の結界（ターン終了時2回復）', g=>{ const me=g.players[0]; me.hand.push(g.inst(D.R53)); g.play(me,me.hand[me.hand.length-1]); g.endTurn(); }],
 ['吸収（吸血蝙蝠の攻撃）', g=>{ const me=g.players[0]; const c=g.mkCr(g.inst(D.V05)); c.sick=false; me.field.push(c); g.attack(me,c,'player'); }],
 ['慈愛の聖女（自分のターン開始時2回復）', g=>{ const me=g.players[0]; me.field.push(g.mkCr(g.inst(D.R25))); g.endTurn(); g.endTurn(); }],
 ['大天使の慈悲（6回復＋1ドロー）', g=>{ const me=g.players[0]; me.hand.push(g.inst(D.R26)); g.play(me,me.hand[me.hand.length-1]); }],
];
for(const [name,fn] of cases){ const g=withGrail(); const op=g.players[1], me=g.players[0]; const a=op.life, h=me.life; fn(g); g.run();
  const heals=g.log.filter(l=>/私のライフ \+/.test(l.s)).length, hits=g.log.filter(l=>/「セラフの聖杯」/.test(l.s)&&/ライフ -/.test(l.s)).length;
  console.log(name.padEnd(22,'　'), '回復回数',heals,' 聖杯の発動',hits,' 敵ライフ',a,'→',op.life); }
