import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={'width':390,'height':780}, device_scale_factor=2)
        errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/anomaly/index.html'); await pg.wait_for_timeout(500)
        await pg.click('#btnCodex'); await pg.wait_for_timeout(300); await pg.screenshot(path='c1_codex.png')
        await pg.click('#back'); await pg.click('#btnNew'); await pg.wait_for_timeout(200); await pg.screenshot(path='c2_setup.png')
        await pg.fill('#seed','test7'); await pg.click('#go'); await pg.wait_for_timeout(300)
        await pg.click('#auto'); await pg.wait_for_timeout(200); await pg.click('#go'); await pg.wait_for_timeout(1500)
        shots=0; blocks=0; targets=0
        for turn in range(40):
            for _ in range(20):
                nob=await pg.query_selector('#nob')
                if nob:
                    blocks+=1
                    if blocks==1: await pg.screenshot(path='c3_block.png')
                    picks=await pg.query_selector_all('#picks .card')
                    if picks: await picks[0].click()
                    else: await nob.click()
                    await pg.wait_for_timeout(400); continue
                picks=await pg.query_selector_all('.overlay #picks .card')
                if picks and not await pg.query_selector('#nob'):
                    targets+=1
                    if targets==1: await pg.screenshot(path='c4_target.png')
                    await picks[0].click(); await pg.wait_for_timeout(400); continue
                break
            if await pg.query_selector('#result'):
                await pg.screenshot(path='c9_result.png'); break
            btn=await pg.query_selector('#endTurn')
            if not btn or not await btn.is_enabled():
                await pg.wait_for_timeout(700); continue
            # my turn: charge first (cheapest non-anomaly), then play all playable, then attack all
            cards=await pg.query_selector_all('.hand .card')
            if cards:
                await cards[-1].click(); await pg.wait_for_timeout(150)
                bb=await pg.query_selector('#bigbtns button:not(:disabled)')
                txt=await bb.text_content() if bb else ''
                if bb and 'チャージ' in txt: await bb.click()
                else: await pg.click('#bigbtns button.ghost')
                await pg.wait_for_timeout(200)
            for _ in range(6):
                played=False
                cards=await pg.query_selector_all('.hand .card:not(.dim)')
                for c in cards:
                    await c.click(); await pg.wait_for_timeout(150)
                    pb=await pg.query_selector('#bigbtns button.primary:not(:disabled)')
                    if pb: await pb.click(); played=True; await pg.wait_for_timeout(400); break
                    await pg.click('#bigbtns button.ghost'); await pg.wait_for_timeout(100)
                # handle target picker
                picks=await pg.query_selector_all('.overlay #picks .card')
                if picks: 
                    targets+=1
                    if targets==1: await pg.screenshot(path='c4_target.png')
                    await picks[0].click(); await pg.wait_for_timeout(300)
                if not played: break
            if turn==6: await pg.screenshot(path='c5_midgame.png')
            for _ in range(8):
                r=await pg.query_selector('.field .card.ready')
                if not r: break
                await r.click(); await pg.wait_for_timeout(150)
                if turn in (4,6) and shots==0: await pg.screenshot(path='c6_attackmode.png'); shots=1
                await pg.click('#life1'); await pg.wait_for_timeout(300)
                nob=await pg.query_selector('#nob')
            btn=await pg.query_selector('#endTurn')
            if btn and await btn.is_enabled(): await btn.click()
            await pg.wait_for_timeout(2500)
        print('blocks',blocks,'targets',targets)
        print('\n'.join(errs) if errs else 'no errors')
        await b.close()
asyncio.run(main())
