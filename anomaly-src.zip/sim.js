const AN=require('./ai.js');
function playGame(seed, lv1, lv2){
  const rng=AN.makeRng('pool'+seed);
  const pools=[0,1].map(i=>{ const p=AN.drawPool(rng,87,null); for(let k=0;k<3;k++) p.unshift(AN.makeAnomaly(rng,i*3+k,null)); return p; });
  const mains=pools.map(p=>AN.AI.bestMain(p));
  const decks=pools.map((p,i)=>AN.AI.autoDeck(p,rng,mains[i]));
  const g=new AN.Game({seed:'g'+seed, decks, names:['A','B'], mains, choosers:[AN.AI.chooser(lv1),AN.AI.chooser(lv2)]});
  let steps=0;
  while(g.winner==null && steps<3000){
    if(g.pending){ throw new Error('pending for CPU?'+JSON.stringify(g.pendingInfo&&g.pendingInfo.type)); }
    AN.AI.step(g, g.active===0?lv1:lv2); steps++;
  }
  return {winner:g.winner, turn:g.turn, first:g.first, deckout:g.players.some(p=>p.deck.length===0), g, mains};
}
const N=parseInt(process.argv[2]||'300'), lv1=parseInt(process.argv[3]||'3'), lv2=parseInt(process.argv[4]||'3');
let wins=[0,0], turns=0, firstWins=0, deckouts=0, maxT=0, unfinished=0;
const attrW={}; const attrG={};
for(let i=0;i<N;i++){
  const r=playGame(i,lv1,lv2);
  if(r.winner==null){unfinished++; continue;}
  wins[r.winner]++; r.mains.forEach((m,i)=>{ attrG[m]=(attrG[m]||0)+1; if(r.winner===i) attrW[m]=(attrW[m]||0)+1; }); turns+=r.turn; maxT=Math.max(maxT,r.turn); if(r.winner===r.first) firstWins++; if(r.deckout) deckouts++;
}
console.log(`games ${N} lv${lv1} vs lv${lv2}: A ${wins[0]} B ${wins[1]} unfinished ${unfinished}`);
console.log(`avg turns ${(turns/(N-unfinished)).toFixed(1)} max ${maxT} firstPlayerWinRate ${(firstWins/(N-unfinished)*100).toFixed(0)}% deckout games ${deckouts}`);
console.log('attr winrate', Object.keys(attrG).map(a=>a+':'+Math.round((attrW[a]||0)/attrG[a]*100)+'%').join(' '));
