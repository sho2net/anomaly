# 全効果音をオフラインで書き出し、NaN（無音化の原因）とピーク音量を確認する。bad=0 ならOK
import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page()
        await pg.goto('file:///home/claude/anomaly/lab.html'); await pg.wait_for_timeout(300)
        r=await pg.evaluate("""async()=>{ const out=[]; const attrs=['flare','tide','grow','ray','void','none','anom'];
          for(const n of AN.SFX.names){ const args = (n==='play'||n==='spell'||n==='relic')?attrs:(n==='turn'||n==='anomaly')?[true,false]:(n==='hit'||n==='face')?[1,8]:[null];
            for(const a of args){ let bad=0, pk=[]; for(let k=0;k<5;k++){ const x=await AN.SFX.renderOffline(n,a,4); if(x.err||!(x.peak>=0)) bad++; pk.push(x.peak); } out.push(n+':'+a+' bad='+bad+' peak='+Math.min(...pk).toFixed(2)+'-'+Math.max(...pk).toFixed(2)); } }
          return out; }""")
        print('\n'.join(r))
        await b.close()
asyncio.run(main())
