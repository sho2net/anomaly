# 長い曲のループ点探し：拍に合わせ、直前・直後8拍の響き（和音・音色・音量）が最も似ている a→b を選ぶ
import librosa, numpy as np, sys
f=sys.argv[1]; lo=float(sys.argv[2]) if len(sys.argv)>2 else 0.5
y,sr=librosa.load(f,sr=22050,mono=True)
tempo,beats=librosa.beat.beat_track(y=y,sr=sr)
bt=librosa.frames_to_time(beats,sr=sr)
ch=librosa.feature.chroma_cqt(y=y,sr=sr); mf=librosa.feature.mfcc(y=y,sr=sr,n_mfcc=13); rms=librosa.feature.rms(y=y)[0]
F=librosa.util.sync(np.vstack([ch, mf/40, rms[None,:]*10]),beats,aggregate=np.mean).T
n=len(bt); dur=len(y)/sr
rm=lambda t: float(np.sqrt(np.mean(y[int(t*sr):int((t+4)*sr)]**2)))
endq=max(t for t in bt if rm(t)>0.5*rm(dur*0.8))  # 終わりのフェードが始まる前
best=[]
def cos(a,b): return float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)+1e-9))
for bi in range(8,n-8):
    if not (dur*float(sys.argv[3] if len(sys.argv)>3 else 0.65) < bt[bi] < min(endq, dur-8)): continue
    for ai in range(8,n-8):
        if not (6 < bt[ai] < dur*lo): continue
        if (bi-ai)%4: continue
        s=cos(F[ai-8:ai].ravel(),F[bi-8:bi].ravel()); s2=cos(F[ai:ai+8].ravel(),F[bi:bi+8].ravel())
        best.append((s+s2,bt[ai],bt[bi]))
best.sort(reverse=True)
print('tempo',float(np.ravel(tempo)[0]),'dur',round(dur,2),'fade starts ~',round(endq,1))
for b in best[:6]: print(f"score={b[0]:.3f}  {b[1]:.3f}s -> {b[2]:.3f}s  (loop {b[2]-b[1]:.1f}s)")
