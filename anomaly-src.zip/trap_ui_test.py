import asyncio
from playwright.async_api import async_playwright
async def start(pg):
    await pg.goto('file:///home/claude/anomaly/index.html'); await pg.wait_for_timeout(300)
    await pg.evaluate('localStorage.clear()'); await pg.reload(); await pg.wait_for_timeout(300)
    await pg.click('#btnNew'); await pg.fill('#seed','trp'); await pg.click('#go'); await pg.wait_for_timeout(300)
    await pg.click('#auto'); await pg.wait_for_timeout(200); await pg.click('#go'); await pg.wait_for_timeout(900)
    mg=await pg.query_selector('#mgo')
    if mg: await mg.click()
    for _ in range(30):
        if await pg.query_selector('#endTurn:not(:disabled)'): break
        await pg.wait_for_timeout(400)
state="()=>{ const g=window.__g(); return 'halt='+g.halt+' myField='+g.players[0].field.map(c=>c.c.d.name).join(',')+' oppField='+g.players[1].field.map(c=>c.c.d.name+'('+g.health(c)+')').join(',')+' oppLife='+g.players[1].life+' myHand='+g.players[0].hand.length; }"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':780}, device_scale_factor=2)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        # 1) I attack into CPU's 渦の罠 / 爆炎の罠 / 道連れの罠
        for trap in ['T54','F53','V54']:
            await start(pg)
            await pg.evaluate("(t)=>{ const g=window.__g(); const me=g.players[0], op=g.players[1]; me.field.length=0; op.field.length=0; const c=g.mkCr(g.inst(AN.CARD_BY_ID['N05'])); c.sick=false; me.field.push(c); op.traps.push(g.inst(AN.CARD_BY_ID[t])); window.__rb(); }", trap)
            await pg.click('.field .card.ready', force=True); await pg.wait_for_timeout(150)
            await pg.click('.pbar .life.target'); await pg.wait_for_timeout(500)
            during=await pg.evaluate(state); banner=await pg.evaluate("document.querySelector('.reveal .rv-kind')?document.querySelector('.reveal .rv-kind').innerText:'(no banner)'")
            if trap=='T54': await pg.screenshot(path='tp1.png')
            await pg.click('.reveal'); await pg.wait_for_timeout(700)
            after=await pg.evaluate(state)
            if trap=='T54': await pg.screenshot(path='tp2.png')
            print(f'[私が攻撃→CPUの{trap}] 表示中: {banner} | {during}\n      閉じた後: {after}')
        # 2) CPU attacks into my 爆炎の罠: end my turn, CPU acts
        await start(pg)
        await pg.evaluate("()=>{ const g=window.__g(); const me=g.players[0], op=g.players[1]; me.field.length=0; op.field.length=0; const c=g.mkCr(g.inst(AN.CARD_BY_ID['N05'])); c.sick=false; op.field.push(c); me.traps.push(g.inst(AN.CARD_BY_ID['F53'])); op.hand.length=0; window.__rb(); }")
        await pg.click('#endTurn'); 
        seen=None
        for _ in range(30):
            await pg.wait_for_timeout(300)
            if await pg.query_selector('.reveal'):
                seen=await pg.evaluate(state); break
        await pg.wait_for_timeout(3500)
        after=(await pg.evaluate(state))+' active='+str(await pg.evaluate('window.__g().active'))
        print(f'[CPUが攻撃→私の爆炎の罠] 表示中: {seen}\n      閉じた後: {after}')
        # 3) summon trap and counter trap: CPU plays into my 茨の罠 / 対抗呪文
        for trap,card in [('G54','N05'),('N51','N10')]:
            await start(pg)
            await pg.evaluate("(a)=>{ const [t,c]=a; const g=window.__g(); const me=g.players[0], op=g.players[1]; me.field.length=0; op.field.length=0; me.field.push(g.mkCr(g.inst(AN.CARD_BY_ID['N03']))); me.traps.push(g.inst(AN.CARD_BY_ID[t])); op.hand.length=0; op.hand.push(g.inst(AN.CARD_BY_ID[c])); op.energyMax=9; window.__rb(); }", [trap,card])
            await pg.click('#endTurn')
            seen=None
            for _ in range(30):
                await pg.wait_for_timeout(300)
                if await pg.query_selector('.reveal'):
                    seen=await pg.evaluate(state); break
            await pg.wait_for_timeout(3500)
            after=await pg.evaluate(state)
            log=await pg.evaluate("()=>window.__g().log.slice(-6).map(l=>l.s).join(' → ')")
            print(f'[CPUが{card}を出す→私の{trap}] 表示中: {seen}\n      閉じた後: {after}\n      {log}')
        print(errs or 'no errors'); await b.close()
asyncio.run(main())
