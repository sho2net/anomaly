const AN=require('./ai.js'); const D=AN.CARD_BY_ID;
function setup(ownerHuman){
  const g=new AN.Game({seed:'tt',decks:[Array(30).fill(D.N01),Array(30).fill(D.N01)],names:['人','CPU'],first:0,noMulligan:true,choosers: ownerHuman?[null,AN.AI.chooser(3)]:[AN.AI.chooser(3),null]});
  return g;
}
function run(trapId, ownerHuman, attackFace){
  const g=setup(ownerHuman);
  // attacker = active player 0 always; trap owner = player 1
  const att=g.players[0], own=g.players[1];
  if(ownerHuman){ g.choosers=[AN.AI.chooser(3),null]; }
  own.traps.push(g.inst(D[trapId]));
  const a=g.mkCr(g.inst(D.N05)); a.sick=false; att.field.push(a);
  const b=g.mkCr(g.inst(D.N03)); own.field.push(b);
  g.log.length=0; const lifeBefore=own.life;
  g.attack(att,a, attackFace?'player':b.c.uid);
  return {log:g.log.map(l=>l.s).join(' → '), pending:!!g.pending, defLife:own.life+'/'+lifeBefore, attackerOnField:att.field.includes(a), defCr:own.field.includes(b)?own.field.find(x=>x===b)&&(g.health(b)+'/'+g.maxHealth(b)):'gone'};
}
for(const [id,face] of [['T54',true],['T54',false],['F53',true],['F53',false],['V54',true]]){
  for(const human of [false,true]){
    const r=run(id,human,face);
    console.log(`[${D[id].name} 罠の持ち主=${human?'人':'CPU'} 攻撃先=${face?'本体':'クリーチャー'}] pending=${r.pending} 攻撃側は場に=${r.attackerOnField} 防御側ライフ=${r.defLife}\n   ${r.log}`);
  }
}
