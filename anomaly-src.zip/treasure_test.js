const AN=require('./ai.js'); const D=AN.CARD_BY_ID;
function G(){ const g=new AN.Game({seed:'tr',decks:[Array(30).fill(D.N01),Array(30).fill(D.N01)],names:['私','敵'],first:0,noMulligan:true,choosers:[AN.AI.chooser(3),AN.AI.chooser(3)]}); return g; }
const L=g=>g.log.slice(-6).map(l=>l.s).join(' → ');
// X04 セラフの聖杯
{ const g=G(), me=g.players[0], op=g.players[1]; me.energy=10; me.hand.push(g.inst(D.X04)); g.play(me, me.hand[me.hand.length-1]);
  me.life=20; const before=op.life; g.gainLife(me,3); g.run();
  console.log('X04 聖杯: 回復後の相手ライフ', before,'→',op.life, '|', L(g)); }
// X01 炎心
{ const g=G(), me=g.players[0], op=g.players[1]; me.energy=10; me.hand.push(g.inst(D.X01)); g.play(me, me.hand[me.hand.length-1]);
  const c=g.mkCr(g.inst(D.N03)); op.field.push(c); const lb=op.life; g.endTurn(); g.endTurn();
  console.log('X01 炎心: 次の自分のターン開始時 相手ライフ',lb,'→',op.life,'相手クリーチャー体力',g.health(c)+'/'+g.maxHealth(c), '|', L(g)); }
// X02 真珠
{ const g=G(), me=g.players[0]; me.energy=10; me.hand.length=0; me.hand.push(g.inst(D.N05)); me.hand.push(g.inst(D.X02)); g.play(me, me.hand[1]);
  console.log('X02 真珠: 手札', me.hand.map(c=>c.d.name+'('+g.costOf(me,c.d,c)+'/元'+c.d.cost+')').join(', '), '|', L(g)); }
// X03 種
{ const g=G(), me=g.players[0]; me.energy=10; me.hand.push(g.inst(D.X03)); g.play(me, me.hand[me.hand.length-1]); const c=me.field[me.field.length-1];
  const s0=g.power(c)+'/'+g.health(c); g.endTurn(); g.endTurn();
  console.log('X03 種: 出したとき',s0,'→ 次の自分のターン開始後',g.power(c)+'/'+g.health(c), '|', L(g)); }
// X05 王冠
{ const g=G(), me=g.players[0]; me.energy=10; me.grave.push(g.inst(D.N05),g.inst(D.N03),g.inst(D.V01)); me.hand.push(g.inst(D.X05)); g.play(me, me.hand[me.hand.length-1]);
  console.log('X05 王冠: 場', me.field.map(c=>c.c.d.name).join(', '), '吸収?', g.hasKw(me.field[0],'drain'), '|', L(g)); }
