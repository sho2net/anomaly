const AN=require('./ai.js');
const ADJ=JSON.parse(process.env.ADJ||'{}');
AN.CARDS.forEach(d=>{ if(d.type!=='creature') return; const a=d.attr[0]; const v=ADJ[a]; if(!v) return; if(v.hp) d.hp=Math.max(1,d.hp+v.hp); if(v.atk) d.power=Math.max(0,d.power+v.atk); if(v.cheapHp && d.cost<=3) d.hp=Math.max(1,d.hp+v.cheapHp); });
let W={},G={},first=0,N=parseInt(process.env.N||'500');
for(let i=0;i<N;i++){
  const rng=AN.makeRng('pool'+i);
  const pools=[0,1].map(k=>{ const p=AN.drawPool(rng,87,null); for(let j=0;j<3;j++) p.unshift(AN.makeAnomaly(rng,k*3+j,null)); return p; });
  const mains=pools.map(p=>AN.AI.bestMain(p));
  const decks=pools.map((p,k)=>AN.AI.autoDeck(p,rng,mains[k]));
  const g=new AN.Game({seed:'g'+i,decks,names:['A','B'],mains,choosers:[AN.AI.chooser(3),AN.AI.chooser(3)]});
  let s=0; while(g.winner==null&&s++<4000) AN.AI.step(g,3);
  if(g.winner===g.first) first++;
  mains.forEach((m,k)=>{ G[m]=(G[m]||0)+1; if(g.winner===k) W[m]=(W[m]||0)+1; });
}
console.log(process.env.ADJ||'base', AN.ATTR_ORDER.map(a=>a+':'+Math.round((W[a]||0)/(G[a]||1)*100)).join(' '), 'first', Math.round(first/N*100));
