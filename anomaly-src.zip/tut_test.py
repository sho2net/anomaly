# v3.19 チュートリアルの通し確認（案内に従って操作 → 以降はAIに打たせて最後まで）
import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(); pg=await b.new_page(viewport={'width':390,'height':780}, device_scale_factor=2)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/anomaly/index.html'); await pg.evaluate('localStorage.clear()'); await pg.reload(); await pg.wait_for_timeout(300)
        await pg.click('#btnTut'); await pg.wait_for_timeout(800); await pg.screenshot(path='tu1.png')
        seen=[]
        async def tip():
            return await pg.evaluate("document.querySelector('.tutbox .tx')?document.querySelector('.tutbox .tx').innerText.slice(0,40):''")
        # 案内に従う
        for step in range(40):
            t=await tip(); 
            if t and (not seen or seen[-1]!=t): seen.append(t)
            ok=await pg.query_selector('#tutok')
            if ok: await ok.click(); await pg.wait_for_timeout(300); continue
            hl=await pg.query_selector('.tut-hl')
            if hl:
                if step<12: await pg.screenshot(path='tu_%02d.png'%step)
                await hl.click(); await pg.wait_for_timeout(400)
                pb=await pg.query_selector('.overlay button.primary')
                if pb and not await pb.is_disabled(): await pb.click(); await pg.wait_for_timeout(1500)
                continue
            # 案内が無い／相手のターン：待つ
            act=await pg.evaluate("__g().active")
            if act==0:
                await pg.evaluate("()=>{ const g=__g(); AN.AI.step(g,2); __rb(); if(g.active===1) window.__act({t:'noop'}); }"); await pg.wait_for_timeout(500)
            else: await pg.wait_for_timeout(1500)
            if await pg.evaluate("__g().winner!=null"): break
        # 残りはAIで最後まで
        for i in range(400):
            if await pg.evaluate("!window.__g()||__g().winner!=null"): break
            ok=await pg.query_selector('#tutok')
            if ok: await ok.click(); t=await tip(); seen.append(t)
            if await pg.evaluate("!!__g().pending && __g().pendingInfo.p===0"):
                await pg.evaluate("()=>{ const g=__g(); const q=g.pendingInfo; const c=(q.cands||q.options||[])[0]; g.provideChoice(c&&c.v!=null?c.v:c); __rb(); if(g.active===1) window.__act({t:'noop'}); }")
            elif await pg.evaluate("__g().active===0 && !__g().pending"):
                await pg.evaluate("()=>{ const g=__g(); AN.AI.step(g,3); __rb(); if(g.active===1) window.__act({t:'noop'}); }")
            await pg.wait_for_timeout(250)
        await pg.wait_for_timeout(2500)
        await pg.screenshot(path='tu_end.png')
        print(await pg.evaluate("JSON.stringify({a:__g().active,t:__g().turn,p:!!__g().pending,pi:__g().pendingInfo&&__g().pendingInfo.type,halt:__g().halt,ov:!!document.querySelector('.overlay'),lv:__g().players.map(x=>x.life)})")); print('\n'.join(seen)); print('winner', await pg.evaluate("window.__g()?__g().winner:null"), 'screen', await pg.evaluate("document.querySelector('.screen').id"), 'errors', errs)
        await b.close()
asyncio.run(main())
