// ===== ANOMALY ui.js =====
(function(){
const app=document.getElementById('app');
const LS='anomaly_series_v2';
let series=null, game=null, cpuTimer=null, evSeen=0;
const ui={screen:'title', attackFrom:null, filter:'all', cfilter:'all', sheet:null, lastLog:'', me:0};
const ART=k=>'art/'+k+'.webp'; // v3.16 一枚絵（WebP。無ければ表示されないだけ）
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

// ---------- serialization ----------
function serPool(pool){ return pool.map(d=>d.anomaly? d : d.id); }
function deserPool(arr){ return arr.map(x=> typeof x==='string' ? AN.CARD_BY_ID[x] : x); }
function save(){ if(!series) return; try{ localStorage.setItem(LS, JSON.stringify({seed:series.seed,format:series.format,level:series.level,wins:series.wins,gameNo:series.gameNo,pools:series.pools.map(serPool),decks:series.decks,nextFirst:series.nextFirst,mains:series.mains,boss:series.boss||null})); }catch(e){} }
function load(){ try{ const j=JSON.parse(localStorage.getItem(LS)); if(!j) return null; j.pools=j.pools.map(deserPool); return j; }catch(e){ return null; } }
function clearSave(){ try{ localStorage.removeItem(LS); }catch(e){} }

// ---------- card element ----------
function statHtml(d,o){
  const atk=o.power!=null?o.power:d.power, hpMax=o.hpMax!=null?o.hpMax:d.hp, hp=o.hp!=null?o.hp:hpMax;
  return '<div class="atk">'+atk+'</div><div class="power'+(hp<hpMax?' dmg':'')+'">'+hp+'</div>';
}
// v3.17 カード絵：通常カード231種は art/cards/<ID>.webp。アノマリー・トークン・秘宝などはアイコンのまま
let CARD_ART=null;
// v3.21 アノマリーの絵：伝説は型ごとに1枚、ふつう・奇妙は名前から決まる絵（同じ名前なら誰の画面でも同じ絵）
const ANOM_LEGEND=['jester','seer','usurp','gear','reckless','titan','sun','soul','time','queen','undead'];
function anomArt(d){
  if(d.legend && ANOM_LEGEND.includes(d.legendType)) return 'art/anom/'+d.legendType+'.webp';
  let h=0; const s=String(d.name||'')+'|'+(d.id||''); for(let i=0;i<s.length;i++) h=(h*31+s.charCodeAt(i))>>>0;
  const spell=d.type!=='creature', set= d.weird ? (spell?['ws1','ws2','ws3']:['wc1','wc2','wc3','wc4']) : (spell?['sp1','sp2','sp3','sp4']:['cr1','cr2','cr3','cr4','cr5','cr6']);
  return 'art/anom/'+set[h%set.length]+('ab'[(h>>>8)%2])+'.webp';
}
function cardArt(d){ if(d.anomaly) return anomArt(d); if(!CARD_ART) CARD_ART=new Set(AN.CARDS.map(c=>c.id)); return (!d.treasure && CARD_ART.has(d.id)) ? 'art/cards/'+d.id+'.webp' : null; }
function cardEl(d, o){
  o=o||{};
  const el=document.createElement('div');
  const attrCls=d.attr.length?'a-'+d.attr[0]:'a-none';
  el.className='card '+(d.anomaly?'anom':(d.treasure?'treasure':attrCls))+(o.big?' bigcard':'')+(o.tapped?' tapped':'')+(o.sick?' sick':'')+(o.ready?' ready':'')+(o.target?' target':'')+(o.frozen?' frozen':'')+(o.sel?' sel':'');
  if(o.back){ el.className='card back'+(o.big?' bigcard':''); el.innerHTML='<div class="q">?</div>'; return el; }
  const typeN={creature:'クリーチャー',spell:'スペル',equip:'装備',relic:'置物',trap:'罠'}[d.type];
  const attrN=d.attr.length? d.attr.map(a=>AN.ATTRS[a].n+'('+AN.ATTRS[a].k+')').join('/') : '無属性';
  const art=cardArt(d); if(art) el.classList.add('hasart');
  let h=(art?'<img class="cart" src="'+art+'" alt="" draggable="false" onerror="this.parentNode.classList.remove(\'hasart\');this.nextSibling.remove();this.remove()"><div class="cshade"></div>':'')+'<div class="art">'+AN.iconSvg(d)+'</div><div class="cost">'+(o.cost!=null?o.cost:d.cost)+'</div><div class="rar">'+(d.anomaly?'?':(d.treasure?'宝':d.rarity))+'</div><div class="name">'+esc(d.name)+'</div>';
  if(o.big){
    h+='<div class="type">'+typeN+' / '+attrN+(d.anomaly?(d.weird?' / アノマリー（奇妙）':(d.legend?' / アノマリー（伝説）':' / アノマリー')):' / '+AN.RARITY[d.rarity].n)+'</div>';
    const lines=AN.cardText(d);
    h+='<div class="text">'+(lines.length?lines.map(esc).join('<br>'):'<span style="color:var(--muted)">（効果なし）</span>')+'</div>';
    if(d.type==='creature') h+=statHtml(d,o);
  } else {
    h+='<div class="type">'+(d.type==='creature'?'':({spell:'スペル',equip:'装備',relic:'置物',trap:'罠'}[d.type]))+'</div>';
    if(d.type==='creature') h+=statHtml(d,o);
    if(o.badge) h+='<div class="badge">'+esc(o.badge)+'</div>';
    if(o.eq) h+='<div class="eq">装+'+o.eq+'</div>';
  }
  el.innerHTML=h; return el;
}

// ---------- overlay / sheet ----------
function closeSheet(){ const o=app.querySelector('.overlay'); if(o) o.remove(); ui.sheet=null; }
function sheet(html, center, modal){
  closeSheet();
  const o=document.createElement('div'); o.className='overlay'+(center?' center':'');
  o.innerHTML='<div class="sheet">'+html+'</div>';
  if(!modal) o.addEventListener('click',e=>{ if(e.target===o) closeSheet(); });
  app.appendChild(o); return o;
}
function sndIcon(){ const m=AN.SFX.isMuted() && !AN.BGM.isOn(); return '<svg viewBox="0 0 24 24" width="15" height="15" style="vertical-align:-3px" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor"/>'+(m?'<path d="M17 9l5 6M22 9l-5 6"/>':'<path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/>')+'</svg>'; }
// v3.15 サウンド設定（効果音と音楽を別々に）
function soundSheet(onClose){
  // 対戦中にCPUが動いて画面が描き直されても消えないよう、#app の外（body）に出す
  const old=document.getElementById('sndsheet'); if(old) old.remove();
  const sh=document.createElement('div'); sh.className='overlay center'; sh.id='sndsheet'; sh.style.cssText='position:fixed;z-index:50';
  sh.addEventListener('click',e=>{ if(e.target===sh){ sh.remove(); if(onClose) onClose(); } });
  sh.innerHTML='<div class="sheet" style="max-width:420px">'+('<h3>サウンド</h3>'
    +'<div class="field-label">音楽</div><div class="seg" id="sgM"><button data-v="1">オン</button><button data-v="0">オフ</button></div>'
    +'<div class="field-label">音楽の音量</div><input type="range" id="mvol" min="0" max="100" step="5" style="width:100%">'
    +'<div class="field-label">効果音</div><div class="seg" id="sgS"><button data-v="1">オン</button><button data-v="0">オフ</button></div>'
    +'<div class="btns"><button class="primary" id="sdone">閉じる</button></div>')+'</div>'; document.body.appendChild(sh);
  const upd=()=>{ sh.querySelectorAll('#sgM button').forEach(b=>b.classList.toggle('on', (+b.dataset.v===1)===AN.BGM.isOn())); sh.querySelectorAll('#sgS button').forEach(b=>b.classList.toggle('on', (+b.dataset.v===1)===!AN.SFX.isMuted())); };
  sh.querySelectorAll('#sgM button').forEach(b=>b.onclick=()=>{ AN.BGM.setOn(+b.dataset.v===1); upd(); });
  sh.querySelectorAll('#sgS button').forEach(b=>b.onclick=()=>{ AN.SFX.setMuted(+b.dataset.v!==1); upd(); });
  const r=sh.querySelector('#mvol'); r.value=Math.round(AN.BGM.vol()*100); r.oninput=()=>AN.BGM.setVol(r.value/100);
  sh.querySelector('#sdone').onclick=()=>{ sh.remove(); if(onClose) onClose(); };
  upd();
}
// 場面ごとの曲（null は今の曲を続ける）
function bgmKeyFor(id){
  if(id==='battle'){
    if(series && series.adv && typeof advRun!=='undefined' && advRun && advRun.pending){ const P=advRun.pending, en=P.en||{}; if(en.hardFinal) return 'judge'; if(en.final) return 'final'; if(P.kind!=='battle'||en.strong) return 'boss'; return 'battle'; }
    if(series && series.boss) return 'boss';
    return 'battle';
  }
  return ({title:'title',setup:'title',codex:'title',lobby:'title',wait:'title',boss:'title',advStart:'title',advEnd:'title',
    draft:'map',advMap:'map',advAnte:'map',advReward:'map',advDeck:'map',advShop:'tavern',advInn:'tavern',advEvent:'tavern'})[id]||null;
}
function toast(s){ const t=document.createElement('div'); t.className='toast'; t.textContent=s; app.appendChild(t); setTimeout(()=>t.remove(),1200); }

// ---------- 用語集 ----------
const GLOSS_MECH = {
  combo:['連撃N','このターンに自分がこのカード以外のカードをN枚以上プレイしていれば発動する（リーダー能力の使用も1枚に数える）。炎の看板メカニクス。'],
  boost:['詠唱','手札にある間、自分がスペルを唱えるたびに詠唱+1され、強化やコスト減が進む（潮読みもスペル扱い）。水の看板メカニクス。'],
  awaken:['繁茂','自分の最大エナジーが7以上なら発動する。森の看板メカニクス。'],
  pray:['祈りN','このゲームで自分のライフが回復した回数がN以上なら発動する。光の看板メカニクス。'],
  souls:['供物N','自分のカードが墓地に送られた数（破壊・スペル使用・捨て札）。Nを消費して発動する。闇の看板メカニクス。'],
  stun:['気絶','レスト効果や凍結を受けた状態。持ち主の次のターン開始まで、攻撃できず、守護として働かず、攻撃されても反撃しない。'],
  freeze:['凍結','気絶に加えて、持ち主の次のターン開始時にもスタンドしない。'],
  rest:['レスト／スタンド','レスト＝横向きの状態。攻撃・守護ができない。自分のターン開始時にスタンド（縦向き）に戻る。攻撃してもレストはしない。'],
  token:['トークン','効果で出る1/1などのクリーチャー。手札や山札に戻ると消え、墓地にも残らない。'],
  perm:['永続／ターン終了時まで','「永続」の強化は場にいる間ずっと残る。「ターン終了時まで」はそのターンの終わりに消える。'],
  dmg:['ダメージと体力','ダメージは蓄積し、体力0で破壊。戦闘では互いに攻撃力分のダメージを与え合う。'],
  noattack:['攻撃不能','このクリーチャーは攻撃できない（守護にはなれる）。'],
  relic:['置物','場に置く非クリーチャー（各自3つまで）。置物自身は攻撃せず、攻撃の対象にもならない（持ち主やクリーチャーを守る効果ではない）。常在効果や誘発効果を持つ。カウントダウン付きのものは自分のターン開始時に1減り、0で消える（消えるときの効果を持つものもある）。'],
  trap:['罠','伏せて置く（各自2つまで）。相手には中身が見えない。「相手が攻撃したとき」「相手が手札からクリーチャーを出したとき」「相手がスペルを唱えたとき」などの条件で一度だけ発動する。'],
  entry:['効果で場に出たクリーチャー','コピー・進化・蘇生・山札から直接など、手札以外から場に出たクリーチャーも登場時効果が発動する。ただし、その登場時効果のうち「クリーチャーを場に出す効果」（コピー・蘇生・進化など）は無限連鎖を防ぐため発動しない。相手のクリーチャーを変身させる効果（カエル化など）では発動しない。'],
  leader:['リーダー能力','毎ターン1回、エナジーを払って使える固有能力。一部のカードで書き換えられる。'],
};
function glossTerms(d){
  const out=[]; const add=(t,x)=>{ if(!out.some(o=>o[0]===t)) out.push([t,x]); };
  const kws=new Set(d.kw||[]);
  (d.effects||[]).forEach(x=>{ if(x.kw) kws.add(x.kw); if(x.tok && AN.TOKENS[x.tok]) AN.TOKENS[x.tok].kw.forEach(k=>kws.add(k)); });
  if(d.equip) d.equip.kw.forEach(k=>kws.add(k));
  kws.forEach(k=>{ if(AN.KW[k]) add(AN.KW[k], AN.KW_HELP[k]||''); });
  const reqs=[]; (d.effects||[]).forEach(x=>{ if(x.req) reqs.push(x.req); if(x.bonus) reqs.push(x.bonus.req); if(x.scale==='combo') reqs.push({combo:1}); if(x.scale==='boost') reqs.push({boost:1}); if(x.scale==='pray') reqs.push({pray:1}); if(x.scale==='souls') reqs.push({souls:1}); });
  if(d.sb) reqs.push({boost:1});
  reqs.forEach(r=>{ Object.keys(r).forEach(k=>{ if(GLOSS_MECH[k]) add(GLOSS_MECH[k][0],GLOSS_MECH[k][1]); }); });
  const txt=AN.cardText(d).join('');
  if(/気絶/.test(txt)) add(GLOSS_MECH.stun[0],GLOSS_MECH.stun[1]);
  if(/凍結/.test(txt)) add(GLOSS_MECH.freeze[0],GLOSS_MECH.freeze[1]);
  if(/レスト/.test(txt)) add(GLOSS_MECH.rest[0],GLOSS_MECH.rest[1]);
  if(/トークン|「(火花|泡|苗木|光の羽|骸|兵士|カエル)」/.test(txt)) add(GLOSS_MECH.token[0],GLOSS_MECH.token[1]);
  if(/リーダー能力/.test(txt)) add(GLOSS_MECH.leader[0],GLOSS_MECH.leader[1]);
  if(d.type==='relic') add(GLOSS_MECH.relic[0],GLOSS_MECH.relic[1]);
  if(d.type==='trap') add(GLOSS_MECH.trap[0],GLOSS_MECH.trap[1]);
  return out;
}
function glossHtml(list){ return list.length? '<div class="gloss">'+list.map(([t,x])=>'<div><b>'+esc(t)+'</b>：'+esc(x)+'</div>').join('')+'</div>' : ''; }
function showGlossary(){
  const kw=Object.keys(AN.KW).map(k=>[AN.KW[k], AN.KW_HELP[k]||'']);
  const mech=['combo','boost','awaken','pray','souls'].map(k=>GLOSS_MECH[k]);
  const rules=['dmg','rest','stun','freeze','perm','token','relic','trap','entry','leader'].map(k=>GLOSS_MECH[k]);
  const leaders=AN.ATTR_ORDER.map(a=>[AN.ATTRS[a].n+'「'+AN.LEADER[a].name+'」', AN.LEADER[a].cost+'エナジー：'+AN.LEADER[a].text]);
  const sec=(h,l)=>'<h3 style="margin-top:14px">'+h+'</h3>'+glossHtml(l);
  sheet('<h3>用語集</h3>'+sec('キーワード能力',kw)+sec('属性の看板メカニクス',mech)+sec('基本ルール',rules)+sec('リーダー能力（初期）',leaders)+'<div class="btns"><button class="ghost" id="gclose">閉じる</button></div>');
  const c=app.querySelector('#gclose'); if(c) c.onclick=closeSheet;
}
function cardSheet(d, o, buttons){
  const s=sheet('<div id="bigwrap"></div>'+glossHtml(glossTerms(d))+'<div class="btns" id="bigbtns"></div>', true);
  s.querySelector('#bigwrap').appendChild(cardEl(d, Object.assign({big:true},o||{})));
  const b=s.querySelector('#bigbtns');
  (buttons||[]).forEach(x=>{ const btn=document.createElement('button'); btn.textContent=x.label; btn.className=x.cls||''; btn.disabled=!!x.disabled; btn.onclick=()=>{ closeSheet(); x.fn&&x.fn(); }; b.appendChild(btn); });
  const c=document.createElement('button'); c.textContent='閉じる'; c.className='ghost'; c.onclick=closeSheet; b.appendChild(c);
  return s;
}

// ---------- screens ----------
function show(name){ ui.screen=name; render(); }
function render(){
  closeSheet();
  app.innerHTML='';
  const fn={advStart:renderAdvStart, advMap:renderAdvMap, advAnte:renderAdvAnte, advReward:renderAdvReward, advShop:renderAdvShop, advInn:renderAdvInn, advEvent:renderAdvEvent, advDeck:renderAdvDeck, tutEnd:renderTutEnd, boss:renderBoss, title:renderTitle, setup:renderSetup, draft:renderDraft, battle:renderBattle, codex:renderCodex, result:renderResult, lobby:renderLobby, wait:renderWait}[ui.screen];
  fn();
}
// v3.16.1 戦闘の背景：専用の絵（bg_*）→ 無ければ地域の絵 → 無ければ標準の闘技場。下の層は上の絵が無いときだけ見える
function battleBg(){
  const L=[]; let a=null;
  try{
    if(series && series.adv && typeof advRun!=='undefined' && advRun && advRun.pending){ const en=advRun.pending.en||{};
      if(en.hardFinal){ L.push('bg_judge'); a='ray'; } else if(en.final){ L.push('bg_devourer'); a='void'; } else a=advArea()||en.attr; }
    else if(series && series.boss){ const b=AN.BOSSES.find(x=>x.key===series.boss); if(b && !b.attr) L.push('bg_anomaly'); else a=b&&b.attr; }
    else if(game){ a=game.players[1-ui.me].main||game.players[ui.me].main; }
  }catch(e){}
  if(a && !L.length) L.push('bg_'+a);
  if(!L.length) L.push('bg_battle');
  return 'radial-gradient(130% 90% at 50% 45%,rgba(23,34,44,.5) 0%,rgba(23,34,44,.72) 60%,rgba(23,34,44,.9) 100%),'+L.map(k=>'url('+ART(k)+')').join(',');
}
function screenEl(id){ try{ AN.BGM.play(bgmKeyFor(id)); }catch(e){}
  try{ const bg=id==='battle'?battleBg():''; if(app.dataset.bg!==bg){ app.dataset.bg=bg; app.style.backgroundImage=bg; } }catch(e){} closeSheet(); app.innerHTML=''; const s=document.createElement('div'); s.className='screen on'; s.id=id; app.appendChild(s); return s; }
function div(cls, html){ const d=document.createElement('div'); d.className=cls||''; if(html!=null) d.innerHTML=html; return d; }

// ----- title -----
// v3.20 データの引き継ぎ：このブラウザに保存している進行（冒険・シリーズ・ボス・記録・設定）を、文字列またはファイルで書き出し／読み込み
function dataExport(){ const o={}; try{ for(let i=0;i<localStorage.length;i++){ const k=localStorage.key(i); if(k&&k.startsWith('anomaly_')) o[k]=localStorage.getItem(k); } }catch(e){} return 'ANOMALY1:'+btoa(unescape(encodeURIComponent(JSON.stringify({v:1,t:Date.now(),d:o})))); }
function dataImport(txt){ const s=String(txt||'').trim(); if(!s.startsWith('ANOMALY1:')) throw new Error('形式が違います'); const j=JSON.parse(decodeURIComponent(escape(atob(s.slice(9))))); if(!j||!j.d) throw new Error('中身が読めません');
  Object.keys(j.d).forEach(k=>{ if(k.startsWith('anomaly_')) localStorage.setItem(k, j.d[k]); }); return Object.keys(j.d).length; }
function dataSheet(){
  const code=dataExport();
  const sh=sheet('<h3>データの引き継ぎ</h3><div class="sub" style="line-height:1.7;margin-bottom:8px">冒険の進み具合・ボス挑戦・ハードの記録・設定などを書き出せます。ブラウザのデータを消す前や、別の端末に移すときに使ってください。</div>'
    +'<div class="field-label">書き出す</div><div class="btns" style="flex-wrap:wrap"><button class="primary" id="dcopy">コードをコピー</button><button id="dfile">ファイルに保存</button></div>'
    +'<div class="field-label" style="margin-top:14px">読み込む（今のデータは上書きされます）</div><textarea id="dtxt" rows="3" style="width:100%;font-size:12px" placeholder="ここにコードを貼り付け"></textarea>'
    +'<div class="btns" style="flex-wrap:wrap"><button id="dload">コードから読み込む</button><button id="dopen">ファイルから読み込む</button><input type="file" id="dinput" accept=".txt,text/plain" style="display:none"></div>'
    +'<div class="btns"><button class="ghost" id="dclose">閉じる</button></div>', true);
  const done=n=>{ toast(n+'件のデータを読み込みました'); setTimeout(()=>location.reload(),900); };
  const tryImport=t=>{ try{ done(dataImport(t)); }catch(e){ toast('読み込めませんでした：'+e.message); } };
  sh.querySelector('#dcopy').onclick=()=>{ (navigator.clipboard?navigator.clipboard.writeText(code):Promise.reject()).then(()=>toast('コピーしました')).catch(()=>{ const ta=sh.querySelector('#dtxt'); ta.value=code; ta.select(); toast('下の欄のコードをコピーしてください'); }); };
  sh.querySelector('#dfile').onclick=()=>{ const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([code],{type:'text/plain'})); a.download='anomaly-save-'+new Date().toISOString().slice(0,10)+'.txt'; document.body.appendChild(a); a.click(); a.remove(); };
  sh.querySelector('#dload').onclick=()=>askConfirm('今のデータを上書きして読み込みますか？','読み込む',()=>tryImport(sh.querySelector('#dtxt').value));
  sh.querySelector('#dopen').onclick=()=>sh.querySelector('#dinput').click();
  sh.querySelector('#dinput').onchange=e=>{ const f=e.target.files[0]; if(!f) return; f.text().then(t=>askConfirm('今のデータを上書きして読み込みますか？','読み込む',()=>tryImport(t))); };
  sh.querySelector('#dclose').onclick=()=>closeSheet();
}
function renderTitle(){
  const s=screenEl('title'); s.classList.add('hasart'); s.style.setProperty('--art','url('+ART('title')+')');
  const saved=load();
  s.innerHTML='<div class="scroll"><div class="wrap" style="padding-top:14vh">'
   +'<h1 class="logo">ANOMALY</h1><div class="sub" style="margin-top:8px">配られた90枚から30枚。うち3枚は、誰も知らないカード。</div>'
   +'<div class="menu">'
   +(saved?'<button class="primary" id="btnResume">続きから（第'+saved.gameNo+'ゲーム・'+saved.wins[0]+'–'+saved.wins[1]+'）</button>':'')
   +'<button class="'+(saved?'':'primary')+'" id="btnNew">新しい対戦を始める</button>'
   +'<button id="btnTut"'+(tutDone()?' class="ghost"':'')+'>チュートリアル（遊び方を覚える）'+(tutDone()?' <small style="color:#7be0b0">✓</small>':'')+'</button>'
   +'<button id="btnAdv">冒険モード（1人用）</button>'
   +'<button id="btnBoss">ボスに挑戦</button>'
   +'<button id="btnOnline">オンライン対戦（部屋コード）</button>'
   +(loadOnline()?'<button id="btnOnlineResume">オンライン対戦を再開（部屋 '+esc(loadOnline().code)+'）</button>':'')
   +'<button id="btnCodex">カードリスト（図鑑）</button>'
   +'<button class="ghost" id="btnData">データの引き継ぎ（バックアップ）</button>'
   +'<button class="ghost" id="btnSnd">'+sndIcon()+' サウンド（音楽 '+(AN.BGM.isOn()?'オン':'オフ')+'・効果音 '+(AN.SFX.isMuted()?'オフ':'オン')+'）</button>'
   +'</div><div class="sub" style="margin-top:28px;font-size:11px">v3.21 — CPU戦・'+AN.CARDS.length+'種プール</div></div></div>';
  s.querySelector('#btnNew').onclick=()=>show('setup');
  s.querySelector('#btnCodex').onclick=()=>show('codex');
  s.querySelector('#btnSnd').onclick=()=>soundSheet(()=>renderTitle());
  s.querySelector('#btnData').onclick=()=>dataSheet();
  s.querySelector('#btnOnline').onclick=()=>show('lobby');
  s.querySelector('#btnBoss').onclick=()=>show('boss');
  s.querySelector('#btnAdv').onclick=()=>show('advStart');
  s.querySelector('#btnTut').onclick=()=>tutStart();
  const ro=s.querySelector('#btnOnlineResume'); if(ro) ro.onclick=()=>onlineResume();
  if(saved) s.querySelector('#btnResume').onclick=()=>{ series=saved; if(series.decks[0]&&series.decks[0].length===AN.CONST.DECK_SIZE) startGame(); else show('draft'); };
}

// ----- setup -----
const setup={format:3, level:2, seed:'', main:'flare'};
function renderSetup(){
  const s=screenEl('setup');
  s.innerHTML='<div class="topbar"><button class="ghost" id="back">←</button><div class="t">新しい対戦</div></div><div class="scroll wrap">'
   +'<div class="field-label">形式</div><div class="seg" id="segF"><button data-v="3">BO3（2本先取）</button><button data-v="5">BO5（3本先取）</button></div>'
   +'<div class="field-label">CPUの強さ</div><div class="seg" id="segL"><button data-v="1">弱</button><button data-v="2">中</button><button data-v="3">強</button></div>'
   +'<div class="field-label">シード（空欄ならランダム。同じシードなら同じ90枚が配られる）</div><input type="text" id="seed" placeholder="例: fujisawa" value="'+esc(setup.seed)+'">'
   +'<div style="margin-top:26px"><button class="primary" id="go" style="width:100%">90枚を受け取る（自分でデッキを組む）</button></div>'
   +'<div style="margin-top:10px"><button id="quick" style="width:100%">おまかせデッキですぐ始める</button><div class="sub" style="margin-top:6px;font-size:12px">90枚から自動で組んだデッキで、すぐに1戦目を始めます。2戦目からは自分で調整できます。</div></div>'
   +'<div class="sub" style="margin-top:18px;line-height:1.7">・87枚はランダムな3属性から各25枚前後＋無属性12枚前後を抽選（コモン60% / アンコモン28% / レア10% / レジェンド2%）<br>・90枚を見てからメイン属性を決めます。デッキはメイン属性＋無属性＋アノマリー<br>・3枚はその場で生成される「アノマリー」。相手はあなたがプレイするまで効果を知りません<br>・エナジーは毎ターン自動で1増え（上限10）、ターン開始時に全回復<br>・初期手札は先攻4枚・後攻5枚。後攻には0コストの「星のかけら」（そのターンのエナジー+1）も配られます<br>・デッキは30枚ちょうど。ゲーム間にメイン属性も含めて組み直せます<br>・クリーチャーは左下が攻撃力、右下が体力</div></div>';
  const seg=(id,key)=>{ s.querySelectorAll('#'+id+' button').forEach(b=>{ b.classList.toggle('on', +b.dataset.v===setup[key]); b.onclick=()=>{ setup[key]=+b.dataset.v; renderSetup(); }; }); };
  seg('segF','format'); seg('segL','level');
  s.querySelector('#back').onclick=()=>show('title');
  s.querySelector('#go').onclick=()=>{ setup.seed=s.querySelector('#seed').value.trim(); newSeries(); setup.seed=''; };
  s.querySelector('#quick').onclick=()=>{ setup.seed=s.querySelector('#seed').value.trim(); setup.quick=true; newSeries(); setup.quick=false; setup.seed=''; };
}
function newSeries(){
  const seed=setup.seed||('s'+Math.floor(Math.random()*1e9).toString(36));
  const rng=AN.makeRng('pool:'+seed);
  const pools=[0,1].map(i=>{ const p=AN.drawPool(rng,87,null); const an=[0,1,2].map(k=>AN.makeAnomaly(rng,i*3+k,null)); return an.concat(p); });
  let mains=[null, AN.AI.bestMain(pools[1])];
  let boss=null;
  let bd=null;
  if(setup.boss){ boss=AN.BOSSES.find(b=>b.key===setup.boss); bd=AN.AI.bossDeck(boss, rng); pools[1]=bd.pool; mains[1]=boss.attr||null; }
  series={seed, format:boss?1:setup.format, level:boss?3:setup.level, wins:[0,0], gameNo:1, pools, decks:[[],[]], nextFirst:null, mains, boss:boss?boss.key:null};
  series.decks[1]= boss ? indicesFor(pools[1], bd.deck) : indicesFor(pools[1], AN.AI.autoDeck(pools[1],rng,mains[1]));
  if(setup.quick && !boss){ // v3.20 おまかせデッキ：自分のデッキも自動で組んで、すぐに1戦目へ
    const r2=AN.makeRng('quick:'+seed); series.mains[0]=AN.AI.bestMain(pools[0]); series.decks[0]=indicesFor(pools[0], AN.AI.autoDeck(pools[0],r2,series.mains[0]));
    save(); startGame(); return;
  }
  save(); show('draft');
}
function indicesFor(pool, defs){ const used=new Set(); const out=[]; defs.forEach(d=>{ for(let i=0;i<pool.length;i++){ if(pool[i]===d&&!used.has(i)){ used.add(i); out.push(i); break; } } }); return out; }

// ----- draft / deck builder -----
function poolGroups(pool){
  const map=new Map();
  pool.forEach((d,i)=>{ const k=d.anomaly?d.id:d.id; if(!map.has(k)) map.set(k,{d,idx:[]}); map.get(k).idx.push(i); });
  const arr=[...map.values()];
  const ao=a=>a.anomaly?-1:AN.ATTR_ORDER.indexOf(a.attr[0]);
  arr.sort((a,b)=> ao(a.d)-ao(b.d) || a.d.cost-b.d.cost || a.d.name.localeCompare(b.d.name,'ja'));
  return arr;
}
function renderDraft(){
  if(series.online && !series.pools){ renderWait(); return; }
  const s=screenEl('draft');
  const MY=ui.me; const pool=series.pools[MY]; const deck=series.decks[MY]; const DS=AN.CONST.DECK_SIZE;
  const groups=poolGroups(pool);
  const filters=[['all','すべて'],['anom','アノマリー'],['none','無属性'],...AN.ATTR_ORDER.map(a=>[a,AN.ATTRS[a].n+' '+AN.ATTRS[a].k]),['deck','デッキ内']];
  const sel=g=>g.idx.filter(i=>deck.includes(i)).length;
  const inDeck=deck.map(i=>pool[i]);
  const attrCnt={}; inDeck.forEach(d=>d.attr.forEach(a=>attrCnt[a]=(attrCnt[a]||0)+1));
  const main=(series.mains||[null,null])[MY];
  const attrOk=d=> d.anomaly || d.attr.length===0 || (main && d.attr.includes(main));
  const deckOk=deck.every(i=>attrOk(pool[i]));
  const curve=[0,0,0,0,0,0,0,0,0]; inDeck.forEach(d=>curve[Math.min(8,d.cost)]++);
  const maxC=Math.max(1,...curve);
  s.innerHTML='<div class="topbar"><button class="ghost" id="back">←</button><div class="t">デッキ構築 <span class="sub">第'+series.gameNo+'ゲーム'+(series.online?' ・ 部屋 '+series.online.code:'')+(main?' ・ <span style="color:'+AN.ATTRS[main].c+'">'+AN.ATTRS[main].n+'（'+AN.ATTRS[main].k+'）</span>':'')+'</span></div><button class="ghost helpbtn" id="help">？</button><button class="ghost" id="auto">おまかせ</button></div>'
   +'<div class="mainpick"><span class="sub">メイン属性</span>'+AN.ATTR_ORDER.map(a=>{ const k=pool.filter(d=>!d.anomaly&&d.attr.includes(a)).length; return '<button data-a="'+a+'" class="'+(main===a?'on':'')+'" style="--ac:'+AN.ATTRS[a].c+'">'+AN.ATTRS[a].n+'<small>'+k+'枚</small></button>'; }).join('')+'</div>'
   +'<div class="sub" style="padding:2px 12px 0;font-size:11px">今回配られた属性：'+AN.ATTR_ORDER.filter(a=>pool.some(d=>!d.anomaly&&d.attr.includes(a))).map(a=>'<span style="color:'+AN.ATTRS[a].c+'">'+AN.ATTRS[a].n+'</span>').join('・')+'</div>'
   +(main?'<div class="sub" style="padding:2px 12px 4px;font-size:11px">リーダー能力「'+esc(AN.LEADER[main].name)+'」：'+esc(AN.LEADER[main].text)+'</div>':'<div class="sub" style="padding:2px 12px 4px;font-size:11px">90枚を見て、メイン属性を選んでください（デッキ＝メイン属性＋無属性＋アノマリー）</div>')
   +'<div class="filters">'+filters.map(f=>'<button data-f="'+f[0]+'" class="'+(ui.filter===f[0]?'on':'')+'">'+f[1]+'</button>').join('')+'</div>'
   +'<div class="scroll"><div class="grid" id="grid"></div><div class="sub" style="padding:0 14px 14px;font-size:11px">カードをタップで詳細と枚数変更。右上は手持ち枚数、左下はデッキに入れた枚数。</div></div>'
   +'<div class="deckbar"><div class="n '+(deck.length===DS?'ok':'')+'">'+deck.length+'<span class="sub" style="font-family:var(--font);font-size:11px">/'+DS+'</span></div>'
   +'<div class="attrs">'+AN.ATTR_ORDER.filter(a=>attrCnt[a]).map(a=>'<span style="color:'+AN.ATTRS[a].c+'">'+AN.ATTRS[a].n+attrCnt[a]+'</span>').join('')+'<span>無'+inDeck.filter(d=>!d.attr.length).length+'</span>'+(deckOk?'':'<span style="color:#f28f8f">属性違反</span>')+'</div>'
   +'<div class="curve">'+curve.slice(1).map((c,i)=>'<i data-c="'+(i+1)+'" style="height:'+Math.max(2,c/maxC*22)+'px"></i>').join('')+'</div>'
   +'<div style="flex:1"></div><button class="primary" id="go" '+(deck.length===DS&&deckOk&&main?'':'disabled')+'>対戦へ</button></div>';
  const grid=s.querySelector('#grid');
  groups.forEach(g=>{
    const d=g.d, n=sel(g);
    if(ui.filter==='anom'&&!d.anomaly) return;
    if(AN.ATTR_ORDER.includes(ui.filter)&&!d.attr.includes(ui.filter)) return;
    if(ui.filter==='none'&&(d.attr.length||d.anomaly)) return;
    if(ui.filter==='deck'&&n===0) return;
    const w=document.createElement('div'); w.className='pcard'+(n===0?' out':'');
    w.appendChild(cardEl(d,{}));
    w.innerHTML+='<div class="have">×'+g.idx.length+'</div>'+(n?'<div class="cnt">'+n+'</div>':'');
    w.onclick=()=>openGroup(g);
    grid.appendChild(w);
  });
  function openGroup(g){
    const d=g.d, n=sel(g);
    const sh=cardSheet(d,{},[
      {label:'− 外す（'+n+'）',disabled:n===0,fn:()=>{ const i=g.idx.find(i=>deck.includes(i)); deck.splice(deck.indexOf(i),1); save(); renderDraft(); openGroup(groupsNow(g)); }},
      {label: attrOk(d)?'＋ 入れる（残'+(g.idx.length-n)+'）':(main?'メイン属性以外は不可':'先にメイン属性を選択'),cls:'primary',disabled:n>=g.idx.length||deck.length>=DS||!attrOk(d),fn:()=>{ const i=g.idx.find(i=>!deck.includes(i)); deck.push(i); save(); renderDraft(); openGroup(groupsNow(g)); }},
    ]);
  }
  function groupsNow(g){ return poolGroups(series.pools[MY]).find(x=>x.d===g.d)||g; }
  s.querySelectorAll('.filters button').forEach(b=>b.onclick=()=>{ ui.filter=b.dataset.f; renderDraft(); });
  s.querySelector('#help').onclick=showGlossary;
  s.querySelectorAll('.mainpick button').forEach(b=>b.onclick=()=>{ series.mains[MY]=b.dataset.a; const ok=d=>d.anomaly||d.attr.length===0||d.attr.includes(b.dataset.a); series.decks[MY]=series.decks[MY].filter(i=>ok(pool[i])); save(); renderDraft(); });
  s.querySelector('#back').onclick=()=>{ if(series.online){ onlineLeave(); series=null; } show('title'); };
  s.querySelector('#auto').onclick=()=>{ if(!series.mains[MY]) series.mains[MY]=AN.AI.bestMain(pool); series.decks[MY]=indicesFor(pool, AN.AI.autoDeck(pool, AN.makeRng(series.seed+series.gameNo+MY), series.mains[MY])); save(); renderDraft(); };
  s.querySelector('#go').onclick=()=>{ if(deck.length===DS&&deckOk&&main){ if(series.online) onlineReady(); else startGame(); } };
}

// ----- battle -----
function startGame(){
  const decks=[0,1].map(i=>series.decks[i].map(k=>series.pools[i][k]));
  // fresh anomaly reveal state per series is kept on the def object; fine.
  const first = series.nextFirst==null ? null : series.nextFirst;
  const boss=series.boss? AN.BOSSES.find(b=>b.key===series.boss) : null;
  game=new AN.Game({seed:series.seed+':g'+series.gameNo, decks, names:['あなた', boss?boss.name:'CPU'], first, mains:series.mains||[null,null], choosers:[null, AN.AI.chooser(series.level)],
    lifes: boss?[0,boss.life]:null, bossRules: boss&&boss.special==='anomaly'?[null,{chaos:true}]:null, leaders: boss?[null,boss.leader]:null, energyBonus: boss?[0,boss.energy]:null});
  game.uiPause=true;
  ui.attackFrom=null; evSeen=0; ui.mullSel=new Set();
  game.mulligan(game.players[1], AN.AI.mullPick(game,1));
  show('battle'); scheduleCpu();
}
function scheduleCpu(){
  clearTimeout(cpuTimer);
  if(!game||series.online||game.winner!=null||game.pending||game.halt||game.active!==1||game.phase==='mulligan') return;
  cpuTimer=setTimeout(()=>{ if(!game||ui.screen!=='battle') return; const a=AN.AI.step(game, series.level); renderBattle(); if(a) scheduleCpu(); else scheduleCpu(); },  Math.max(620, AN.FX.busy()+120));
}
function mechTxt(p){ switch(p.main){ case 'flare': return '連撃'+p.plays; case 'tide': return 'スペル'+p.spellsCast; case 'grow': return p.energyMax>=7?'繁茂中':'繁茂まで'+(7-p.energyMax); case 'ray': return '祈り'+p.pray; case 'void': return '供物'+p.souls; } return ''; }
// ---------- アノマリー公開演出 ----------
const revealQ=[]; let revealing=false;
function queueReveal(d, who){ revealQ.push({d,who}); if(!revealing) nextReveal(); }
function nextReveal(){
  const r=revealQ.shift(); if(!r){ revealing=false; return; }
  revealing=true;
  const el=document.createElement('div'); el.className='reveal'+(r.d.legend?' legend':'');
  if(r.d.phase){ el.className='reveal legend'; el.innerHTML='<div class="rv-inner"><div class="rv-kind">真の姿</div><div class="rv-who" style="font-size:18px;color:var(--text)">'+esc(r.d.name)+'が目覚めた</div><div class="rv-tap">タップで閉じる</div></div>'; }
  else {
  const kind = r.d.isTrap ? '罠発動' : (r.d.legend ? '伝説のアノマリー' : (r.d.weird ? '奇妙なアノマリー' : 'アノマリー'));
  el.innerHTML='<div class="rv-inner"><div class="rv-kind">'+kind+'</div><div class="rv-who">'+esc(r.who)+(r.d.isTrap?'の罠':'が解き放った')+'</div><div class="rv-card"></div><div class="rv-tap">タップで閉じる</div></div>';
  el.querySelector('.rv-card').appendChild(cardEl(r.d,{big:true}));
  }
  document.body.appendChild(el);
  let done=false; const close=()=>{ if(done) return; done=true; el.classList.add('out'); setTimeout(()=>{ el.remove(); if(r.d.isTrap && game && game.halt && !revealQ.some(x=>x.d.isTrap)){ game.resume(); if(ui.screen==='battle') afterAction(); } nextReveal(); }, 300); };
  el.onclick=close; setTimeout(close, r.d.legend?4200:2800);
}
function afterAction(){ renderBattle(); scheduleCpu(); }
function applyAction(g, a, p){
  const pl=g.players[p]; if(!pl) return;
  if(g.halt) g.resume();
  switch(a.t){
    case 'play': { const c=pl.hand.find(x=>x.uid===a.uid); if(c) g.play(pl,c); break; }
    case 'attack': { const cr=g.findCr(a.uid); if(cr) g.attack(pl,cr,a.target); break; }
    case 'ability': g.useAbility(pl); break;
    case 'end': if(g.active===p) g.endTurn(); break;
    case 'choice': if(g.pending && g.pendingInfo && g.pendingInfo.p===p) g.provideChoice(a.v); break;
    case 'mull': g.mulligan(pl, a.uids||[]); break;
    case 'concede': if(g.winner==null){ g.winner=1-p; g.say(pl.name+'は投了した','win'); g.queue=[]; g.pending=null; } break;
  }
}
function doAct(a){
  if(game && game.halt && !(series&&series.online)) return;
  if(series && series.online){ onlineSend(a); return; }
  applyAction(game, a, ui.me); afterAction();
}
function renderBattle(){
  const prevSnap=AN.FX.snapshot(document.getElementById('battle'));
  const s=screenEl('battle');
  const ME=ui.me, me=game.players[ME], op=game.players[1-ME];
  const myTurn=game.active===ME && !game.pending && game.winner==null;
  const pend=game.pending ? game.pendingInfo : null;
  const humanPend = pend && pend.p===ME;
  const atkMode=ui.attackFrom && myTurn;
  const atkCr=atkMode? game.findCr(ui.attackFrom):null;
  if(atkMode && (!atkCr || !game.canAttackWith(me,atkCr))) { ui.attackFrom=null; }
  const targets = (atkMode&&atkCr)? game.attackTargets(me,atkCr) : [];

  const pbar=(p,top)=>{
    const free=p.energy;
    let chips='<div class="energyrow">'; for(let i=0;i<p.energyMax;i++) chips+='<div class="chip '+(i<free?'':'tapped')+'"></div>'; chips+='</div>';
    const LL=game.leaderDef(p);
    return '<div class="pbar"><div class="life '+(top&&targets.includes('player')?'target':'')+'" id="life'+p.i+'">'+p.life+'</div><div class="nm">'+esc(p.name)+(LL?'<div style="font-size:10px;color:'+(p.main?AN.ATTRS[p.main].c:'#C58CFF')+';font-weight:400">'+(p.main?AN.ATTRS[p.main].n:'変異')+' ・ '+esc(LL.name)+(p.abilityUsed?'（使用済）':'')+' ・ '+mechTxt(p)+'</div>':'')+'</div>'
      +'<div class="st"><span>手札 <b>'+p.hand.length+'</b></span><span>山札 <b>'+p.deck.length+'</b></span></div>'
      +'<div class="st"><span>墓地 <b>'+p.grave.length+'</b></span><span>エナジー <b>'+free+'/'+p.energyMax+'</b></span></div>'+chips+'</div>';
  };
  const fieldEl=(p,mine)=>{
    const f=document.createElement('div'); f.className='field'+(p.field.length?'':' empty'); f.dataset.empty=mine?'（場にクリーチャーなし）':'';
    p.field.forEach(cr=>{
      const canAtk=mine&&myTurn&&game.canAttackWith(me,cr);
      const el=cardEl(cr.c.d,{tapped:cr.tapped,sick:(cr.sick&&!game.hasKw(cr,'haste')&&mine)||(mine&&cr.attacked&&!canAtk),ready:canAtk&&!atkMode,target:!mine&&targets.includes(cr.c.uid),frozen:cr.frozen,sel:atkMode&&cr===atkCr,power:game.power(cr),hp:game.health(cr),hpMax:game.maxHealth(cr),eq:cr.equips.length||0,badge:cr.stun?'気絶':(cr.c.d.anomaly?'アノマリー':(game.hasKw(cr,'armor')&&cr.armorUsed?'装甲済':''))});
      el.onclick=()=>{
        if(!mine && atkMode && targets.includes(cr.c.uid)){ ui.attackFrom=null; doAct({t:'attack',uid:atkCr.c.uid,target:cr.c.uid}); return; }
        if(mine && canAtk && !atkMode){ ui.attackFrom=cr.c.uid; renderBattle(); return; }
        if(mine && atkMode && cr===atkCr){ ui.attackFrom=null; renderBattle(); return; }
        const btns=[]; if(mine&&canAtk) btns.push({label:'攻撃する',cls:'primary',fn:()=>{ ui.attackFrom=cr.c.uid; renderBattle(); }});
        cardSheet(cr.c.d,{power:game.power(cr),hp:game.health(cr),hpMax:game.maxHealth(cr)},btns.concat(cr.equips.map(e=>({label:'装備: '+e.d.name,fn:()=>cardSheet(e.d,{},[])}))));
      };
      el.dataset.uid=cr.c.uid; el.dataset.zone='field'; el.dataset.attr=cr.c.d.anomaly?'anom':(cr.c.d.attr[0]||'none');
      f.appendChild(el);
    });
    return f;
  };
  s.appendChild(div('',pbar(op,true)));
  s.appendChild(zoneEl(op,false));
  s.appendChild(fieldEl(op,false));
  const last=game.log.length?game.log[game.log.length-1]:{s:''};
  const mid=document.createElement('div'); mid.className='mid';
  const phaseTxt = game.winner!=null?'終了': game.active===ME?'あなたのターン':(series.online?'相手のターン':'CPUのターン');
  mid.innerHTML='<div class="logline">'+esc(last.s)+'</div><button class="ghost helpbtn sndbtn" id="snd" title="サウンド">'+sndIcon()+'</button><button class="ghost helpbtn" id="help" title="用語集">？</button><div class="phase '+(game.active===ME?'you':'')+'">'+phaseTxt+'</div>';
  mid.querySelector('#help').onclick=(e)=>{ e.stopPropagation(); showGlossary(); };
  mid.querySelector('#snd').onclick=(e)=>{ e.stopPropagation(); soundSheet(()=>{ if(ui.screen==='battle'&&game) renderBattle(); }); };
  mid.querySelector('.logline').onclick=showLog;
  s.appendChild(mid);
  s.appendChild(fieldEl(me,true));
  s.appendChild(div('',pbar(me,false)));
  s.appendChild(zoneEl(me,true));
  // hand
  const hand=document.createElement('div'); hand.className='hand fan';
  const n=me.hand.length, W=Math.min(app.clientWidth||390,560), CW=74;
  const gap=n>1? Math.min(62, (W-CW-44)/(n-1)) : 0;
  const spread=Math.min(6, 40/Math.max(1,n-1));
  me.hand.forEach((c,i)=>{
    const can=game.canPlay(me,c);
    const ec=game.costOf(me,c.d,c); const el=cardEl(c.d,{cost:ec, badge:c.boost?'詠唱+'+c.boost:(c.d.anomaly?(c.d.weird?'奇妙':'アノマリー'):'')}); if(myTurn&&!can) el.classList.add('dim');
    const k=i-(n-1)/2;
    el.style.left='calc(50% - '+(CW/2)+'px + '+(k*gap)+'px)';
    el.style.bottom=(14-k*k*1.0)+'px';
    el.style.transform='rotate('+(k*spread)+'deg)';
    el.style.zIndex=10+i;
    el.onclick=()=>{
      ui.attackFrom=null;
      const cost=game.costOf(me,c.d,c);
      cardSheet(c.d,{},[
        {label:'プレイ（エナジー'+cost+'）',cls:'primary',disabled:!can,fn:()=>{ doAct({t:'play',uid:c.uid}); }},
      ]);
    };
    el.dataset.uid=c.uid; el.dataset.zone='hand'; el.dataset.attr=c.d.anomaly?'anom':(c.d.attr[0]||'none');
    hand.appendChild(el);
  });
  s.appendChild(hand);
  const act=document.createElement('div'); act.className='actions';
  let hint='';
  if(game.winner!=null) hint='';
  else if(!myTurn && !humanPend) hint= series.online ? (pend&&pend.p!==ME ? '相手が選択中…' : '相手のターンです') : 'CPUが考えています…';
  else if(atkMode) hint='攻撃先をタップ（相手のライフ、または相手のクリーチャー）';
  else hint='エナジー'+me.energy+'/'+me.energyMax+' ・ 手札をタップでプレイ / 光っているクリーチャーで攻撃';
  const L=game.leaderDef(me);
  act.innerHTML='<div class="hint">'+hint+'</div>'+(atkMode?'<button class="ghost" id="cancelAtk">攻撃をやめる</button>':'')
    +(L?'<button id="ability" class="'+(game.canUseAbility(me)?'':'ghost')+'" '+(game.canUseAbility(me)?'':'disabled')+' title="'+esc(L.text)+'">'+esc(L.name)+'（'+L.cost+'）</button>':'')
    +'<button class="primary" id="endTurn" '+(myTurn?'':'disabled')+'>ターン終了</button>'+(series.online?'<button class="ghost" id="concede" title="投了">投了</button>':'');
  const cc=act.querySelector('#concede'); if(cc) cc.onclick=()=>askConfirm('投了しますか？','投了する',()=>window.__act({t:'concede'}));
  const ab=act.querySelector('#ability'); if(ab){ ab.onclick=()=>{ ui.attackFrom=null; doAct({t:'ability'}); }; ab.oncontextmenu=e=>{ e.preventDefault(); toast(L.text); }; }
  const oppL=game.leaderDef(op);
  s.appendChild(act);
  s.querySelector('#endTurn').onclick=()=>{ ui.attackFrom=null; doAct({t:'end'}); };
  const ca=s.querySelector('#cancelAtk'); if(ca) ca.onclick=()=>{ ui.attackFrom=null; renderBattle(); };
  const lifeOp=s.querySelector('#life'+op.i); lifeOp.onclick=()=>{ if(atkMode&&targets.includes('player')){ ui.attackFrom=null; doAct({t:'attack',uid:atkCr.c.uid,target:'player'}); } };
  // events → flashes
  const evs=game.events.slice(evSeen); evSeen=game.events.length;
  evs.forEach(e=>{ if(e.type==='play' && e.d && e.d.anomaly) queueReveal(e.d, game.players[e.p].name); if(e.type==='trap') queueReveal(Object.assign({isTrap:true},e.d), game.players[e.p].name); if(e.type==='bossphase') queueReveal({phase:true, name:game.players[e.p].name}, game.players[e.p].name); });
  AN.FX.run(prevSnap, s, evs, game, ME);
  if(series && series.tut) tutAfterRender(s);
  if(game.winner!=null && !game._endSnd){ game._endSnd=true; AN.SFX.later(350, game.winner===ME?'win':'lose'); }
  // pending for human
  if(game.phase==='mulligan'){ renderMulligan(); return; }
  if(humanPend) renderPending(pend);
  if(game.winner!=null) setTimeout(finishGame, 900);
}
// ---------- ボス選択 ----------
const LSB='anomaly_boss_v1';
function bossProgress(){ try{ return parseInt(localStorage.getItem(LSB)||'0'); }catch(e){ return 0; } }
function setBossProgress(n){ try{ localStorage.setItem(LSB,String(n)); }catch(e){} }
function renderBoss(){
  const s=screenEl('boss'); const prog=bossProgress();
  s.innerHTML='<div class="topbar"><button class="ghost" id="back">←</button><div class="t">ボスに挑戦</div></div><div class="scroll wrap">'
   +'<div class="sub" style="line-height:1.7;margin-bottom:12px">いつもどおり90枚を受け取ってデッキを組み、強化されたボスと1本勝負。倒すと次のボスが解放されます。ボスは全カードから選んだ強いデッキを使います。</div>'
   +AN.BOSSES.map((b,i)=>{ const open=i<=prog; const cleared=i<prog; return '<div class="bosscard'+(open?'':' locked')+'" style="--ac:'+(b.attr?AN.ATTRS[b.attr].c:'#C58CFF')+'">'+'<div class="bport" style="background-image:url('+ART('chal_'+(i+1))+')"></div>'+'<div class="bbody"><div class="bn">'+(i+1)+'. '+esc(b.name)+(cleared?' <span class="clr">撃破済</span>':'')+'</div><div class="sub">'+(open?esc(b.desc):'前のボスを倒すと解放')+'</div>'+(open?'<button class="primary" data-b="'+b.key+'">挑戦する</button>':'')+'</div></div>'; }).join('')
   +'</div>';
  s.querySelector('#back').onclick=()=>show('title');
  s.querySelectorAll('button[data-b]').forEach(bt=>bt.onclick=()=>{ setup.boss=bt.dataset.b; setup.seed=''; newSeries(); setup.boss=null; });
}
function renderMulligan(){
  const me=game.players[ui.me];
  if(game.mullDone[ui.me]){ sheet('<h3>マリガン</h3><div class="sub">相手が手札を選んでいます…</div>', true, true); return; }
  ui.mullSel=ui.mullSel||new Set();
  const first=game.first===ui.me;
  const sh=sheet('<h3>マリガン：戻すカードを選んでください</h3><div class="sub" style="margin-bottom:6px">'+(first?'あなたが先攻です。':'あなたは後攻です（星のかけらは戻せません）。')+'選んだカードを山札に戻して混ぜ、同じ枚数を引き直します。</div><div class="picks" id="mpicks"></div><div class="btns"><button class="primary" id="mgo"></button></div>', true, true);
  const pk=sh.querySelector('#mpicks');
  const upd=()=>{ const n=ui.mullSel.size; sh.querySelector('#mgo').textContent= n? n+'枚を引き直して始める' : 'この手札で始める'; };
  me.hand.forEach(c=>{
    const el=cardEl(c.d,{}); if(ui.mullSel.has(c.uid)) el.classList.add('mullx');
    if(c.d.id==='sp_shard'){ el.style.opacity=.6; }
    else el.onclick=()=>{ if(ui.mullSel.has(c.uid)) ui.mullSel.delete(c.uid); else ui.mullSel.add(c.uid); el.classList.toggle('mullx'); upd(); };
    el.oncontextmenu=(e)=>{ e.preventDefault(); cardSheet(c.d,{},[]); };
    pk.appendChild(el);
  });
  upd();
  sh.querySelector('#mgo').onclick=()=>{ const u=[...ui.mullSel]; ui.mullSel=new Set(); doAct({t:'mull',uids:u}); };
}
function zoneEl(p, mine){
  const z=document.createElement('div'); z.className='zone';
  if(!p.relics.length && !p.traps.length) return z;
  p.relics.forEach(r=>{ const b=document.createElement('button'); b.className='zchip relic'; b.innerHTML=AN.iconSvg(r.c.d)+'<span>'+esc(r.c.d.name)+(r.cd!=null?'<b>'+r.cd+'</b>':'')+'</span>'; b.onclick=()=>cardSheet(r.c.d,{},[]); z.appendChild(b); });
  p.traps.forEach(c=>{ const b=document.createElement('button'); b.className='zchip trap'; if(mine){ b.innerHTML=AN.iconSvg(c.d)+'<span>'+esc(c.d.name)+'</span>'; b.onclick=()=>cardSheet(c.d,{},[]); } else { b.innerHTML='<span>？ 罠</span>'; b.onclick=()=>toast('伏せられた罠。中身は分からない'); } z.appendChild(b); });
  return z;
}
// ゲーム内の確認ダイアログ（ブラウザ標準の confirm はアーティファクトや一部のアプリ内ブラウザで表示されないため使わない）
function askConfirm(msg, yesLabel, onYes){
  const sh=sheet('<h3>確認</h3><div class="sub" style="margin-bottom:12px;line-height:1.7">'+esc(msg)+'</div><div class="btns"><button class="ghost" id="cfNo">やめる</button><button class="primary" id="cfYes">'+esc(yesLabel||'はい')+'</button></div>', true);
  sh.querySelector('#cfNo').onclick=closeSheet;
  sh.querySelector('#cfYes').onclick=()=>{ closeSheet(); onYes(); };
}
function renderPending(q){
  const me=game.players[ui.me];
  if(q.type==='block'){
    const atk=game.findCr(q.attacker);
    const sh=sheet('<h3>「'+esc(atk.c.d.name)+'」（攻撃力'+game.power(atk)+'）が'+(q.target==='player'?'あなた':'「'+esc(game.findCr(q.target).c.d.name)+'」')+'に攻撃。ブロックしますか？</h3><div class="picks" id="picks"></div><div class="btns"><button class="primary" id="nob">ブロックしない</button></div>', false, true);
    const pk=sh.querySelector('#picks');
    q.cands.forEach(u=>{ const cr=game.findCr(u); const el=cardEl(cr.c.d,{power:game.power(cr),hp:game.health(cr),hpMax:game.maxHealth(cr)}); el.onclick=()=>{ doAct({t:'choice',v:u}); }; pk.appendChild(el); });
    sh.querySelector('#nob').onclick=()=>{ doAct({t:'choice',v:null}); };
  } else if(q.type==='pick'){
    const label=q.eff.e==='discover'?'発見：1枚を選んで手札に加える':'山札の上：1枚を手札に、残りは山札の下へ';
    const sh=sheet('<h3>'+label+'</h3><div class="picks" id="picks"></div>', false, true);
    const pk=sh.querySelector('#picks');
    q.opts.forEach((o2,i)=>{ const el=cardEl(o2.d,{}); el.onclick=()=>{ doAct({t:'choice',v:i}); }; pk.appendChild(el); });
  } else if(q.type==='target'||q.type==='equip'){
    const label=q.type==='equip'?'「'+esc(q.src.d.name)+'」を装備するクリーチャーを選択':'「'+esc(q.src.d.name)+'」の対象を選択：'+esc(AN.effectText(q.eff));
    const sh=sheet('<h3>'+label+'</h3><div class="picks" id="picks"></div>'+(q.cands.includes('player')?'<div class="btns"><button class="primary" id="pickPlayer">相手のライフ（'+game.players[1-ui.me].life+'）</button></div>':''), false, true);
    const pk=sh.querySelector('#picks');
    const pp=sh.querySelector('#pickPlayer'); if(pp) pp.onclick=()=>{ doAct({t:'choice',v:'player'}); };
    q.cands.filter(u=>u!=='player').forEach(u=>{
      const cr=game.findCr(u); let el;
      if(cr) el=cardEl(cr.c.d,{power:game.power(cr),hp:game.health(cr),hpMax:game.maxHealth(cr),tapped:false});
      else { const c=me.grave.find(x=>x.uid===u); el=cardEl(c.d,{}); }
      el.onclick=()=>{ doAct({t:'choice',v:u}); }; pk.appendChild(el);
    });
  }
}
function showLog(){
  const sh=sheet('<h3>ログ</h3><div class="log">'+game.log.slice(-60).map(l=>'<div class="'+l.kind+'">'+esc(l.s)+'</div>').join('')+'</div>');
  sh.querySelector('.log').scrollTop=1e6;
}
function finishGame(){
  if(!game||game.winner==null||ui.screen!=='battle') return;
  revealQ.length=0; document.querySelectorAll('.reveal').forEach(e=>e.remove()); revealing=false;
  if(series && series.tut){ tutFinish(game.winner); return; }
  if(series && series.adv){ advFinish(game.winner); return; }
  const w=game.winner; series.lastWinner=w; series.lastTurns=game.turn; series.nextFirst=1-w; // 敗者が先攻
  if(series.online){ series.gameNo=series.playingNo; ui.screen='result'; onlineGameOver(w); }
  else { series.wins[w]++; save(); }
  show('result');
}

// ----- result -----
function renderResult(){
  const s=screenEl('result');
  const need=Math.ceil(series.format/2);
  const over=series.wins[0]>=need||series.wins[1]>=need;
  const ME=ui.me; const won=series.lastWinner===ME;
  const revealed=series.pools[1-ME].filter(d=>d.anomaly&&d.revealed);
  const bossD=series.boss? AN.BOSSES.find(b=>b.key===series.boss) : null;
  const oppName=series.online? series.online.oppName : (bossD?bossD.name:'CPU');
  if(bossD && over && series.wins[ME]>=need){ const idx=AN.BOSSES.indexOf(bossD); if(bossProgress()<idx+1) setBossProgress(idx+1); }
  s.innerHTML='<div class="result"><div class="big" style="color:'+(won?'#7be0b0':'#f28f8f')+'">'+(won?'WIN':'LOSE')+'</div><div class="sub">第'+series.gameNo+'ゲーム・'+series.lastTurns+'ターンで決着</div>'
   +(bossD&&over? '<div class="big" style="font-size:22px">'+(series.wins[ME]>=need?esc(bossD.name)+' 撃破！':'敗北…')+'</div>'+(series.wins[ME]>=need && AN.BOSSES.indexOf(bossD)<AN.BOSSES.length-1?'<div class="sub">次のボスが解放されました</div>':'') : '<div class="score">'+series.wins[ME]+' – '+series.wins[1-ME]+'</div>')
   +(over?(bossD?'':'<div class="big" style="font-size:22px">'+(series.wins[ME]>need-1?'シリーズ勝利':'シリーズ敗北')+'</div>'):'<div class="sub">'+(won?'次は'+esc(oppName)+'が先攻':'次はあなたが先攻')+'</div>')
   +'<div class="sub" style="margin-top:10px">判明した'+esc(oppName)+'のアノマリー：'+(revealed.length?'':'まだなし')+'</div><div class="picks" id="rev"></div>'
   +'<div class="menu" style="width:100%;max-width:320px">'+(over?'<button class="primary" id="home">タイトルへ</button>':'<button class="primary" id="next">デッキを調整して次のゲームへ</button><button id="home">中断してタイトルへ</button>')+'</div></div>';
  const rv=s.querySelector('#rev'); revealed.forEach(d=>{ const el=cardEl(d,{}); el.onclick=()=>cardSheet(d,{},[]); rv.appendChild(el); });
  if(over){ s.querySelector('#home').onclick=()=>{ if(series.online) onlineLeave(); clearSave(); series=null; game=null; show('title'); }; }
  else { s.querySelector('#next').onclick=()=>{ ui.filter='all'; if(series.online){ ui.screen='wait'; renderWait(); onRoom(room); return; } series.gameNo++; save(); show('draft'); }; s.querySelector('#home').onclick=()=>{ if(series.online){ onlineLeave(); series=null; game=null; } else { series.gameNo++; save(); } show('title'); }; }
}

// ----- codex -----
function renderCodex(){
  const s=screenEl('codex');
  const filters=[['all','すべて'],...AN.ATTR_ORDER.map(a=>[a,AN.ATTRS[a].n+' '+AN.ATTRS[a].k]),['none','無属性']];
  s.innerHTML='<div class="topbar"><button class="ghost" id="back">←</button><div class="t">カードリスト <span class="sub">'+AN.CARDS.length+'種</span></div></div>'
   +'<div class="filters">'+filters.map(f=>'<button data-f="'+f[0]+'" class="'+(ui.cfilter===f[0]?'on':'')+'">'+f[1]+'</button>').join('')+'</div>'
   +'<div class="scroll"><div class="kwlist">'+Object.keys(AN.KW).map(k=>'<b>'+AN.KW[k]+'</b>：'+AN.KW_HELP[k]).join('　')+'<br>エナジーは毎ターン自動で1増える（上限10）。90枚（5属性＋無属性＋アノマリー3枚）を見てからメイン属性を選び、デッキは30枚（メイン属性＋無属性＋アノマリー）。クリーチャーは攻撃力（左下）と体力（右下）を持ち、戦闘では互いに攻撃力分のダメージを与え合う。ダメージは蓄積し、体力0で破壊。攻撃しても横向き（レスト）にはならず、攻撃済みになるだけ。レスト状態のクリーチャーは攻撃も守護もできず、自分のターン開始時にスタンドする。水・光のレスト効果や凍結を受けたクリーチャーは「気絶」し、攻撃されても反撃しない。レスト中の守護は守れない。攻撃は相手のライフか相手のクリーチャー（どれでも）を選べるが、スタンド状態の守護がいる間は守護しか攻撃できない（不可視は無視できる）。属性ごとにリーダー能力（2エナジー・1ターン1回）：炎「火花」相手のライフ-1／水「潮読み」ライフ1で1ドロー／森「成長」+1永続／光「聖光」2回復（祈り5以上で1ドロー）／闇「屍術」骸トークン。属性ごとの看板メカニクス：炎＝連撃（このターンに他のカードをN枚プレイ済みなら発動）、水＝詠唱（手札にある間、スペルを唱えるたびに強化／コスト減。潮読みもスペル扱い）、森＝繁茂（最大エナジー7以上）、光＝祈り（このゲームで回復した回数）、闇＝供物（自分のカードが墓地に送られた数。消費して発動）。アノマリーは3枚中1枚が「奇妙」枠で、役に立つかどうか分からない効果を持つ。キーワードは属性専有：速攻＝炎、不可視・凍結＝水、突破＝森、守護＝光・水、装甲＝光、吸収・猛毒・蘇生＝闇。<br>抽選率：コモン60% / アンコモン28% / レア10% / レジェンド2%　（アノマリーは各プレイヤー3枚、その場で生成）</div><div class="grid" id="grid"></div></div>';
  const grid=s.querySelector('#grid');
  const ai=d=>d.attr.length?AN.ATTR_ORDER.indexOf(d.attr[0]):5;
  const list=AN.CARDS.filter(d=>ui.cfilter==='all'||(ui.cfilter==='none'?d.attr.length===0:d.attr.includes(ui.cfilter))).slice().sort((a,b)=>ai(a)-ai(b)||a.cost-b.cost);
  list.forEach(d=>{ const el=cardEl(d,{}); el.onclick=()=>cardSheet(d,{},[]); grid.appendChild(el); });
  s.querySelectorAll('.filters button').forEach(b=>b.onclick=()=>{ ui.cfilter=b.dataset.f; renderCodex(); });
  s.querySelector('#back').onclick=()=>show('title');
}


// ================= online =================
const LSO='anomaly_online_v2';
let net=null, roomUnsub=null, actUnsub=null, appliedN=0;
function getNet(){ if(!net) net=window.AN_NET.createNet(window.FIREBASE_CONFIG||null); return net; }
function saveOnline(o){ try{ localStorage.setItem(LSO, JSON.stringify(o)); }catch(e){} }
function loadOnline(){ try{ return JSON.parse(localStorage.getItem(LSO)); }catch(e){ return null; } }
function clearOnline(){ try{ localStorage.removeItem(LSO); }catch(e){} }
function stopWatch(){ if(roomUnsub){ roomUnsub(); roomUnsub=null; } if(actUnsub){ actUnsub(); actUnsub=null; } }
const lobby={name:'', code:'', format:3, err:''};
function renderLobby(){
  const s=screenEl('lobby');
  const n=getNet();
  s.innerHTML='<div class="topbar"><button class="ghost" id="back">←</button><div class="t">オンライン対戦</div></div><div class="scroll wrap">'
   +'<div class="sub" style="line-height:1.7">'+(n.kind==='firebase'?'通信：Firebase（別の端末・別の場所の相手と対戦できます）':'通信：このブラウザ内のみ（Firebase未設定。同じブラウザの別タブ同士でだけ対戦できます）')+'</div>'
   +'<div class="field-label">あなたの名前</div><input type="text" id="nm" maxlength="12" placeholder="例: ショウ" value="'+esc(lobby.name)+'">'
   +'<div class="field-label">形式（部屋を作る側が決めます）</div><div class="seg" id="segF"><button data-v="3" class="'+(lobby.format===3?'on':'')+'">BO3</button><button data-v="5" class="'+(lobby.format===5?'on':'')+'">BO5</button></div>'
   +'<div style="margin-top:18px"><button class="primary" id="create" style="width:100%">部屋を作る</button></div>'
   +'<div class="field-label" style="margin-top:22px">部屋コードで参加</div><div class="row"><input type="text" id="code" maxlength="4" placeholder="ABCD" style="text-transform:uppercase;font-family:var(--disp);letter-spacing:.2em" value="'+esc(lobby.code)+'"><button id="join">参加</button></div>'
   +(lobby.err?'<div style="color:#f28f8f;margin-top:10px">'+esc(lobby.err)+'</div>':'')
   +'<div class="sub" style="margin-top:22px;line-height:1.7">・部屋を作った側がコードを相手に伝えます<br>・両者が90枚からデッキを組んで「対戦へ」を押すと開始<br>・通信が切れてもタイトルの「再開」で戻れます（行動ログから復元）<br>・チート対策はありません（信頼ベース）</div></div>';
  s.querySelector('#back').onclick=()=>show('title');
  s.querySelectorAll('#segF button').forEach(b=>b.onclick=()=>{ lobby.format=+b.dataset.v; renderLobby(); });
  s.querySelector('#create').onclick=async()=>{ lobby.name=s.querySelector('#nm').value.trim()||'P1'; lobby.err=''; try{ await onlineCreate(); }catch(e){ lobby.err='作成に失敗: '+e.message; renderLobby(); } };
  s.querySelector('#join').onclick=async()=>{ lobby.name=s.querySelector('#nm').value.trim()||'P2'; lobby.code=s.querySelector('#code').value.trim().toUpperCase(); lobby.err=''; try{ await onlineJoin(lobby.code); }catch(e){ lobby.err=e.message; renderLobby(); } };
}
async function onlineCreate(){
  const seed='o'+Math.floor(Math.random()*1e9).toString(36);
  const code=await getNet().createRoom({seed, format:lobby.format, players:{0:{name:lobby.name}}, created:Date.now()});
  enterRoom(code, 0, lobby.name);
}
async function onlineJoin(code){
  if(!/^[A-Z0-9]{4}$/.test(code)) throw new Error('コードは4文字です');
  const r=await getNet().getRoom(code); if(!r) throw new Error('その部屋は見つかりません');
  if(r.players && r.players[1] && r.players[1].name!==lobby.name) throw new Error('その部屋は満員です');
  await getNet().set(code,'players/1',{name:lobby.name});
  enterRoom(code, 1, lobby.name);
}
function enterRoom(code, slot, name){
  saveOnline({code, slot, name});
  series={online:{code, slot, name, oppName:'相手'}, seed:null, format:3, level:null, wins:[0,0], gameNo:1, pools:null, decks:[[],[]], mains:[null,null], nextFirst:null};
  ui.me=slot;
  stopWatch();
  roomUnsub=getNet().watchRoom(code, onRoom);
  show('wait');
}
function onlineResume(){ const o=loadOnline(); if(!o) return; lobby.name=o.name; enterRoom(o.code, o.slot, o.name); }
function onlineLeave(){ stopWatch(); clearOnline(); }
let room=null;
function onRoom(r){
  room=r; if(!series||!series.online) return;
  const o=series.online;
  if(!series.pools){ // first sight of room: derive pools from seed
    series.seed=r.seed; series.format=r.format||3;
    const rng=AN.makeRng('pool:'+r.seed);
    series.pools=[0,1].map(i=>{ const p=AN.drawPool(rng,87,null); const an=[0,1,2].map(k=>AN.makeAnomaly(rng,i*3+k,null)); return an.concat(p); });
  }
  const pl=r.players||{}; o.oppName=(pl[1-o.slot]&&pl[1-o.slot].name)||'相手';
  // results → wins, gameNo
  const games=r.games||{}; let wins=[0,0], n=1;
  while(games[n] && games[n].result!=null){ wins[games[n].result]++; n++; }
  series.wins=wins; const need=Math.ceil(series.format/2);
  if(ui.screen==='battle'||ui.screen==='result'){ if(ui.screen==='result') renderResult(); return; }
  if(wins[0]>=need||wins[1]>=need){ series.gameNo=n-1; return; }
  series.gameNo=n;
  const gd=games[n]||{};
  const bothReady = gd.ready && gd.ready[0] && gd.ready[1] && gd.decks && gd.decks[0] && gd.decks[1];
  if(ui.screen==='wait'){
    if(!pl[1]) { renderWait(); return; }
    if(bothReady){ onlineStartGame(n, gd); return; }
    // restore my deck if already submitted
    if(gd.decks && gd.decks[o.slot]){ series.decks[o.slot]=gd.decks[o.slot].slice(); series.mains[o.slot]=gd.mains[o.slot]; }
    if(gd.ready && gd.ready[o.slot]) { renderWait(); return; }
    show('draft'); return;
  }
  if(ui.screen==='draft' && bothReady){ onlineStartGame(n, gd); return; }
  if(ui.screen==='waitready'){ if(bothReady) onlineStartGame(n, gd); else renderWaitReady(); return; }
}
function renderWait(){
  const s=screenEl('wait'); const o=series.online; const n=getNet();
  s.innerHTML='<div class="wrap" style="padding-top:12vh;text-align:center"><div class="sub">部屋コード</div><div class="disp" style="font-size:44px;letter-spacing:.2em;margin:6px 0 14px">'+esc(o.code)+'</div>'
   +'<div class="sub">'+(room&&room.players&&room.players[1]?'相手：'+esc(o.oppName):'相手の参加を待っています…')+'</div>'
   +'<div class="sub" style="margin-top:8px">'+(n.kind==='firebase'?'':'（このブラウザの別タブで同じコードを入力すると対戦できます）')+'</div>'
   +'<div class="menu" style="max-width:320px;margin:30px auto 0"><button class="ghost" id="leave">退出</button></div></div>';
  s.querySelector('#leave').onclick=()=>{ onlineLeave(); series=null; show('title'); };
}
async function onlineReady(){
  const o=series.online; const n=series.gameNo;
  ui.screen='waitready'; renderWaitReady();
  await getNet().set(o.code,'games/'+n+'/decks/'+o.slot, series.decks[o.slot]);
  await getNet().set(o.code,'games/'+n+'/mains/'+o.slot, series.mains[o.slot]);
  await getNet().set(o.code,'games/'+n+'/ready/'+o.slot, true);
}
function renderWaitReady(){
  const s=screenEl('wait'); ui.screen='waitready';
  s.innerHTML='<div class="wrap" style="padding-top:20vh;text-align:center"><div class="big" style="font-family:var(--disp);font-size:22px">準備完了</div><div class="sub" style="margin-top:10px">'+esc(series.online.oppName)+'のデッキ構築を待っています…</div>'
   +'<div class="menu" style="max-width:320px;margin:30px auto 0"><button class="ghost" id="leave">退出</button></div></div>';
  s.querySelector('#leave').onclick=()=>{ onlineLeave(); series=null; show('title'); };
}
function onlineStartGame(n, gd){
  const o=series.online;
  const decks=[0,1].map(i=>gd.decks[i].map(k=>series.pools[i][k]));
  const mains=[gd.mains[0]||null, gd.mains[1]||null];
  series.decks=[gd.decks[0].slice(), gd.decks[1].slice()]; series.mains=mains;
  const prev=(room.games||{})[n-1]; const first = prev && prev.result!=null ? 1-prev.result : null;
  const names=[room.players[0].name, room.players[1].name];
  series.playingNo=n;
  game=new AN.Game({seed:series.seed+':g'+n, decks, names, first, mains, choosers:[null,null]});
  game.uiPause=true;
  ui.attackFrom=null; evSeen=0; appliedN=0; ui.mullSel=new Set();
  if(actUnsub) actUnsub();
  show('battle');
  actUnsub=getNet().watchActions(o.code, n, (a,i)=>{ if(i<appliedN) return; appliedN=i+1; if(!game) return; applyAction(game, a, a.p); if(ui.screen==='battle') renderBattle(); });
}
function onlineSend(a){ const o=series.online; getNet().pushAction(o.code, series.gameNo, Object.assign({p:o.slot, ts:Date.now()}, a)); }
async function onlineGameOver(w){ const o=series.online; const n=series.playingNo; const gd=(room.games||{})[n]||{}; if(gd.result==null) await getNet().set(o.code,'games/'+n+'/result', w); }

/*ADV*/
window.__act=(a)=>doAct(a);
window.__g=()=>game; window.__rb=()=>renderBattle();
// boot
if(location.search.includes('auto=1')){ /* debug hook */ }
render();
})();
