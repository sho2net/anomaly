const AN=require('./ai.js');
const V=(process.env.V||'').split(',');
const D=AN.CARD_BY_ID;
if(V.includes('dt')){ ['V33','V34','V35'].forEach(id=>{ const d=D[id]; if(d.power>1) d.power--; else d.hp--; }); D.V37.cost=3; D.V38.cost=5; }
if(V.includes('armor')) AN.RULES.armorWeaken=true;
if(V.includes('rayhp')) AN.CARDS.forEach(d=>{ if(d.type==='creature'&&d.attr[0]==='ray'&&!d.kw.includes('blocker')) d.hp++; });
if(V.includes('void3')) AN.LEADER.void.cost=3;
if(V.includes('ray3')){ AN.LEADER.ray.ef=[{t:'leader',e:'heal',n:3}]; }
if(V.includes('rayfort')){ AN.LEADER.ray.ef=[{t:'leader',e:'heal',n:2},{t:'leader',e:'pumpTarget',n:1}]; }
if(V.includes('raydraw')){ AN.LEADER.ray.ef=[{t:'leader',e:'heal',n:2},{t:'leader',e:'draw',n:1,req:{pray:5}}]; }
if(V.includes('rayatk')) AN.CARDS.forEach(d=>{ if(d.type==='creature'&&d.attr[0]==='ray'&&!d.kw.includes('blocker')) d.power++; });
if(V.includes('voidsoft')){ D.V33.hp=1; D.V33.power=1; ['V26'].forEach(id=>D[id].cost=7); D.V38.cost=5; }
if(V.includes('rayatk4')) AN.CARDS.forEach(d=>{ if(d.type==='creature'&&d.attr[0]==='ray'&&!d.kw.includes('blocker')&&d.cost>=4) d.power++; });
if(V.includes('rayheal')){ D.R25.cost=2; D.R10.hp++; D.R12.hp++; }
const A=AN.ATTR_ORDER, M={}, W={}, G={}; const N=parseInt(process.env.N||'2000');
for(let i=0;i<N;i++){
  const rng=AN.makeRng('pool'+i);
  const pools=[0,1].map(k=>{ const p=AN.drawPool(rng,87,null); for(let j=0;j<3;j++) p.unshift(AN.makeAnomaly(rng,k*3+j,null)); return p; });
  const mains=pools.map(p=>AN.AI.bestMain(p));
  const decks=pools.map((p,k)=>AN.AI.autoDeck(p,rng,mains[k]));
  const g=new AN.Game({seed:'g'+i,decks,names:['A','B'],mains,choosers:[AN.AI.chooser(3),AN.AI.chooser(3)]});
  let s=0; while(g.winner==null&&s++<4000) AN.AI.step(g,3);
  if(g.winner==null) continue;
  mains.forEach((m,k)=>{ G[m]=(G[m]||0)+1; if(g.winner===k) W[m]=(W[m]||0)+1; });
  if(mains[0]!==mains[1]){ const w=mains[g.winner], l=mains[1-g.winner]; M[w+'>'+l]=(M[w+'>'+l]||0)+1; }
}
const nm={flare:'炎',tide:'水',grow:'森',ray:'光',void:'闇'};
const row=a=>nm[a]+' '+A.filter(b=>b!==a).map(b=>{ const w=M[a+'>'+b]||0,l=M[b+'>'+a]||0; return '対'+nm[b]+Math.round(w/(w+l)*100); }).join(' ');
console.log('['+(process.env.V||'現状')+'] 全体 '+A.map(a=>nm[a]+Math.round(W[a]/G[a]*100)).join(' ')+' | '+row('ray')+' | '+row('void'));
